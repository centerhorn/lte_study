% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter8\SystemModel_Simulink)
%
% This folder contains multiple Simulink models (testbenches) that showcase how
% the LTE PHY System model can be implemented in Simulink and how you can 
% configure the Simulink model to perform qualitative and quantitative assessment of LTE system model.
% The details are presented in chapter 8 of the book "Understanding LTE with MATLAB"
% 
% There are all together 3 experiments in Simulink: 
%
% 1. MyModel0.slx   = Simulink simulation model without parameter dialog
%
% By running this model you perofrm the simulation of LTE model
% (transmission modes 1 to 4) for the parameters specicified in MATLAB
% script commlteSystem_params.
%  If we want to run the simulation for a different transmission mode or a different set of 
% operating conditions, we must first modify the system parameters by changing the MATLAB script. 
% Then we need to return to our Simulink model and rerun the simulation. 
% After setting parameters each time, the MATLAB function blocks in the
% model are recompiled and the simulation follows the full compilation of
% the model. At the end of simulation usually BER values are saved for SNR
% values specified.
% 
% 2. MyModel1.slx = Simulink simulation model with a  parameter dialog
%
% By running this model you perofrm the simulation of LTE model without the need 
% to specify parameters as a MATLAB script. A Parameter Dialog is
% added to the model that lets you interactively set simulation parameters.
% After setting parameters each time the MATLAB function blocks in the
% model are recompiled and the simulation follows the full compilation of
% the model. At the end of simulation usually BER values are saved for SNR
% values specified.
% 
% 3. MyModel2.slx = Simulink model processing  voice or music data through LTE system model
%
% This model simulates an LTE phone call. First using blocks for DSP System
% Toolbox we perform speech/music coding to turn voice signals as
% bit stream inputs to the LTE model. After recovering the received bit stream we
% perform speech decoding operations to recover the transmitted voice/music signals.
% Exploration:
% By changing the file name in the "From Multimedia File" block you can
% stream any music or voice file 
% At the end of the simulation, variables InputAudio and OutputAudio in MATLAB 
% are the input and output voice/music signals of the LTE phone call. 
% Use MATLAB function soundsc to listen to the file.
% For example, by typing soundsc(OutputAdio, Fs) you listen to audio file
% output . Fs is the Sampling frequency of the voice/music file.
% As always by chaging parameters such as maxNumErrs and maxNumBits,  
% you get longer or shorter experiment time. By changing the link SNR, 
% the parameter snrdB, you can see the efect of AWGN noise
% on the overall performance. 