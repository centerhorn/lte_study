function [rxSig, chPathG, nVar]  = commlteSystem_Channel(txSig, snrdB, prmLTEPDSCH,  prmMdl )
%#codegen
% MIMO Fading channel
[rxFade, chPathG] = MIMOFadingChan(txSig, prmLTEPDSCH, prmMdl);
% Add AWG noise
sigPow = 10*log10(var(rxFade));
noiseVar = 10.^(0.1.*(sigPow-snrdB));
rxSig =  AWGNChannel(rxFade, noiseVar);
nVar=(10.^(0.1.*(-snrdB)))*ones(1,prmLTEPDSCH.numRx);