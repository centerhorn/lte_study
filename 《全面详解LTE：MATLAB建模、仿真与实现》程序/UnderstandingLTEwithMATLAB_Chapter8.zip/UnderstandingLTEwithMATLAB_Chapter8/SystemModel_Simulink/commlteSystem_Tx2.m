function [txSig, csr_ref] = commlteSystem_Tx2(nS,  dataIn, prmLTEDLSCH, prmLTEPDSCH, prmMdl)
%#codegen
% Transport block CRC generation
tbCrcOut1 =CRCgenerator(dataIn);
% Channel coding includes - CB segmentation, turbo coding, rate matching,
% bit selection, CB concatenation - per codeword
[data1, ~, ~] = TbChannelCoding(tbCrcOut1, nS, prmLTEDLSCH, prmLTEPDSCH);
%Scramble codeword
scramOut = Scramble(data1, nS, 0, prmLTEPDSCH.maxG);
% Modulate
modOut = Modulator(scramOut, prmLTEPDSCH.modType);
%%%%%%%%%%%%%%%%%%%%%%%
% MIMO transmitter based on the mode
%%%%%%%%%%%%%%%%%%%%%%%
switch prmLTEPDSCH.txMode
    case 1  % Mode 1: Single-antenna (SIMO mode)
        PrecodeOut =modOut;
        
    case 2   % Mode 2: Transmit diversity
        % TD with SFBC
        PrecodeOut = TDEncode(modOut(:,1),prmLTEPDSCH.numTx);
        
    case 3   % Mode 3: Open-loop Spatial multiplexing
        LayerMapOut = LayerMapper(modOut, [], prmLTEPDSCH);
        % Precoding
        PrecodeOut = SpatialMuxPrecoderOpenLoop(LayerMapOut, prmLTEPDSCH);
        
    case 4    % Mode 4: Closed-loop Spatial multiplexing
        % Layer mapping
        LayerMapOut = LayerMapper(modOut, [], prmLTEPDSCH);
        % Precoding
        usedCbIdx = prmMdl.cbIdx;
        [PrecodeOut, ~] = SpatialMuxPrecoder(LayerMapOut, prmLTEPDSCH, usedCbIdx);
end
% Generate Cell-Specific Reference (CSR) signals
numTx=prmLTEPDSCH.numTx;
csr = CSRgenerator(nS, numTx);
csr_ref=complex(zeros(2*prmLTEPDSCH.Nrb, 4, numTx));
for m=1:numTx
    csr_pre=csr(1:2*prmLTEPDSCH.Nrb,:,:,m);
    csr_ref(:,:,m)=reshape(csr_pre,2*prmLTEPDSCH.Nrb,4);
end
% Resource grid filling
txGrid = REmapper_mTx(PrecodeOut, csr_ref, nS, prmLTEPDSCH);
% OFDM transmitter
txSig = OFDMTx(txGrid, prmLTEPDSCH);