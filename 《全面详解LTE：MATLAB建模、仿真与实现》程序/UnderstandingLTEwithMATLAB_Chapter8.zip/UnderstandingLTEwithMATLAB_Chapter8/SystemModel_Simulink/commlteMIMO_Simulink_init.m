function commlteMIMO_Simulink_init(txMode, Tx, Rx, chanBW,  modType, contReg,...
     numCodeWords, cRate,maxIter, fullDecode, ...
    chanMdl, snrdB, Doppler, corrLvl, maxNumBits, cbIdx,  Eqmode, chEstOn )
% Create the parameter structures
vector=[1,2,4];
numTx=vector(Tx);
numRx=vector(Rx);
% PDSCH parameters
CheckAntennaConfig(numTx, numRx, txMode, numCodeWords);
prmLTEPDSCH = prmsPDSCH(txMode, chanBW, contReg, modType, numTx, numRx, numCodeWords,Eqmode);
[SymbolMap, Constellation]=ModulatorDetail(prmLTEPDSCH.modType);
prmLTEPDSCH.SymbolMap=SymbolMap;
prmLTEPDSCH.Constellation=Constellation;
if numTx==1
    prmLTEPDSCH.csrSize=[2*prmLTEPDSCH.Nrb, 4];
else
    prmLTEPDSCH.csrSize=[2*prmLTEPDSCH.Nrb, 4, numTx];
end
% DLSCH parameters
prmLTEDLSCH = prmsDLSCH(cRate,maxIter, fullDecode, prmLTEPDSCH);
% Channel parameters
chanSRate   = prmLTEPDSCH.chanSRate;
DelaySpread = prmLTEPDSCH.cpLenR;
 prmMdl = prmsMdl( chanSRate,  DelaySpread, chanMdl, Doppler, numTx, numRx, ...
    corrLvl, chEstOn-1, 0, cbIdx);
%% Assign parameter structure variables to base workspace
assignin('base', 'prmLTEPDSCH', prmLTEPDSCH);
assignin('base', 'prmLTEDLSCH', prmLTEDLSCH);
assignin('base', 'prmMdl', prmMdl);
assignin('base', 'snrdB', snrdB);
assignin('base', 'maxNumBits', maxNumBits);
assignin('base', 'maxNumErrs', maxNumBits);