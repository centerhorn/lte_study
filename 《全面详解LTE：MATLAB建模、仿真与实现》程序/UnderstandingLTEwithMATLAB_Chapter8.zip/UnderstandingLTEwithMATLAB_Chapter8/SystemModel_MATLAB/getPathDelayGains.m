function [PathDelays, PathGains]=getPathDelayGains(chanMdl)
Mdl=chanMdl(1:3);
switch Mdl
    case 'EPA'
        PathDelays = [0 30 70 90 110 190 410]*1e-9;
        PathGains    = [0 -1 -2 -3 -8 -17.2 -20.8];
    case 'EVA'
        PathDelays = [0 30 150 310 370 710 1090 1730 2510]*1e-9;
        PathGains  = [0 -1.5 -1.4 -3.6 -0.6 -9.1 -7 -12 -16.9];
    case 'ETU'
        PathDelays = [0 50 120 200 230 500 1600 2300 5000]*1e-9;
        PathGains  = [-1 -1 -1 0 0 0 -3 -5 -7];
end
end