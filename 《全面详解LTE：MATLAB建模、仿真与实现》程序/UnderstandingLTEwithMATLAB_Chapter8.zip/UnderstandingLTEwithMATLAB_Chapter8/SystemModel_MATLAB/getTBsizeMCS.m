function [tbSize, ActualRate] = getTBsizeMCS(modType, TCR, Nrb, numLayers, numPDSCHBits)
% Get the transport block size for a specified configuration.
% Inputs: 
%   modType     : 1 (QPSK), 2 (16QAM), 3 (64QAM)
%   TCR         : Target Code Rate
%   Nrb         : number of resource blocks
%   numLayers   : number of layers
%   numPDSCHBits: number of PDSCH bits (G)
% Output:
%   tbSize : transport block length
% Example: R.10 of A.3.3.2.1 in 36.101
%   tbLen =  getTBsizeRMC(1, 1/3, 50, 1, 12384)
% Reference: 
%   1) Section 7.1.7 of 36.213, for TB sizes.
%      Uses preloaded Tables 7.1.7.1-1, 7.1.7.2.1-1, 7.1.7.2.2 and 7.1.7.2.5.
%   2) Section A.3.1 of 36.101 for TB size selection criteria.
switch modType
    case 1 % QPSK
        numTBSizes = 10;
        stIdx = 0;
    case 2 % 16QAM
        numTBSizes = 7;
        stIdx = 9;
    case 3 % 64QAM
        numTBSizes = 12;
        stIdx = 15;
end
numBitsPerLayer=numPDSCHBits/numLayers;
% Load saved entries for Tables 7.1.7.2.1-1, 7.1.7.2.2 and 7.1.7.2.5.
load TBSTable.mat  
tbVec = baseTBSTab(stIdx+(1:numTBSizes), Nrb);      % for 1-based indexing
ProposedRates=(tbVec+24)./numBitsPerLayer;
ProposedRates(ProposedRates<1/3)=10;
[~, c] = min(abs(TCR-ProposedRates));
tbSize = tbVec(c);

if (numLayers==2) % Section 7.1.7.2.2
    if (Nrb <= 55)
        tbSize = baseTBSTab(stIdx+c, 2*Nrb); 
    else
        index=(layer2TBSTab(:,1)==tbSize);
        tbSize = layer2TBSTab(index, 2);
    end
elseif (numLayers==4)  % Section 7.1.7.2.5
    if (Nrb <= 27)
        tbSize = baseTBSTab(stIdx+c, 4*Nrb); 
    else
        index=(layer4TBSTab(:,1)==tbSize);
        tbSize = layer4TBSTab(index, 2);
    end
end
ActualRate=(tbSize+24)./numPDSCHBits;

% [EOF]
