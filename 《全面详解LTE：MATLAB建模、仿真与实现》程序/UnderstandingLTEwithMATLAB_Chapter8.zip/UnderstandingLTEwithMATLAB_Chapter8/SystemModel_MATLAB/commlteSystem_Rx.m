function [dataOut, dataRx, yRec] = commlteSystem_Rx(nS, csr_ref, rxSig, chPathG, nVar, ...
    prmLTEDLSCH, prmLTEPDSCH, prmMdl)
%#codegen
% OFDM Rx
rxGrid = OFDMRx(rxSig, prmLTEPDSCH);
% updated for numLayers -> numTx
[dataRx, csrRx, idx_data] = REdemapper_mTx(rxGrid, nS, prmLTEPDSCH);
% MIMO channel estimation
if prmMdl.chEstOn
    chEst = ChanEstimate_mTx(prmLTEPDSCH, csrRx,  csr_ref, prmMdl.chEstOn);
    hD     = ExtChResponse(chEst, idx_data, prmLTEPDSCH);
else
    idealChEst = IdChEst(prmLTEPDSCH, prmMdl, chPathG);
    hD =  ExtChResponse(idealChEst, idx_data, prmLTEPDSCH);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MIMO Receiver based on the mode
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch prmLTEPDSCH.txMode
    case 1
        % Based on Maximum-Combining Ratio (MCR)
        yRec = Equalizer_simo(dataRx, hD, max(nVar), prmLTEPDSCH);
        cwOut = yRec;
        
    case 2
        % Based on Transmit Diversity  with SFBC combiner
        yRec = TDCombine(dataRx, hD, prmLTEPDSCH.numTx, prmLTEPDSCH.numRx);
        cwOut = yRec;
        
    case 3
        yRec = MIMOReceiver_OpenLoop(dataRx, hD, prmLTEPDSCH, nVar);
        % Demap received codeword(s)
        [cwOut, ~] = LayerDemapper(yRec, prmLTEPDSCH);
        
    case 4
        % Based on Spatial Multiplexing
        Wn = PrecoderMatrix(prmMdl.cbIdx, prmLTEPDSCH.numTx, prmLTEPDSCH.numLayers);
        yRec = MIMOReceiver(dataRx, hD, prmLTEPDSCH, nVar, Wn);
        % Demap received codeword(s)
        [cwOut1, cwOut2] = LayerDemapper(yRec, prmLTEPDSCH);
        if  prmLTEPDSCH.numCodeWords==1
            cwOut = cwOut1;
        else
            cwOut = [cwOut1, cwOut2];
        end
end
% Codeword processing
switch nS
    case 0
        outLen = prmLTEDLSCH.TBLenVec(1);
    case 10
        outLen = prmLTEDLSCH.TBLenVec(2);
    otherwise
        outLen = prmLTEDLSCH.TBLenVec(3);
end
C=zeros(2,1);Kplus=C;
for n=1:2
    [C(n), ~, Kplus(n)] =  CblkSegParams(outLen);
end
if prmLTEPDSCH.numCodeWords==1
    dataOut=false(outLen,1);
else
    dataOut=false(2*outLen,1);
end
index=1:outLen;
for n = 1:prmLTEPDSCH.numCodeWords
    % Demodulation
    if prmLTEPDSCH.Eqmode == 3
        % not necessary in case of Sphere Decoding
        demodOut = cwOut(:,n);
    else
        % Demodulate
        demodOut = DemodulatorSoft(cwOut(:,n), prmLTEPDSCH.modType, max(nVar));
    end
    % Descramble received codeword
    rxCW =  Descramble(demodOut, nS, 0, prmLTEPDSCH.maxG);
    % Channel decoding includes CB segmentation, turbo decoding, rate dematching
    [decTbData, ~,~] = TbChannelDecoding(nS, rxCW, Kplus(n), C(n),  prmLTEDLSCH, prmLTEPDSCH);
    % Transport block CRC detection
    [dataOut(index), ~] = CRCdetector(decTbData);
    index = index + outLen;
end