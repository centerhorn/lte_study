function z=zReport_data_rate_average(p2, p1)
y=p2.numCodeWords*(1/10.0e-3)*(p1.TBLenVec(1)+p1.TBLenVec(2)+8*p1.TBLenVec(3));
z=y/1e6;
Mod={'QPSK','16QAM','64QAM'};
Mode={'SIMO','TD','open-loop SM','closed-loop SM'};
fprintf(1,'\nLTE mode       = %1d (%s)\n',p2.txMode, Mode{p2.txMode});
fprintf(1,'MIMO Antenna   = %1d x %1d \n',p2.numTx, p2.numRx);
fprintf(1,'Bandwidth      = %.2f MHz\n',p2.Nrb/5);
fprintf(1,'Modulation     = %s\n',Mod{p2.modType});
fprintf(1,'Coding rate    = %6.4f \n',p1.cRate);
fprintf(1,'Data rate      = %.2f Mbps\n',z);
end

