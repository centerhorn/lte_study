function out = TDEncode(in, numTx)
%   Both SFBC and SFBC with FSTD
persistent hTDEnc;
if isempty(hTDEnc)
    % Use same object for either scheme
    hTDEnc = comm.OSTBCEncoder('NumTransmitAntennas', 2);
end
switch numTx
    case 1
        out=in;
    case 2 % SFBC
        in((2:2:end).') = -conj(in((2:2:end).'));
        % STBC Alamouti
        y= step(hTDEnc, in);       
        % Scale
        out = y/sqrt(2);
    case 4
        inLen=size(in,1);
        y = complex(zeros(inLen, 4));
        in((2:2:end).') = -conj(in((2:2:end).'));
        idx12 = ([1:4:inLen; 2:4:inLen]); idx12 = idx12(:);
        idx34 = ([3:4:inLen; 4:4:inLen]); idx34 = idx34(:);
        y(idx12, [1 3]) = step(hTDEnc, in(idx12));
        y(idx34, [2 4]) = step(hTDEnc, in(idx34));
        out = y/sqrt(2);
end