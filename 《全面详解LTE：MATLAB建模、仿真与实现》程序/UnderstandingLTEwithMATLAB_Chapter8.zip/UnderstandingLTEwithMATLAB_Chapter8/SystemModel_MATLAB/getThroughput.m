function Throughput=getThroughput( ~, CbFlag, SubFrame)
persistent ErrorBlk
if isempty(ErrorBlk)
    ErrorBlk=0;
end
ErrorBlk = ErrorBlk + CbFlag;
Throughput=1-(ErrorBlk/SubFrame);
fprintf(1,'Subframe %4d ; Error Frames = %4d ; BLER = %6.4f ; Throughput = %4.2f \r', ...
        SubFrame, ErrorBlk, (ErrorBlk/SubFrame), Throughput );
end