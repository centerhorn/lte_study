clear all
clear functions
TestCases=[...
    1,1,1;
    1,1,2;
    1,1,4;
    2,2,2;
    2,4,4;
    3,2,2;
    3,4,4;
    4,2,2;
    4,4,4];
NumCases=size(TestCases,1);
Ber_vec_Experiment2=zeros(NumCases,1);
for Experiment = 1:NumCases
    txMode             = TestCases(Experiment,1);   % Transmisson mode one of {1, 2, 3, 4}
    numTx              = TestCases(Experiment,2);    % Number of transmit antennas
    numRx              = TestCases(Experiment,3);   % Number of receive antennas
    copyfile('commlteSystem_params_clean.m','commlteSystem_params.m');
    commlteSystemModel;
    Ber_vec_Experiment2(Experiment)=Measures(1);
end
