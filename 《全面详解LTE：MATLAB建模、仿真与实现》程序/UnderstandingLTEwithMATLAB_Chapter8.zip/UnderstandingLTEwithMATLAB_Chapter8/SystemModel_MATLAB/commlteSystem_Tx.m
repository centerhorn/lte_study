function [txSig, csr_ref, dataIn] = commlteSystem_Tx(nS, prmLTEDLSCH, prmLTEPDSCH, prmMdl)
%#codegen
%  Generate payload
dataIn1 = genPayload(nS,  prmLTEDLSCH.TBLenVec);
% Transport block CRC generation
tbCrcOut1 =CRCgenerator(dataIn1);
% Channel coding includes - CB segmentation, turbo coding, rate matching,
% bit selection, CB concatenation - per codeword
[data1, Kplus1, C1] = TbChannelCoding(tbCrcOut1, nS, prmLTEDLSCH, prmLTEPDSCH);
%Scramble codeword
scramOut = Scramble(data1, nS, 0, prmLTEPDSCH.maxG);
% Modulate
modOut = Modulator(scramOut, prmLTEPDSCH.modType);
%%%%%%%%%%%%%%%%%%%%%%%
% MIMO transmitter based on the mode
%%%%%%%%%%%%%%%%%%%%%%%
numTx=prmLTEPDSCH.numTx;
dataIn= dataIn1;
Kplus=Kplus1;
C=C1;
Wn=complex(ones(numTx,numTx));
switch prmLTEPDSCH.txMode
    case 1  % Mode 1: Single-antenna (SIMO mode)
        PrecodeOut =modOut;
         
    case 2   % Mode 2: Transmit diversity
        % TD with SFBC
        PrecodeOut = TDEncode(modOut(:,1),prmLTEPDSCH.numTx);
        
    case 3   % Mode 3: Open-loop Spatial multiplexing
        LayerMapOut = LayerMapper(modOut, [], prmLTEPDSCH);
        % Precoding
        PrecodeOut = SpatialMuxPrecoderOpenLoop(LayerMapOut, prmLTEPDSCH);
        
    case 4    % Mode 4: Closed-loop Spatial multiplexing
        if  prmLTEPDSCH.numCodeWords==1
            % Layer mapping
            LayerMapOut = LayerMapper(modOut, [], prmLTEPDSCH);
        else
            dataIn2 = genPayload(nS,  prmLTEDLSCH.TBLenVec);
            tbCrcOut2 =CRCgenerator(dataIn2);
            [data2, Kplus2, C2] = TbChannelCoding(tbCrcOut2, nS, prmLTEDLSCH, prmLTEPDSCH);
            scramOut2 = Scramble(data2, nS, 0, prmLTEPDSCH.maxG);
            modOut2 = Modulator(scramOut2, prmLTEPDSCH.modType);
            % Layer mapping
            LayerMapOut = LayerMapper(modOut, modOut2, prmLTEPDSCH);
            dataIn= [dataIn1;dataIn2];
            Kplus=[Kplus1;Kplus2];
            C=[C1; C2];
        end
        % Precoding
        usedCbIdx = prmMdl.cbIdx;
        [PrecodeOut, Wn] = SpatialMuxPrecoder(LayerMapOut, prmLTEPDSCH, usedCbIdx);
end
% Generate Cell-Specific Reference (CSR) signals
numTx=prmLTEPDSCH.numTx;
csr = CSRgenerator(nS, numTx);
csr_ref=complex(zeros(2*prmLTEPDSCH.Nrb, 4, numTx));
for m=1:numTx
    csr_pre=csr(1:2*prmLTEPDSCH.Nrb,:,:,m);
    csr_ref(:,:,m)=reshape(csr_pre,2*prmLTEPDSCH.Nrb,4);
end
% Resource grid filling
txGrid = REmapper_mTx(PrecodeOut, csr_ref, nS, prmLTEPDSCH);
% OFDM transmitter
txSig = OFDMTx(txGrid, prmLTEPDSCH);