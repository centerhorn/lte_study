function CheckAntennaConfig(numTx, numRx, txMode, numCodeWords)
if txMode ==1
    Allowed=[1,1;1,2;1,3;1,4;];
else
    Allowed=[2,2;4,4];
end
MyConfig=[numTx,numRx];
tmp=MyConfig(ones(size(Allowed,1),1),:);
err=sum(abs(tmp-Allowed),2);
if isempty(find(~err,1))
    disp('Wrong antenna configuration! Allowable configurations are:');
    disp(Allowed);
    error('Please change number of Tx and/or Rx antennas!');
end
if ( (txMode ~= 4) && (numCodeWords ~= 1))
    string =['Transmission mode ',num2str(txMode),' only allows 1 codeword'];
    disp(string);
    error('Please change number of codewords to 1 !');
end
if ( (numCodeWords> 2) || (numCodeWords <1) )
    error('Only 1 or 2 codewords allowed !');
end

