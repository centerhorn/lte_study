%% Initialization
copyfile('commlteSystem_params_throughput.m','commlteSystem_params.m');
%% Delay spread smaller than Cyclic Prefix Length
clear functions
fprintf(1,'Examining throughput instead of BER or Block Error Rate (BLER)\n');
commlteSystemModel_Throughput;

