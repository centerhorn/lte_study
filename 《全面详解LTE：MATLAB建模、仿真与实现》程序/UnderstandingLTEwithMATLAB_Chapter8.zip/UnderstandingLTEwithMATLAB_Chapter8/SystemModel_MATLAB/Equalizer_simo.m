function [y, num, denum]  = Equalizer_simo(in, hD, nVar, prmLTE)
%#codegen
EqMode=prmLTE.Eqmode;
numTx=prmLTE.numTx;
numRx=size(hD,2);
if (numTx>1), error('Equalizer_simo: dediccated to single transmit antenna case.');end
if numRx==1
    switch EqMode
        case 1,   % Zero forcing
            num = conj(hD);
            denum=conj(hD).*hD;
        case 2,   % MMSE
            num = conj(hD);
            denum=conj(hD).*hD+nVar;
    end
else
    num = conj(hD);
    denum=conj(hD).*hD;
end
y = sum(in .*num,2)./sum(denum,2);