clear all
TestCase={...
    'flat', 'Low',0,'flat', 'Medium',5,'flat', 'High',70,...
    'frequency-selective', 'Low',0,'frequency-selective', 'Medium',5,'frequency-selective', 'High',70,...
    'EPA 5Hz', 'Low',5,'EPA 5Hz', 'Medium',5,'EPA 5Hz', 'High',5,...
    'EVA 5Hz', 'Low',5,'EVA 5Hz', 'Medium',5,'EVA 5Hz', 'High',5,...
    'EVA 70Hz', 'Low',70,'EVA 70Hz', 'Medium',70,'EVA 70Hz', 'High',70,...
    };
NumCases=15;
BerRefCh=zeros(NumCases,1);
for n = 1:NumCases
    clear functions;
    chanMdl             = TestCase{3*n-2};      % Channel model
    corrLvl                = TestCase{3*n-1};    % Antenna correlations
    Doppler               = TestCase{3*n};          % Maximum Doppler shift  
    fprintf(1,'Channel model = %s Max. Doppler shift = %d Correlation = %s\n',  chanMdl,   Doppler,  corrLvl);
    copyfile('commlteSystem_params_referenceChannels.m','commlteSystem_params.m');
    commlteSystemModel;
    BerRefCh(n)=Measures(1);
end
