function hD=gridResponse_averageSlot(hp, Nrb, Nrb_sc, Ndl_symb, Edges)
% Average over the two same Freq subcarriers, and then interpolate between
% them - get all estimates and then repeat over all columns (symbols).
% The interpolation assmues NCellID = 0.
% Time average two pilots over the slots, then interpolate (F)
% between the 4 averaged values, repeat for all symbols in sframe
Separation=3;
hD = complex(zeros(Nrb*Nrb_sc, Ndl_symb*2));
N=numel(Edges);
% Compute channel response over all resource elements of OFDM symbols
switch N
    case 2
        % Interpolate between subcarriers
        Index=1:Ndl_symb;
        for n=1:N 
        E=Edges(n);Edge=[E, 5-E];
        y = InterpolateCsr(hp(:,n),  2* Separation, Edge);
        % Repeat between OFDM symbols in each slot
        yR=y(:,ones(1,Ndl_symb));
        hD(:,Index)=yR;
        Index=Index+Ndl_symb;
        end
    case 4
        Edge=[0 2];
        h1_a_mat = [hp(:,1),hp(:,2)].';
        h1_a = h1_a_mat(:);
        h2_a_mat = [hp(:,3),hp(:,4)].';
        h2_a = h2_a_mat(:);
        hp_a=[h1_a,h2_a];
        Index=1:Ndl_symb;
        for n=1:size(hp_a,2) 
        y = InterpolateCsr(hp_a(:,n),  Separation, Edge);
        % Repeat between OFDM symbols in each slot
        yR=y(:,ones(1,Ndl_symb));
        hD(:,Index)=yR;
        Index=Index+Ndl_symb;
        end
    otherwise
        error('Wrong Edges parameter for function gridResponse.');
end