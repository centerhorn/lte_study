function [prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteSystem_initialize(txMode, ...
chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, Doppler, corrLvl, ...
    chEstOn, numCodeWords, enPMIfback, cbIdx)
% Create the parameter structures
% PDSCH parameters
CheckAntennaConfig(numTx, numRx, txMode, numCodeWords);
prmLTEPDSCH = prmsPDSCH(txMode, chanBW, contReg, modType, numTx, numRx, numCodeWords,Eqmode);
[SymbolMap, Constellation]=ModulatorDetail(prmLTEPDSCH.modType);
prmLTEPDSCH.SymbolMap=SymbolMap;
prmLTEPDSCH.Constellation=Constellation;
% DLSCH parameters
prmLTEDLSCH = prmsDLSCH(cRate,maxIter, fullDecode, prmLTEPDSCH);
% Channel parameters
chanSRate   = prmLTEPDSCH.chanSRate;
DelaySpread = 2* prmLTEPDSCH.cpLenR;
 prmMdl = prmsMdl(chanSRate,  DelaySpread, chanMdl, Doppler, numTx, numRx, ...
    corrLvl, chEstOn, enPMIfback, cbIdx);