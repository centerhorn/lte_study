%% Experiment of sweeping SNR values for all 3 modulation schemes
clear functions
for modType= 1:3   % [1,2,3] maps to ['QPSK','16QAM','64QAM']
    copyfile('commlteSystem_params_SnrVec.m','commlteSystem_params.m');
    copyfile('commlteSystem_initialize_lowCP.m','commlteSystem_initialize.m');
    SnrVec=getSnrVector(modType,7);
    Bers=zeros(size(SnrVec));
    Num=numel(SnrVec);
    for n=1:Num
        txMode             = 4;   % Transmisson mode one of {1, 2, 3, 4}
        numTx              = 2;    % Number of transmit antennas
        numRx              = 2;   % Number of receive antennas
        snrdB=SnrVec(n);
        commlteSystemModel;
        Bers(n)=Measures(1);
    end
    pfx=num2str(modType);
    eval(['Bers',pfx,' = Bers;']);
    eval(['SnrVec',pfx,' = SnrVec;']);
end
save Chapter8_Ber_SnrVec Bers1 Bers2 Bers3 SnrVec1 SnrVec2 SnrVec3