function hD=ExtChResponse(chEst, idx_data, prmLTE)
%#codegen
numTx = prmLTE.numTx;
numRx = prmLTE.numRx;
if (numTx==1)
    hD=complex(zeros(numel(idx_data),numRx));
    for n=1:numRx
        tmp=chEst(:,:,n);
        hD(:,n)=tmp(idx_data);
    end
else
    hD=complex(zeros(numel(idx_data),numTx,numRx));
    for n=1:numRx
        for m=1:numTx
            tmp=chEst(:,:,m,n);
            hD(:,m,n)=tmp(idx_data);
        end
    end
end