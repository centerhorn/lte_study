function hD=gridResponse_averageSubframe(hp, Ndl_symb, Edges)
% Average over the two same Freq subcarriers, and then interpolate between
% them - get all estimates and then repeat over all columns (symbols).
% The interpolation assmues NCellID = 0.
% Time average two pilots over the slots, then interpolate (F)
% between the 4 averaged values, repeat for all symbols in sframe
Separation=3;
N=numel(Edges);
Edge=[0 2];
% Compute channel response over all resource elements of OFDM symbols
switch N
    case 2
        h1_a_mat = hp.';
        h1_a = h1_a_mat(:);
        % Interpolate between subcarriers
        y = InterpolateCsr(h1_a,  Separation, Edge);
        % Repeat between OFDM symbols
        hD=y(:,ones(1,Ndl_symb*2));
    case 4
        h1_a1 = mean([hp(:, 1), hp(:, 3)],2);
        h1_a2 = mean([hp(:, 2), hp(:, 4)],2);
        h1_a_mat = [h1_a1 h1_a2].';
        h1_a = h1_a_mat(:);
        % Interpolate between subcarriers
        y = InterpolateCsr(h1_a,  Separation, Edge);
        % Repeat between OFDM symbols
        hD=y(:,ones(1,Ndl_symb*2));
    otherwise
        error('Wrong Edges parameter for function gridResponse.');
end