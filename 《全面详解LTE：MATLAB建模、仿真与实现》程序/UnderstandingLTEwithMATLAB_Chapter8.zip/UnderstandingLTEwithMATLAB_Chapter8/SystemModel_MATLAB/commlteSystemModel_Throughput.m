% Script for LTE (mode 1 to 4, downlink transmission)
%
% Single or double codeword transmission for mode 4
%
clear functions
%%
commlteSystem_params;
[prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteSystem_initialize(txMode, ...
    chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, Doppler, corrLvl, ...
    chEstOn, numCodeWords, enPMIfback, cbIdx);
clear txMode chanBW contReg modType Eqmode numTx numRx cRate maxIter fullDecode chanMdl Doppler corrLvl chEstOn numCodeWords enPMIfback cbIdx 
%%
disp('Simulating the LTE Downlink - Modes 1 to 4');
zReport_data_rate_average(prmLTEPDSCH, prmLTEDLSCH); 
fprintf(1,'SNR (dB)       = %3d\n', snrdB); 
hPBer = comm.ErrorRate;
%% Simulation loop
tic;
SubFrame =1;
nS = 0; % Slot number, one of [0:2:18]
Measures = zeros(3,1); %initialize BER output
while (Measures(3) < maxNumBits) && (Measures(2) < maxNumErrs)
    %% Transmitter
    [txSig, csr, dataIn] = commlteSystem_Tx(nS, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
     %% Channel model
     [rxSig, chPathG, ~]  = commlteSystem_Channel(txSig, snrdB, prmLTEPDSCH,  prmMdl );
     %% Receiver
     nVar=(10.^(0.1.*(-snrdB)))*ones(1,size(rxSig,2));
     [dataOut, dataRx, yRec, CbFlag] = commlteSystem_Rx_Throughput(nS, csr, rxSig, chPathG, nVar, ...
         prmLTEDLSCH, prmLTEPDSCH, prmMdl);
    %% Calculate  bit errors
    Measures = step(hPBer, dataIn, dataOut);
    %% Visualize results
    if (visualsOn && prmLTEPDSCH.Eqmode~=3)
        zVisualize( prmLTEPDSCH, txSig, rxSig, yRec, dataRx, csr, nS);
    end;  
   Throughput=getThroughput( Measures(1), CbFlag, SubFrame);
    %% Update subframe number
    nS = nS + 2; if nS > 19, nS = mod(nS, 20); end;
    SubFrame =SubFrame +1;
end
reset(hPBer);
toc;