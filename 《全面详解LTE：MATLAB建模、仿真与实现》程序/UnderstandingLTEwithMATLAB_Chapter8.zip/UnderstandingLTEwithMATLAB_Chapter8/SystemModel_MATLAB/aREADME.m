% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter8\SystemModel_MATLAB)
%
% This folder contains multiple MATLAB scripts (testbenches) that showcase how
% to execute and verify proper operation of a LTE PHY System model covering
% user-plane details of transmission modes 1 to 4 as presented in chapter 8 of
% the book "Understanding LTE with MATLAB"
% 
% There are all together 8 experiments that cover the system modeling results presented in chapter eight: 
% 1. commlteSystemExperiment_SnrVec.m                        : to examine the BER as a Function of SNR
% 2. commlteSystemExperiment_Throughput.m                : to examine the throughput of the LTE system model    
% 3. commlteSystemExperiment_TxModeClean.m             : to examine effects of Transmission Modes in low-distortion channels    
% 4. commlteSystemExperiment_TxModeDistorted.m       : to examine effects of Transmission Modes in high-distortion channels
% 5. commlteSystemExperiment_channelEst.m                 : to examine effects of Channel-Estimation Techniques
% 6. commlteSystemExperiment_delaySpread.m               : to examine effects of Channel Delay Spread and Cyclic Prefix length
% 7. commlteSystemExperiment_mimoReceiver.m            : to examine effects of MIMO Receiver Algorithms
% 8. commlteSystemExperiment_referenceChannels.m     : to examine effects of Channel Models 
% How to run demos:
% type each <experiment name>  such as commlteSystemExperiment_SnrVec at the MATLAB command prompt
% Associated with each experiment is a parameter file that sets relevant
% system parameters. For example, commlteSystem_params_SnrVec.m sets the
% parameters for the commlteSystemExperiment_SnrVec.m experiment, which sweeps trough SNR values to compute the BER
% In each experiment, ss the system model is executed for various parameters, measueres such as
% BER and throughput are computed and reported.
% Exploration:
% As always by chaging parameters such as maxNumErrs and maxNumBits,  
% you get longer or shorter experiment time. By changing the link SNR, the parameter snrdB, you can see the efect of AWGN noise
% on the overall performance. 