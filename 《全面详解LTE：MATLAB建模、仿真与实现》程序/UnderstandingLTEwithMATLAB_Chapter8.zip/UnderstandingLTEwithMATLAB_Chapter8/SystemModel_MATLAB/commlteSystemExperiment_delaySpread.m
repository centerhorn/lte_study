%% Initialization
copyfile('commlteSystem_params_delaySpread.m','commlteSystem_params.m');
%% Delay spread smaller than Cyclic Prefix Length
clear functions
copyfile('commlteSystem_initialize_lowCP.m','commlteSystem_initialize.m');
fprintf(1,'Delay spread smaller than Cyclic Prefix Length\n');
commlteSystemModel;
BerLowCP=Measures(1);
%% Delay spread larger than Cyclic Prefix Length
clear functions
copyfile('commlteSystem_initialize_highCP.m','commlteSystem_initialize.m');
fprintf(1,'Delay spread larger than Cyclic Prefix Length\n');
commlteSystemModel;
BerhighCP=Measures(1);

