%% Initialization
copyfile('commlteSystem_params_mimoReceiver.m','commlteSystem_params.m');
copyfile('commlteSystem_initialize_lowCP.m','commlteSystem_initialize.m');
%% Zero Forcing algorithm (ZF)
clear functions
fprintf(1,'Zero Forcing algorithm (ZF)\n');
Eqmode           = 1;      % Type of equalizer used [1,2,3] for ['ZF', 'MMSE','Sphere Decoder']
commlteSystemModel;
BerZ=Measures(1);
%% Minimum Mean Squaree Error algorithm (MMSE)
clear functions
fprintf(1,'Minimum Mean Squaree Error algorithm (MMSE)\n');
Eqmode           = 2;      % Type of equalizer used [1,2,3] for ['ZF', 'MMSE','Sphere Decoder']
commlteSystemModel;
BerM=Measures(1);
%% Sphere Decoder algorithm (SD)
clear functions
fprintf(1,'Sphere Decoder algorithm (SD)\n');
Eqmode           = 3;      % Type of equalizer used [1,2,3] for ['ZF', 'MMSE','Sphere Decoder']
commlteSystemModel;
BerS=Measures(1);
