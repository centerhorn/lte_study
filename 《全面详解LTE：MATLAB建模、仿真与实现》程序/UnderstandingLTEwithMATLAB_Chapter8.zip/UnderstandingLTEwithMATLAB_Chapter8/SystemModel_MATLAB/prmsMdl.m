function prmMdl = prmsMdl( chanSRate,  DelaySpread,  chanMdl, Doppler, numTx, numRx, ...
    corrLvl, chEstOn, enPMIfback, cbIdx)
prmMdl.chanMdl = chanMdl;
prmMdl.AntConfig=char([48+numTx,'x',48+numRx]);
prmMdl.Doppler=Doppler;
prmMdl.corrLevel = corrLvl;
switch chanMdl
    case 'flat',
        prmMdl.PathDelays = 0*(1/chanSRate);
        prmMdl.PathGains  = 0;
        prmMdl.ChannelType =1;
    case 'frequency-selective',
        prmMdl.PathDelays = floor(linspace(0,DelaySpread,5))*(1/chanSRate);
        prmMdl.PathGains  = [0 -3 -6 -8 -17.2];
        prmMdl.ChannelType =1;
    case 'EPA 0Hz'
         [prmMdl.PathDelays, prmMdl.PathGains]= getPathDelayGains(chanMdl);
        prmMdl.ChannelType =1;
    otherwise
        prmMdl.ChannelType =2;
        [prmMdl.PathDelays, prmMdl.PathGains]= getPathDelayGains(chanMdl);
end
prmMdl.chEstOn = chEstOn;
prmMdl.enPMIfback = enPMIfback;
prmMdl.cbIdx = cbIdx;
% Correlation Matrix calculations
[xCor_tx, xCor_rx]=getCorrMatrix(corrLvl, numTx, numRx);
prmMdl.xCor_tx = xCor_tx;
prmMdl.xCor_rx = xCor_rx;
end
%% Helper functions
%
function [xCor_tx, xCor_rx]=getCorrMatrix(corrLvl, numTx, numRx)
switch corrLvl
    case 'Low'
        r1=0;
        r2=0;
    case 'Medium'
        r1=0.3;
        r2=0.9;
    case 'High'
        r1=0.9;
        r2=0.9;
end
xCor_tx = getCorrelationMatrix(numTx, r1);
xCor_rx = getCorrelationMatrix(numRx, r2);
end
%
function R = getCorrelationMatrix(NumAntennas, r)
switch NumAntennas
    case 1
        R = 1;
    case 2
        R = [1 r; r 1];
    case 4
        R = [1          r^(1/9)    r^(4/9)    r;       ...
            (r^(1/9))  1          r^(1/9)    r^(4/9); ...
            (r^(4/9))  (r^(1/9))  1          r^(1/9); ...
            r          (r^(4/9))  (r^(1/9))  1];
end
end