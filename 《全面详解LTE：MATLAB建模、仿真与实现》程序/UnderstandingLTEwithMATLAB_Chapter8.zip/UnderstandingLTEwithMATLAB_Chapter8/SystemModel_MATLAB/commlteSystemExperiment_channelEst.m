%% Initialization
copyfile('commlteSystem_params_channelEst.m','commlteSystem_params.m');
copyfile('commlteSystem_initialize_lowCP.m','commlteSystem_initialize.m');
%% Ideal Channel estimation
clear functions
fprintf(1,'Ideal Channel estimation\n');
chEstOn           = 0;          % use channel estimation or ideal channel
commlteSystemModel;
Ber00=Measures(1);
%% Channel estimation based on interpolation
clear functions
fprintf(1,'Channel estimation based on interpolation\n');
chEstOn           = 1;          % use channel estimation or ideal channel
commlteSystemModel;
Ber01=Measures(1);
%% Channel estimation based on averaging over each slot
clear functions
fprintf(1,'Channel estimation based on averaging over each slot\n');
chEstOn           = 2;          % use channel estimation or ideal channel
commlteSystemModel;
Ber02=Measures(1);
%% Channel estimation based on averaging over each subframe
clear functions
fprintf(1,'Channel estimation based on averaging over each subframe\n');
chEstOn           = 3;          % use channel estimation or ideal channel
commlteSystemModel;
Ber03=Measures(1);