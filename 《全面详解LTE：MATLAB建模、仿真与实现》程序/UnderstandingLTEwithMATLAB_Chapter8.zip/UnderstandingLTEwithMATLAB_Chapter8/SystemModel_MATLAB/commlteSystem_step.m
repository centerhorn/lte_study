function [dataIn, dataOut, txSig, rxSig, dataRx, yRec, csr]...
    = commlteSystem_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl)

%% Transmitter
[txSig, csr, dataIn] = commlteSystem_Tx(nS, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
%% Channel model
[rxSig, chPathG, ~]  = commlteSystem_Channel(txSig, snrdB, prmLTEPDSCH,  prmMdl );
%% Receiver
nVar=(10.^(0.1.*(-snrdB)))*ones(1,size(rxSig,2));
[dataOut, dataRx, yRec] = commlteSystem_Rx(nS, csr, rxSig, chPathG, nVar, ...
    prmLTEDLSCH, prmLTEPDSCH, prmMdl);
end