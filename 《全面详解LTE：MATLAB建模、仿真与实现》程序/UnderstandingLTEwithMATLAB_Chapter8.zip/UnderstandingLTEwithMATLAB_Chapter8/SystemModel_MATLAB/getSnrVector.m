function y=getSnrVector(modType, MaxIter)
switch modType
    case 1
        MinSnr = 0;
        MaxSnr = 8;
    case 2
        MinSnr = 8;
        MaxSnr = 16;
    case 3
        MinSnr = 16;
        MaxSnr = 24;
end
y=fix(linspace(MinSnr,MaxSnr, MaxIter));