% This directory is composed of 3 distinct sub-directories.
% For a detailed description of how to perform experiments and run
% simulation testbenches of each section, please go to each sub-directory and
% consult its own aREADME.m file
