function y=Transceiver0_fixed2(u)
%% Constants
trellis=poly2trellis(7, [133 171]);
polynomial=[1 1 zeros(1, 16) 1 1 0 0 0 1 1];
%% Initializations
persistent Modulator  DeModulator ConvEncoder Viterbi CRCGen CRCDet FFT IFFT
if isempty(Modulator)
    Modulator       = comm.QPSKModulator('BitInput',true,'OutputDataType','Custom');
    DeModulator   =  comm.QPSKDemodulator('BitOutput',true, 'OutputDataType', 'Smallest unsigned integer');
    ConvEncoder   =  comm.ConvolutionalEncoder('TerminationMethod','Truncated', 'TrellisStructure', trellis);
    Viterbi             = comm.ViterbiDecoder('TrellisStructure', trellis, 'InputFormat','Hard',...
        'TerminationMethod','Truncated', 'OutputDataType','logical');
    CRCGen          = comm.CRCGenerator('Polynomial', polynomial);
    CRCDet           = comm.CRCDetector   ('Polynomial', polynomial);
    FFT  = dsp.FFT;
    IFFT = dsp.IFFT;
end
tb               = step(CRCGen , u);                       % CRC generator
cod_sig      = step(ConvEncoder , tb);              % Convolutional encoder
mod_sig     = step(Modulator, cod_sig);          % QPSK Modulator
sig              = step(IFFT, mod_sig);                   % Perform IFFT
rec              = step(FFT, sig);                             % Perform FFT
demod        = step(DeModulator, rec);            % QPSK Demodulator
dec             = step(Viterbi , demod);                % Viterbi decoder
y                 = step(CRCDet , dec);                    % CRC detector