% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter10\3rd_fft)
%
% This folder contains a series of MATLAB functions and scripts that showcase 
% Support for Fixed-Point Data in a simple transceiver function
% as presented in chapter 10 of the "Understanding LTE with MATLAB"
%
% How to run the demos:
% Double click on the MATLAB Coder project files:  
% MyFFT0_fixed.prj   
% and observe the Project Code Generation Issues report
% when you use fft and ifft functions to process fixed-point data.
% Note by using dsp.FFT and dsp.IFFT System objects, which support
% fixed-point data, the issues get resolved and code generation for fixed-point version of
% transceiver function is successful.