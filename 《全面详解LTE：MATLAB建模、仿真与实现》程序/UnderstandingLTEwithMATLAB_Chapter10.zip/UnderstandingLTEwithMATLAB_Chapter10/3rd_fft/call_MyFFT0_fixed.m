u=randn(2024,1)>0;                            % Input
y=Transceiver0_fixed(u);

