function y=Transceiver0_fixed(u)
%% Constants
trellis=poly2trellis(7, [133 171]);
polynomial=[1 1 zeros(1, 16) 1 1 0 0 0 1 1];
%% Initializations
persistent Modulator  DeModulator ConvEncoder Viterbi CRCGen CRCDet
if isempty(Modulator)
    Modulator       = comm.QPSKModulator('BitInput',true,'OutputDataType','Custom');
    DeModulator   =  comm.QPSKDemodulator('BitOutput',true);
    ConvEncoder   =  comm.ConvolutionalEncoder('TerminationMethod','Truncated', 'TrellisStructure', trellis);
    Viterbi             = comm.ViterbiDecoder('TrellisStructure', trellis, 'InputFormat','Hard','TerminationMethod','Truncated');
    CRCGen          = comm.CRCGenerator('Polynomial', polynomial);
    CRCDet           = comm.CRCDetector   ('Polynomial', polynomial);
end
tb               = step(CRCGen , u);                       % CRC generator
cod_sig      = step(ConvEncoder , tb);              % Convolutional encoder
mod_sig     = step(Modulator, cod_sig);          % QPSK Modulator
sig              = ifft(mod_sig);                             % Perform IFFT
rec              = fft(sig);                                       % Perform FFT
demod        = step(DeModulator, rec);            % QPSK Demodulator
dec             = step(Viterbi , demod);                % Viterbi decoder
y                 = step(CRCDet , dec);                    % CRC detector