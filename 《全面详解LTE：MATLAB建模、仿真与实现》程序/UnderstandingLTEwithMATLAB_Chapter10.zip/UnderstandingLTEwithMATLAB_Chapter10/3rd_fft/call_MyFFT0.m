u=randn(2024,1);                            % Input
y=Transceiver0(u);

