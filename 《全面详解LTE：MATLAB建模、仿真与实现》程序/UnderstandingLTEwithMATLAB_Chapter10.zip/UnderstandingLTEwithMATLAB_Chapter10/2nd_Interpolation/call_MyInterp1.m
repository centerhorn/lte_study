N=200;
X=(0:1:N-1)';
Y=exp(-1j*pi*X/N);
z1=MyInterp1(Y);      % Function call

