N=200;
X=(0:1:N-1)';
Y=exp(-1j*pi*X/N);
z0=MyInterp0(Y);      % Function call

