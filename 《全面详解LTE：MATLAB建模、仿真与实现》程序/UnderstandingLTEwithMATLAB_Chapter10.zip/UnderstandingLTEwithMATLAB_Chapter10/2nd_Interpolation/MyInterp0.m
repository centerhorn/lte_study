function out = MyInterp0(y)
%#codegen
UpsampFactor=6;
out=interp(y,UpsampFactor);