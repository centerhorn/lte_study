function out = MyInterp1(y)
%#codegen
UpsampFactor=6;
delta=y(end)-y(end-1);
z=[y;y(end)+delta];
InterpIndex=(1:(1/UpsampFactor):numel(z))';
x=interp1( z,InterpIndex);
out=x(1:end-1);