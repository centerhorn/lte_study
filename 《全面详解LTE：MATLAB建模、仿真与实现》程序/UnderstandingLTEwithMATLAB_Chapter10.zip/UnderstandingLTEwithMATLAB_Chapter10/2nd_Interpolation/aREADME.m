% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter10\2nd_Interpolation)
%
% This folder contains a series of MATLAB functions and scripts that showcase 
% How to verify readiness of a function for Code Generation applied to 2 versions of the pilot interpolation functions 
% as presented in chapter 10 of the "Understanding LTE with MATLAB"
%
% How to run the demos:
% Double click on the MATLAB Coder project file: MyInterp.prj
% and observe the Project Code Generation Issues report
% Then double click on the MATLAB Coder project file: MyInterp1.prj
% Note how by using a function where every MATLAB command supports code generation 
% the issues are resolved and code generation proceeds correctly. 