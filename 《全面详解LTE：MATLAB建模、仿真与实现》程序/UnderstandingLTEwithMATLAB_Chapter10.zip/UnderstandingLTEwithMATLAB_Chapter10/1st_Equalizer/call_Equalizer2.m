u=complex(single(randn(72,14)));                                             % First input
coef= single(randn(72,14)) +1j * single(randn(72,14));            % Second input 
y=Equalizer(u,coef);                                                                   % Function call

