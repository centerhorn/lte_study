function y = Equalizer( u, coefficients)
%#codegen
% Equalizer using element-by-element multiplication
y = u.*coefficients;
end

