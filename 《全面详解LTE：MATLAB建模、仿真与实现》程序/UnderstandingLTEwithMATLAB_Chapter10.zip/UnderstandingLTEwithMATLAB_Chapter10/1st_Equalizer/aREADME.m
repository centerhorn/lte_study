% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter10\1st_Equalizer)
%
% This folder contains a series of MATLAB functions and scripts that showcase 
% How to Generate C Code from MATLAB function in either of two ways:
% 1. Using a MATLAB Command or 2. Using the MATLAB Coder Project 
% as presented in chapter 10 of the "Understanding LTE with MATLAB"
%
% How to run the demos:
% 1. type build_Equalizer in MATLAB command line 
% or
% 2. double click on the MATLAB Coder project file: MyEqualizer.prj
% Follow the instructions and details in the chapter 10.