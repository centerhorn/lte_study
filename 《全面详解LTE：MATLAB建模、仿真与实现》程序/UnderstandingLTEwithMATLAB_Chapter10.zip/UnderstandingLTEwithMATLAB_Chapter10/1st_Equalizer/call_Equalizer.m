u=1:100;                        % First input
coef=cos(u);                  % Second input 
y=Equalizer(u,coef);      % Function call

