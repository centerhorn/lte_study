%% Using a MATLAB Command to generate C code from MATLAB function

%% build the mex function
call_Equalizer
% call_Equalizer2
 codegen �args {u , coef} Equalizer.m
%% generate stanalone C code
% call_Equalizer
call_Equalizer2
codegen �args {u , coef} Equalizer.m �config:lib �report