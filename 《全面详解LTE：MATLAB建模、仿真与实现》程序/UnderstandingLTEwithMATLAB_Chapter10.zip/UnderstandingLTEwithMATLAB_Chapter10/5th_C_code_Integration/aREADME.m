% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter10\3rd_fft)
%
% This folder contains a series of MATLAB and C functions and scripts that showcase 
% how integrate C code generated from a MATLAB function into existing C/C++
% executable as presented in chapter 10 of the "Understanding LTE with MATLAB"
%
% This folder contains demo files to perform a 4-step process.
% 
% How to run the demos:
% 1. First, run the script: 
% zPDCCH_v9_build
% to create a compiled MATLAB MEX executable for our algorithm.
% The output is the MEX function zPDCCH_v9.mexw64
% 2. Execute the MATLAB testbench 
% zPDCCH_v8_MATLAB_testbench
% to generate reference numerical
% results and reference execution times.
% 3. Generate C code from the function by executing zPDCCH_v8_build.prj MATLAB Coder project.
% All the sources and header files(*.c and *.h) will be generated in a directory under this folder called
% .\codegen\lib\zPDCCH_v8
% 4. Use a C/C++ main function (main.c) and that calls the generated C code and a simple Makefile (Makefile) 
% to compile and link the C main function and the generated C code of the function. 
% They are both placed under this folder called
% .\codegen\lib\zPDCCH_v8
% The result will be an executable that can run on a computer. This executable is the C testbench.
% 6. Run the generated executable (the C testbench) outside the MATLAB environment. 
% Execute the Windows SDK 7.1 Comand prompt .
% In the command prompt Go to the directory: cd  .\codegen\lib\zPDCCH_v8
% Clean the old compiled C objects by running the command >> gmake -k clean -f Makefile
% Recompile C objects and generate C executable by running the command >> gmake -k all -f Makefile
% Verify that the C testbench generates the same numerical results as the reference MATLAB
% testbench by calling the comand:
% >> main_win.exe 10000000 10000000 
% Finally, compare the execution time of the C testbench to a MATLAB testbench
% processing the same test cases.