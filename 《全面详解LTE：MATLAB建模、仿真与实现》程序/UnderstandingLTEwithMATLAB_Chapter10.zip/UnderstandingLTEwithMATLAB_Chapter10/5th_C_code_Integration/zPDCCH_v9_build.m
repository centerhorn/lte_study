EbNo=0; 
maxNumErrs=1e6; 
maxNumBits=1e6;
codegen zPDCCH_v8 -args {EbNo, maxNumErrs, maxNumBits} -o zPDCCH_v9