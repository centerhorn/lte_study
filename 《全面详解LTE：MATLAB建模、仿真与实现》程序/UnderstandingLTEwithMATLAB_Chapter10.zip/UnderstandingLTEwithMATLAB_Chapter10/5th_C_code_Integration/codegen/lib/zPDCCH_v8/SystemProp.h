/*
 * SystemProp.h
 *
 * Code generation for function 'SystemProp'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __SYSTEMPROP_H__
#define __SYSTEMPROP_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void c_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj);
extern void d_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const unsigned int value[625]);
extern void e_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value[636]);
extern void f_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value[280]);
extern void g_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value[40]);
extern void h_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, double value);
extern void i_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value[8]);
extern void j_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, double value);
extern void k_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, double value);
#endif
/* End of code generation (SystemProp.h) */
