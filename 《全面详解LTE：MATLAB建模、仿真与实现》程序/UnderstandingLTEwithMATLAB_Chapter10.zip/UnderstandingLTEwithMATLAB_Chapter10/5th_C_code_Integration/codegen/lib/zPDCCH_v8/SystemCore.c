/*
 * SystemCore.c
 *
 * Code generation for function 'SystemCore'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "SystemCore.h"
#include "Nondirect1.h"
#include "setup.h"
#include "zPDCCH_v8_emxutil.h"
#include "xor.h"
#include "AWGNChannel.h"
#include "FadingChannel.h"
#include "SystemProp.h"
#include "filter.h"

/* Function Declarations */
static int ACS_fxp_s32_s32(int numStates, int pTempMetric[], int alpha, const
  int pBMet[], int pStateMet[], unsigned int pTbState[], unsigned int pTbInput[],
  const int pTbPtr[], const unsigned int pNxtSt[], const unsigned int pEncOut[],
  int maxValue);
static void SystemCore_initializeInputSizes(comm_MIMOChannel *obj);
static void SystemCore_setup(comm_GoldSequence_2 *obj);
static void b_SystemCore_setup(comm_internal_GoldSequenceXor *obj);
static void b_eml_rand_mt19937ar(unsigned int b_state[625]);
static void c_SystemCore_setup(comm_MIMOChannel *obj);
static void d_SystemCore_setup(comm_internal_GoldSequenceXor_1 *obj);
static void e_SystemCore_setup(comm_GoldSequence_3 *obj);

/* Function Definitions */
static int ACS_fxp_s32_s32(int numStates, int pTempMetric[], int alpha, const
  int pBMet[], int pStateMet[], unsigned int pTbState[], unsigned int pTbInput[],
  const int pTbPtr[], const unsigned int pNxtSt[], const unsigned int pEncOut[],
  int maxValue)
{
  int minstate;
  int renorm;
  int stateIdx;
  int currmetric;
  int inpIdx;
  int q0;
  int nextStateIdx;
  int qY;
  renorm = maxValue;
  for (stateIdx = 0; stateIdx < numStates; stateIdx++) {
    pTempMetric[stateIdx] = maxValue;
  }

  for (stateIdx = 0; stateIdx < numStates; stateIdx++) {
    currmetric = pStateMet[stateIdx];
    for (inpIdx = 0; inpIdx < alpha; inpIdx++) {
      q0 = inpIdx * numStates + stateIdx;
      nextStateIdx = (int)pNxtSt[q0];
      q0 = pBMet[pEncOut[q0]];
      qY = currmetric + q0;
      if ((currmetric < 0) && ((q0 < 0) && (qY >= 0))) {
        qY = MIN_int32_T;
      } else {
        if ((currmetric > 0) && ((q0 > 0) && (qY <= 0))) {
          qY = MAX_int32_T;
        }
      }

      if (qY < pTempMetric[nextStateIdx]) {
        q0 = numStates * pTbPtr[0U] + nextStateIdx;
        pTbState[q0] = (unsigned int)stateIdx;
        pTbInput[q0] = (unsigned int)inpIdx;
        pTempMetric[nextStateIdx] = qY;
        if (pTempMetric[nextStateIdx] < renorm) {
          renorm = pTempMetric[nextStateIdx];
        }
      }
    }
  }

  /* Update (and renormalize) state metrics, then find  */
  /*  minimum metric state for start of traceback */
  minstate = 0;
  for (stateIdx = 0; stateIdx < numStates; stateIdx++) {
    q0 = pTempMetric[stateIdx];
    qY = q0 - renorm;
    if ((q0 < 0) && ((renorm >= 0) && (qY >= 0))) {
      qY = MIN_int32_T;
    } else {
      if ((q0 >= 0) && ((renorm < 0) && (qY < 0))) {
        qY = MAX_int32_T;
      }
    }

    pStateMet[stateIdx] = qY;
    if (qY == 0) {
      minstate = stateIdx;
    }
  }

  return minstate;
}

static void SystemCore_initializeInputSizes(comm_MIMOChannel *obj)
{
  comm_MIMOChannel *b_obj;
  int i2;
  static const short value[8] = { 3108, 2, 1, 1, 1, 1, 1, 1 };

  b_obj = obj;
  for (i2 = 0; i2 < 8; i2++) {
    b_obj->inputVarSize1[i2] = (unsigned int)value[i2];
  }
}

static void SystemCore_setup(comm_GoldSequence_2 *obj)
{
  comm_GoldSequence_2 *b_obj;
  comm_internal_GoldSequenceXor *this;
  comm_PNSequence_9 *c_obj;
  int idx;
  b_obj = obj;
  b_obj->isInitialized = TRUE;
  b_obj = obj;
  this = &b_obj->cGenerator;
  this->isInitialized = FALSE;
  this->isReleased = FALSE;
  b_obj = obj;
  this = &b_obj->cGenerator;
  if (this->isInitialized) {
    c_obj = &this->pFirstSequence;

    /* System object Initialization function: comm.PNSequence */
    for (idx = 0; idx < 31; idx++) {
      c_obj->W0_shiftReg[idx] = c_obj->P1_IniState[idx];
    }
  }
}

static void b_SystemCore_setup(comm_internal_GoldSequenceXor *obj)
{
  comm_internal_GoldSequenceXor *b_obj;
  comm_PNSequence_9 *c_obj;
  int i;
  static const signed char iv9[32] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 };

  static const signed char iv10[31] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  static const signed char iv11[31] = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1,
    0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0 };

  static const unsigned short uv3[2] = { 43200U, 1U };

  comm_PNSequence_10 *d_obj;
  static const signed char iv12[32] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 };

  static const signed char iv13[31] = { 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0 };

  b_obj = obj;
  b_obj->isInitialized = TRUE;
  b_obj = obj;
  c_obj = &b_obj->pFirstSequence;

  /* System object Constructor function: comm.PNSequence */
  c_obj->S0_isInitialized = FALSE;
  c_obj->S1_isReleased = FALSE;
  for (i = 0; i < 32; i++) {
    c_obj->P0_Polynomial[i] = (unsigned char)iv9[i];
  }

  for (i = 0; i < 31; i++) {
    c_obj->P1_IniState[i] = (unsigned char)iv10[i];
    c_obj->P2_Mask[i] = (unsigned char)iv11[i];
  }

  for (i = 0; i < 2; i++) {
    c_obj->P3_MaxOutSize[i] = uv3[i];
  }

  d_obj = &b_obj->pSecondSequence;

  /* System object Constructor function: comm.PNSequence */
  d_obj->S0_isInitialized = FALSE;
  d_obj->S1_isReleased = FALSE;
  for (i = 0; i < 32; i++) {
    d_obj->P0_Polynomial[i] = (unsigned char)iv12[i];
  }

  for (i = 0; i < 31; i++) {
    d_obj->P1_Mask[i] = (unsigned char)iv13[i];
  }

  for (i = 0; i < 2; i++) {
    d_obj->P2_MaxOutSize[i] = uv3[i];
  }

  b_obj = obj;
  c_obj = &b_obj->pFirstSequence;

  /* System object Initialization function: comm.PNSequence */
  for (i = 0; i < 31; i++) {
    c_obj->W0_shiftReg[i] = c_obj->P1_IniState[i];
  }
}

static void b_eml_rand_mt19937ar(unsigned int b_state[625])
{
  unsigned int r;
  int mti;
  r = 100U;
  b_state[0] = 100U;
  for (mti = 0; mti < 623; mti++) {
    r = (r ^ r >> 30U) * 1812433253U + (1 + mti);
    b_state[mti + 1] = r;
  }

  b_state[624] = 624U;
}

static void c_SystemCore_setup(comm_MIMOChannel *obj)
{
  comm_MIMOChannel *b_obj;
  unsigned int uv4[625];
  unsigned int uv5[625];
  int i;
  creal_T dcv0[636];
  creal_T x[32];
  creal_T dcv1[280];
  creal_T filterOut[320];
  creal_T dcv2[28];
  creal_T dcv3[32];
  static const double dv1[8] = { -0.0019589738603249776, 0.0109082344693896,
    -0.035989677276361709, 0.10791557218888112, 0.9681927178992048,
    -0.061569262286000404, 0.014813780273185613, -0.0024025612507599893 };

  int i1;
  creal_T dcv4[280];
  static const double dv2[8] = { -0.00376453503293513, 0.021176872368889415,
    -0.0712703802736878, 0.22794835312566583, 0.90964787755623577,
    -0.10613792657749883, 0.026616398139977914, -0.0043858741222753987 };

  static const double dv3[8] = { -0.0052572973707263517, 0.029894617451689004,
    -0.1028141798547984, 0.35522105070832621, 0.82754879586814256,
    -0.13380513634594685, 0.034801520990625751, -0.0058200453803686977 };

  static const double dv4[8] = { -0.00629795036486299, 0.036223512333436354,
    -0.12757732587818868, 0.48438115499037193, 0.72600168782452,
    -0.14545302205145352, 0.03907848141175424, -0.0066261522652795949 };

  static const double dv5[8] = { -0.00677751383068747, 0.039457774230985246,
    -0.14265809342844146, 0.60983636066166247, 0.60983636066166247,
    -0.14265809342844146, 0.039457774230985246, -0.00677751383068747 };

  static const double dv6[8] = { -0.0066261522652795949, 0.03907848141175424,
    -0.14545302205145352, 0.72600168782452, 0.48438115499037193,
    -0.12757732587818868, 0.036223512333436354, -0.00629795036486299 };

  static const double dv7[8] = { -0.0058200453803686977, 0.034801520990625751,
    -0.13380513634594685, 0.82754879586814256, 0.35522105070832621,
    -0.1028141798547984, 0.029894617451689004, -0.0052572973707263517 };

  static const double dv8[8] = { -0.0043858741222753987, 0.026616398139977914,
    -0.10613792657749883, 0.90964787755623577, 0.22794835312566583,
    -0.0712703802736878, 0.021176872368889415, -0.00376453503293513 };

  static const double dv9[8] = { -0.0024025612507599893, 0.014813780273185613,
    -0.061569262286000404, 0.9681927178992048, 0.10791557218888112,
    -0.035989677276361709, 0.0109082344693896, -0.0019589738603249776 };

  static const double dv10[8] = { -2.0499417134388578E-13,
    6.8058746136427585E-13, -1.234126341546299E-12, 1.000000000001485,
    -1.234126341546299E-12, 6.8058746136427585E-13, -2.0499417134388578E-13, 0.0
  };

  creal_T b_filterOut[40];
  creal_T dcv5[8];
  c_SystemProp_matlabCodegenSetAn(obj);
  SystemCore_initializeInputSizes(obj);
  b_obj = obj;
  memset(&uv4[0], 0, 625U * sizeof(unsigned int));
  d_SystemProp_matlabCodegenSetAn(b_obj, uv4);
  for (i = 0; i < 625; i++) {
    uv5[i] = b_obj->pWGNState[i];
  }

  b_eml_rand_mt19937ar(uv5);
  d_SystemProp_matlabCodegenSetAn(b_obj, uv5);
  for (i = 0; i < 636; i++) {
    dcv0[i].re = 0.0;
    dcv0[i].im = 0.0;
  }

  e_SystemProp_matlabCodegenSetAn(b_obj, dcv0);
  c_FadingChannel_GFilterGenerate(b_obj);
  d_FadingChannel_GFilterGenerate(b_obj, x);
  for (i = 0; i < 280; i++) {
    dcv1[i].re = 0.0;
    dcv1[i].im = 0.0;
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv1);
  c_filter(dv1, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[10 * i1 + 80 * i] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * i], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv2, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 1] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (4 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv3, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 2] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (8 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv4, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 3] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (12 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv5, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 4] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (16 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv6, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 5] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (20 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv7, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 6] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (24 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv8, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 7] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (28 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv9, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 8] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (32 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  c_filter(dv10, x, dcv3, dcv2);
  for (i = 0; i < 4; i++) {
    for (i1 = 0; i1 < 8; i1++) {
      filterOut[(10 * i1 + 80 * i) + 9] = dcv3[i1 + (i << 3)];
    }
  }

  for (i = 0; i < 280; i++) {
    dcv4[i] = b_obj->pIFilterState[i];
  }

  for (i = 0; i < 4; i++) {
    memcpy(&dcv4[7 * (36 + i)], &dcv2[7 * i], 7U * sizeof(creal_T));
  }

  f_SystemProp_matlabCodegenSetAn(b_obj, dcv4);
  for (i = 0; i < 4; i++) {
    memcpy(&b_filterOut[10 * i], &filterOut[70 + 80 * i], 10U * sizeof(creal_T));
  }

  g_SystemProp_matlabCodegenSetAn(b_obj, b_filterOut);
  h_SystemProp_matlabCodegenSetAn(b_obj, 10.0);
  i = (int)(70.0 + b_obj->pIFilterPhase);
  for (i1 = 0; i1 < 4; i1++) {
    dcv5[i1 << 1].re = 0.0;
    dcv5[i1 << 1].im = 0.0;
    dcv5[1 + (i1 << 1)] = filterOut[(i + 80 * i1) - 1];
  }

  i_SystemProp_matlabCodegenSetAn(b_obj, dcv5);
  j_SystemProp_matlabCodegenSetAn(b_obj, 1.0);
  FadingChannel_generatePathGains(b_obj);
  k_SystemProp_matlabCodegenSetAn(b_obj, 0.0);
}

static void d_SystemCore_setup(comm_internal_GoldSequenceXor_1 *obj)
{
  comm_internal_GoldSequenceXor_1 *b_obj;
  comm_PNSequence_14 *c_obj;
  int i;
  static const signed char iv32[32] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 };

  static const signed char iv33[31] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  static const signed char iv34[31] = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1,
    0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0 };

  static const unsigned short uv7[2] = { 43200U, 1U };

  comm_PNSequence_15 *d_obj;
  static const signed char iv35[32] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 };

  static const signed char iv36[31] = { 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0 };

  b_obj = obj;
  b_obj->isInitialized = TRUE;
  b_obj = obj;
  c_obj = &b_obj->pFirstSequence;

  /* System object Constructor function: comm.PNSequence */
  c_obj->S0_isInitialized = FALSE;
  c_obj->S1_isReleased = FALSE;
  for (i = 0; i < 32; i++) {
    c_obj->P0_Polynomial[i] = (unsigned char)iv32[i];
  }

  for (i = 0; i < 31; i++) {
    c_obj->P1_IniState[i] = (unsigned char)iv33[i];
    c_obj->P2_Mask[i] = (unsigned char)iv34[i];
  }

  for (i = 0; i < 2; i++) {
    c_obj->P3_MaxOutSize[i] = uv7[i];
  }

  d_obj = &b_obj->pSecondSequence;

  /* System object Constructor function: comm.PNSequence */
  d_obj->S0_isInitialized = FALSE;
  d_obj->S1_isReleased = FALSE;
  for (i = 0; i < 32; i++) {
    d_obj->P0_Polynomial[i] = (unsigned char)iv35[i];
  }

  for (i = 0; i < 31; i++) {
    d_obj->P1_Mask[i] = (unsigned char)iv36[i];
  }

  for (i = 0; i < 2; i++) {
    d_obj->P2_MaxOutSize[i] = uv7[i];
  }

  b_obj = obj;
  c_obj = &b_obj->pFirstSequence;

  /* System object Initialization function: comm.PNSequence */
  for (i = 0; i < 31; i++) {
    c_obj->W0_shiftReg[i] = c_obj->P1_IniState[i];
  }
}

static void e_SystemCore_setup(comm_GoldSequence_3 *obj)
{
  comm_GoldSequence_3 *b_obj;
  comm_internal_GoldSequenceXor_1 *this;
  comm_PNSequence_14 *c_obj;
  int idx;
  b_obj = obj;
  b_obj->isInitialized = TRUE;
  b_obj = obj;
  this = &b_obj->cGenerator;
  this->isInitialized = FALSE;
  this->isReleased = FALSE;
  b_obj = obj;
  this = &b_obj->cGenerator;
  if (this->isInitialized) {
    c_obj = &this->pFirstSequence;

    /* System object Initialization function: comm.PNSequence */
    for (idx = 0; idx < 31; idx++) {
      c_obj->W0_shiftReg[idx] = c_obj->P1_IniState[idx];
    }
  }
}

void SystemCore_reset(commcodegen_ErrorRate *obj)
{
  commcodegen_ErrorRate *b_obj;
  comm_ErrorRate_2 *c_obj;
  int i;
  if (obj->isInitialized) {
    b_obj = obj;
    c_obj = &b_obj->cSFunObject;

    /* System object Initialization function: comm.ErrorRate */
    c_obj->W0_errors = 0.0;
    c_obj->W1_symbols = 0.0;
    c_obj->W2_STDelay = 0;
    c_obj->W4_curTx = 0;
    for (i = 0; i < 2048; i++) {
      c_obj->W5_useFrame[i] = TRUE;
    }
  }
}

void SystemCore_step(commcodegen_CRCGenerator *obj, const double varargin_1[2048],
                     double varargout_1[2072])
{
  commcodegen_CRCGenerator *b_obj;
  int k;
  static const short value[8] = { 2048, 1, 1, 1, 1, 1, 1, 1 };

  boolean_T exitg1;
  static const short iv8[8] = { 2048, 1, 1, 1, 1, 1, 1, 1 };

  comm_CRCGenerator_6 *c_obj;
  unsigned int shReg;
  int i;
  unsigned int input;
  unsigned int bitMask;
  int j;
  unsigned int inpBit;
  if (!obj->isInitialized) {
    b_obj = obj;
    b_obj->isInitialized = TRUE;
    for (k = 0; k < 8; k++) {
      b_obj->inputVarSize1[k] = (unsigned int)value[k];
    }
  }

  b_obj = obj;
  k = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize1[k] != (unsigned int)iv8[k]) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize1[k] = (unsigned int)value[k];
      }

      exitg1 = TRUE;
    } else {
      k++;
    }
  }

  b_obj = obj;
  c_obj = &b_obj->cSFunObject;

  /* System object Outputs function: comm.CRCGenerator */
  /* Initialize for current sub-frame */
  shReg = 0U;
  k = 0;
  for (i = 0; i < 259; i++) {
    input = 0U;
    bitMask = 128U;
    for (j = 0; j < 8; j++) {
      if (k < 2048) {
        inpBit = (unsigned int)varargin_1[k] & 1U;
        varargout_1[k] = inpBit;

        /* Build input data chunk */
        input |= bitMask * inpBit;
        bitMask >>= 1U;
        k++;
      }
    }

    /* Retrieve value from CRC table and update register */
    shReg = c_obj->P0_CRCTable[shReg >> 16U & 255U] ^ (shReg << 8U | input);
  }

  /* Process the leftover bits */
  /* Apply final XOR */
  /* Output the register */
  varargout_1[2048] = (int)(shReg >> 23U) & 1;
  varargout_1[2049] = (int)(shReg >> 22U) & 1;
  varargout_1[2050] = (int)(shReg >> 21U) & 1;
  varargout_1[2051] = (int)(shReg >> 20U) & 1;
  varargout_1[2052] = (int)(shReg >> 19U) & 1;
  varargout_1[2053] = (int)(shReg >> 18U) & 1;
  varargout_1[2054] = (int)(shReg >> 17U) & 1;
  varargout_1[2055] = (int)(shReg >> 16U) & 1;
  varargout_1[2056] = (int)(shReg >> 15U) & 1;
  varargout_1[2057] = (int)(shReg >> 14U) & 1;
  varargout_1[2058] = (int)(shReg >> 13U) & 1;
  varargout_1[2059] = (int)(shReg >> 12U) & 1;
  varargout_1[2060] = (int)(shReg >> 11U) & 1;
  varargout_1[2061] = (int)(shReg >> 10U) & 1;
  varargout_1[2062] = (int)(shReg >> 9U) & 1;
  varargout_1[2063] = (int)(shReg >> 8U) & 1;
  varargout_1[2064] = (int)(shReg >> 7U) & 1;
  varargout_1[2065] = (int)(shReg >> 6U) & 1;
  varargout_1[2066] = (int)(shReg >> 5U) & 1;
  varargout_1[2067] = (int)(shReg >> 4U) & 1;
  varargout_1[2068] = (int)(shReg >> 3U) & 1;
  varargout_1[2069] = (int)(shReg >> 2U) & 1;
  varargout_1[2070] = (int)(shReg >> 1U) & 1;
  varargout_1[2071] = (int)shReg & 1;
}

void b_SystemCore_step(comm_GoldSequence_2 *obj, const double varargin_1[31],
  emxArray_real_T *varargout_1)
{
  comm_GoldSequence_2 *b_obj;
  comm_internal_GoldSequenceXor *c_obj;
  comm_PNSequence_9 *d_obj;
  int idx;
  int i;
  unsigned char tmp;
  unsigned char tmp2;
  emxArray_real_T *b_varargout_1;
  comm_PNSequence_10 *e_obj;
  int outTemp_size[2];
  boolean_T outTemp_data[43200];
  if (!obj->isInitialized) {
    SystemCore_setup(obj);
  }

  b_obj = obj;
  c_obj = &b_obj->cGenerator;
  if (!c_obj->isInitialized) {
    b_SystemCore_setup(c_obj);
  }

  d_obj = &c_obj->pFirstSequence;
  if (!d_obj->S0_isInitialized) {
    d_obj->S0_isInitialized = TRUE;

    /* System object Initialization function: comm.PNSequence */
    for (idx = 0; idx < 31; idx++) {
      d_obj->W0_shiftReg[idx] = d_obj->P1_IniState[idx];
    }
  }

  /* System object Outputs function: comm.PNSequence */
  if (6216U > d_obj->P3_MaxOutSize[0U]) {
  } else {
    idx = varargout_1->size[0] * varargout_1->size[1];
    varargout_1->size[0] = 6216;
    varargout_1->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)varargout_1, idx, (int)sizeof(double));
    for (i = 0; i < 31; i++) {
      d_obj->W0_shiftReg[i] = d_obj->P1_IniState[i];
    }

    for (idx = 0; idx < 6216; idx++) {
      tmp = 0;
      for (i = 0; i < 31; i++) {
        tmp = (unsigned char)((unsigned int)tmp + (unsigned char)((unsigned int)
          d_obj->P0_Polynomial[i + 1] * d_obj->W0_shiftReg[i]));
      }

      tmp &= 1;
      tmp2 = 0;
      for (i = 0; i < 31; i++) {
        tmp2 = (unsigned char)((unsigned int)tmp2 + (unsigned char)((unsigned
          int)d_obj->W0_shiftReg[i] * d_obj->P2_Mask[i]));
      }

      varargout_1->data[idx] = tmp2 & 1;
      for (i = 29; i > -1; i += -1) {
        d_obj->W0_shiftReg[i + 1] = d_obj->W0_shiftReg[i];
      }

      d_obj->W0_shiftReg[0U] = tmp;
    }
  }

  emxInit_real_T(&b_varargout_1, 2);
  e_obj = &c_obj->pSecondSequence;

  /* System object Outputs function: comm.PNSequence */
  if (6216U > e_obj->P2_MaxOutSize[0U]) {
  } else {
    idx = b_varargout_1->size[0] * b_varargout_1->size[1];
    b_varargout_1->size[0] = 6216;
    b_varargout_1->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)b_varargout_1, idx, (int)sizeof(double));
    for (idx = 0; idx < 31; idx++) {
      e_obj->W0_shiftReg[(unsigned int)idx] = (unsigned char)varargin_1
        [(unsigned int)idx];
    }

    for (idx = 0; idx < 6216; idx++) {
      tmp = 0;
      for (i = 0; i < 31; i++) {
        tmp = (unsigned char)((unsigned int)tmp + (unsigned char)((unsigned int)
          e_obj->P0_Polynomial[i + 1] * e_obj->W0_shiftReg[i]));
      }

      tmp &= 1;
      tmp2 = 0;
      for (i = 0; i < 31; i++) {
        tmp2 = (unsigned char)((unsigned int)tmp2 + (unsigned char)((unsigned
          int)e_obj->W0_shiftReg[i] * e_obj->P1_Mask[i]));
      }

      b_varargout_1->data[idx] = tmp2 & 1;
      for (i = 29; i > -1; i += -1) {
        e_obj->W0_shiftReg[i + 1] = e_obj->W0_shiftReg[i];
      }

      e_obj->W0_shiftReg[0U] = tmp;
    }
  }

  xor(varargout_1, b_varargout_1, outTemp_data, outTemp_size);
  idx = varargout_1->size[0] * varargout_1->size[1];
  varargout_1->size[0] = outTemp_size[0];
  varargout_1->size[1] = outTemp_size[1];
  emxEnsureCapacity((emxArray__common *)varargout_1, idx, (int)sizeof(double));
  i = outTemp_size[0] * outTemp_size[1];
  emxFree_real_T(&b_varargout_1);
  for (idx = 0; idx < i; idx++) {
    varargout_1->data[idx] = outTemp_data[idx];
  }
}

void c_SystemCore_step(commcodegen_QPSKModulator *obj, const double varargin_1
  [6216], creal_T varargout_1[3108])
{
  commcodegen_QPSKModulator *b_obj;
  int k;
  static const short value[8] = { 6216, 1, 1, 1, 1, 1, 1, 1 };

  boolean_T exitg1;
  static const short iv14[8] = { 6216, 1, 1, 1, 1, 1, 1, 1 };

  comm_QPSKModulator_0 *c_obj;
  int outIdx;
  int i;
  int symbolIndex;
  int m;
  double u;
  if (!obj->isInitialized) {
    b_obj = obj;
    b_obj->isInitialized = TRUE;
    for (k = 0; k < 8; k++) {
      b_obj->inputVarSize1[k] = (unsigned int)value[k];
    }
  }

  b_obj = obj;
  k = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize1[k] != (unsigned int)iv14[k]) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize1[k] = (unsigned int)value[k];
      }

      exitg1 = TRUE;
    } else {
      k++;
    }
  }

  b_obj = obj;
  c_obj = &b_obj->cSFunObject;

  /* System object Outputs function: comm.QPSKModulator */
  k = 0;
  outIdx = 0;
  for (i = 0; i < 3108; i++) {
    symbolIndex = 0;
    for (m = 0; m < 2; m++) {
      symbolIndex <<= 1;
      u = varargin_1[k];
      k++;
      symbolIndex += (int)floor(u);
    }

    symbolIndex ^= symbolIndex >> 1;
    varargout_1[outIdx].re = c_obj->P0_modmap[symbolIndex << 1];
    varargout_1[outIdx].im = c_obj->P0_modmap[(symbolIndex << 1) + 1];
    outIdx++;
  }
}

void d_SystemCore_step(comm_MIMOChannel *obj, const creal_T varargin_1[6216],
  creal_T varargout_1[6216], creal_T varargout_2[12432])
{
  comm_MIMOChannel *b_obj;
  int k;
  boolean_T exitg1;
  static const short iv15[8] = { 3108, 2, 1, 1, 1, 1, 1, 1 };

  static const short inputSize[8] = { 3108, 2, 1, 1, 1, 1, 1, 1 };

  if (!obj->isInitialized) {
    c_SystemCore_setup(obj);
  }

  b_obj = obj;
  k = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize1[k] != (unsigned int)iv15[k]) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize1[k] = (unsigned int)inputSize[k];
      }

      exitg1 = TRUE;
    } else {
      k++;
    }
  }

  FadingChannel_stepImpl(obj, varargin_1, varargout_1, varargout_2);
}

void e_SystemCore_step(comm_AWGNChannel *obj, const creal_T varargin_1[6216],
  double varargin_2, creal_T varargout_1[6216])
{
  comm_AWGNChannel *b_obj;
  int k;
  static const short value[8] = { 3108, 2, 1, 1, 1, 1, 1, 1 };

  boolean_T exitg2;
  static const short iv31[8] = { 3108, 2, 1, 1, 1, 1, 1, 1 };

  boolean_T exitg1;
  if (!obj->isInitialized) {
    b_obj = obj;
    b_obj->isInitialized = TRUE;
    for (k = 0; k < 8; k++) {
      b_obj->inputVarSize1[k] = (unsigned int)value[k];
      b_obj->inputVarSize2[k] = 1U;
    }

    c_AWGNChannel_validatePropertie(b_obj);
    b_obj->TunablePropsChanged = FALSE;
  }

  b_obj = obj;
  if (b_obj->TunablePropsChanged) {
    c_AWGNChannel_validatePropertie(b_obj);
    b_obj->TunablePropsChanged = FALSE;
    for (k = 0; k < 5; k++) {
      b_obj->tunablePropertyChanged[k] = FALSE;
    }
  }

  b_obj = obj;
  k = 0;
  exitg2 = FALSE;
  while ((exitg2 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize1[k] != (unsigned int)iv31[k]) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize1[k] = (unsigned int)value[k];
      }

      exitg2 = TRUE;
    } else {
      k++;
    }
  }

  k = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize2[k] != 1U) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize2[k] = 1U;
      }

      exitg1 = TRUE;
    } else {
      k++;
    }
  }

  AWGNChannel_stepImpl(varargin_1, varargin_2, varargout_1);
}

void f_SystemCore_step(comm_GoldSequence_3 *obj, const double varargin_1[31],
  emxArray_real_T *varargout_1)
{
  comm_GoldSequence_3 *b_obj;
  comm_internal_GoldSequenceXor_1 *c_obj;
  comm_PNSequence_14 *d_obj;
  int idx;
  int i;
  unsigned char tmp;
  unsigned char tmp2;
  emxArray_real_T *b_varargout_1;
  comm_PNSequence_15 *e_obj;
  int outTemp_size[2];
  boolean_T outTemp_data[43200];
  if (!obj->isInitialized) {
    e_SystemCore_setup(obj);
  }

  b_obj = obj;
  c_obj = &b_obj->cGenerator;
  if (!c_obj->isInitialized) {
    d_SystemCore_setup(c_obj);
  }

  d_obj = &c_obj->pFirstSequence;
  if (!d_obj->S0_isInitialized) {
    d_obj->S0_isInitialized = TRUE;

    /* System object Initialization function: comm.PNSequence */
    for (idx = 0; idx < 31; idx++) {
      d_obj->W0_shiftReg[idx] = d_obj->P1_IniState[idx];
    }
  }

  /* System object Outputs function: comm.PNSequence */
  if (6216U > d_obj->P3_MaxOutSize[0U]) {
  } else {
    idx = varargout_1->size[0] * varargout_1->size[1];
    varargout_1->size[0] = 6216;
    varargout_1->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)varargout_1, idx, (int)sizeof(double));
    for (i = 0; i < 31; i++) {
      d_obj->W0_shiftReg[i] = d_obj->P1_IniState[i];
    }

    for (idx = 0; idx < 6216; idx++) {
      tmp = 0;
      for (i = 0; i < 31; i++) {
        tmp = (unsigned char)((unsigned int)tmp + (unsigned char)((unsigned int)
          d_obj->P0_Polynomial[i + 1] * d_obj->W0_shiftReg[i]));
      }

      tmp &= 1;
      tmp2 = 0;
      for (i = 0; i < 31; i++) {
        tmp2 = (unsigned char)((unsigned int)tmp2 + (unsigned char)((unsigned
          int)d_obj->W0_shiftReg[i] * d_obj->P2_Mask[i]));
      }

      varargout_1->data[idx] = tmp2 & 1;
      for (i = 29; i > -1; i += -1) {
        d_obj->W0_shiftReg[i + 1] = d_obj->W0_shiftReg[i];
      }

      d_obj->W0_shiftReg[0U] = tmp;
    }
  }

  emxInit_real_T(&b_varargout_1, 2);
  e_obj = &c_obj->pSecondSequence;

  /* System object Outputs function: comm.PNSequence */
  if (6216U > e_obj->P2_MaxOutSize[0U]) {
  } else {
    idx = b_varargout_1->size[0] * b_varargout_1->size[1];
    b_varargout_1->size[0] = 6216;
    b_varargout_1->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)b_varargout_1, idx, (int)sizeof(double));
    for (idx = 0; idx < 31; idx++) {
      e_obj->W0_shiftReg[(unsigned int)idx] = (unsigned char)varargin_1
        [(unsigned int)idx];
    }

    for (idx = 0; idx < 6216; idx++) {
      tmp = 0;
      for (i = 0; i < 31; i++) {
        tmp = (unsigned char)((unsigned int)tmp + (unsigned char)((unsigned int)
          e_obj->P0_Polynomial[i + 1] * e_obj->W0_shiftReg[i]));
      }

      tmp &= 1;
      tmp2 = 0;
      for (i = 0; i < 31; i++) {
        tmp2 = (unsigned char)((unsigned int)tmp2 + (unsigned char)((unsigned
          int)e_obj->W0_shiftReg[i] * e_obj->P1_Mask[i]));
      }

      b_varargout_1->data[idx] = tmp2 & 1;
      for (i = 29; i > -1; i += -1) {
        e_obj->W0_shiftReg[i + 1] = e_obj->W0_shiftReg[i];
      }

      e_obj->W0_shiftReg[0U] = tmp;
    }
  }

  xor(varargout_1, b_varargout_1, outTemp_data, outTemp_size);
  idx = varargout_1->size[0] * varargout_1->size[1];
  varargout_1->size[0] = outTemp_size[0];
  varargout_1->size[1] = outTemp_size[1];
  emxEnsureCapacity((emxArray__common *)varargout_1, idx, (int)sizeof(double));
  i = outTemp_size[0] * outTemp_size[1];
  emxFree_real_T(&b_varargout_1);
  for (idx = 0; idx < i; idx++) {
    varargout_1->data[idx] = outTemp_data[idx];
  }
}

void g_SystemCore_step(commcodegen_ViterbiDecoder *obj, const double varargin_1
  [12432], double varargout_1[4144])
{
  commcodegen_ViterbiDecoder *b_obj;
  int k;
  static const short value[8] = { 12432, 1, 1, 1, 1, 1, 1, 1 };

  comm_ViterbiDecoder_5 *c_obj;
  boolean_T exitg1;
  static const short iv39[8] = { 12432, 1, 1, 1, 1, 1, 1, 1 };

  unsigned int minstateLastTB;
  int tbworkLastTB;
  int ib;
  int indx1;
  int temp;
  int indx2;
  int tmpV;
  unsigned int minstate;
  unsigned int input;
  if (!obj->isInitialized) {
    b_obj = obj;
    b_obj->isInitialized = TRUE;
    for (k = 0; k < 8; k++) {
      b_obj->inputVarSize1[k] = (unsigned int)value[k];
    }

    c_obj = &b_obj->cSFunObject;
    if (!c_obj->S0_isInitialized) {
      c_obj->S0_isInitialized = TRUE;
      InitializeConditions(c_obj);
    }

    InitializeConditions(&b_obj->cSFunObject);
  }

  b_obj = obj;
  k = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize1[k] != (unsigned int)iv39[k]) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize1[k] = (unsigned int)value[k];
      }

      exitg1 = TRUE;
    } else {
      k++;
    }
  }

  b_obj = obj;
  c_obj = &b_obj->cSFunObject;
  if (!c_obj->S0_isInitialized) {
    c_obj->S0_isInitialized = TRUE;
    InitializeConditions(c_obj);
  }

  /* System object Outputs function: comm.ViterbiDecoder */
  minstateLastTB = 0U;
  tbworkLastTB = 0;

  /* Set state metric for all zeros state equal to zero and all other state metrics equal to max values */
  c_obj->W6_maxVal = 32767;
  c_obj->W1_stateMetric[0U] = 0;
  for (k = 0; k < 63; k++) {
    c_obj->W1_stateMetric[k + 1] = 32767;
  }

  /* Set traceback memory to zero */
  for (k = 0; k < 2240; k++) {
    c_obj->W4_tbInput[k] = 0U;
    c_obj->W3_tbState[k] = 0U;
  }

  c_obj->W5_tbPtr = 0;
  for (ib = 0; ib < 4144; ib++) {
    k = ib * 3;

    /* Branch Metric Computation */
    for (indx1 = 0; indx1 < 8; indx1++) {
      temp = indx1;
      c_obj->W0_bMetric[indx1] = 0;
      for (indx2 = 0; indx2 < 3; indx2++) {
        tmpV = (int)floor(varargin_1[(k - indx2) + 2]);
        if ((temp & 1) != 0) {
          tmpV = 1 - tmpV;
        }

        c_obj->W0_bMetric[indx1] += tmpV;
        temp = (int)((unsigned int)temp >> 1);
      }
    }

    /* State Metric Update */
    minstate = (unsigned int)ACS_fxp_s32_s32(64, c_obj->W2_tempMetric, 2,
      c_obj->W0_bMetric, c_obj->W1_stateMetric, c_obj->W3_tbState,
      c_obj->W4_tbInput, &c_obj->W5_tbPtr, c_obj->P0_StateVec,
      c_obj->P1_OutputVec, 32767);

    /* Traceback decoding */
    k = c_obj->W5_tbPtr;

    /* Get starting minstate, starting tbwork for last loop */
    if (ib == 4143) {
      minstateLastTB = minstate;
      tbworkLastTB = k;
    }

    /* Do not do traceback for first TbDepth times */
    if (ib >= 34) {
      input = 0U;
      for (indx1 = 0; indx1 < 35; indx1++) {
        input = c_obj->W4_tbInput[minstate + (k << 6)];
        minstate = c_obj->W3_tbState[minstate + (k << 6)];
        if (k > 0) {
          k--;
        } else {
          k = 34;
        }
      }

      varargout_1[(ib - 34) % 4144] = (int)input & 1;
    }

    /* Increment (mod TbDepth) the traceback index and store */
    if (c_obj->W5_tbPtr < 34) {
      c_obj->W5_tbPtr++;
    } else {
      c_obj->W5_tbPtr = 0;
    }

    for (indx1 = 0; indx1 < 34; indx1++) {
      k = (int)(minstateLastTB + (tbworkLastTB << 6));
      input = c_obj->W4_tbInput[k];
      varargout_1[4143 - indx1] = (int)input & 1;
      minstateLastTB = c_obj->W3_tbState[k];
      if (tbworkLastTB > 0) {
        tbworkLastTB--;
      } else {
        tbworkLastTB = 34;
      }
    }
  }
}

void h_SystemCore_step(commcodegen_CRCDetector *obj, const double varargin_1
  [2072], double varargout_1[2048])
{
  commcodegen_CRCDetector *b_obj;
  int k;
  static const short value[8] = { 2072, 1, 1, 1, 1, 1, 1, 1 };

  boolean_T exitg1;
  static const short iv40[8] = { 2072, 1, 1, 1, 1, 1, 1, 1 };

  if (!obj->isInitialized) {
    b_obj = obj;
    b_obj->isInitialized = TRUE;
    for (k = 0; k < 8; k++) {
      b_obj->inputVarSize1[k] = (unsigned int)value[k];
    }
  }

  b_obj = obj;
  k = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (k < 8)) {
    if (b_obj->inputVarSize1[k] != (unsigned int)iv40[k]) {
      for (k = 0; k < 8; k++) {
        b_obj->inputVarSize1[k] = (unsigned int)value[k];
      }

      exitg1 = TRUE;
    } else {
      k++;
    }
  }

  Nondirect_stepImpl(varargin_1, varargout_1);
}

void i_SystemCore_step(commcodegen_ErrorRate *obj, const double varargin_1[2048],
  const double varargin_2[2048], double varargout_1[3])
{
  commcodegen_ErrorRate *b_obj;
  int i;
  static const short value[8] = { 2048, 1, 1, 1, 1, 1, 1, 1 };

  comm_ErrorRate_2 *c_obj;
  boolean_T exitg2;
  static const short iv41[8] = { 2048, 1, 1, 1, 1, 1, 1, 1 };

  boolean_T exitg1;
  double err;
  double sym;
  double ratio;
  boolean_T cur_fr;
  if (!obj->isInitialized) {
    b_obj = obj;
    b_obj->isInitialized = TRUE;
    for (i = 0; i < 8; i++) {
      b_obj->inputVarSize1[i] = (unsigned int)value[i];
      b_obj->inputVarSize2[i] = (unsigned int)value[i];
    }

    c_obj = &b_obj->cSFunObject;
    if (!c_obj->S0_isInitialized) {
      c_obj->S0_isInitialized = TRUE;

      /* System object Initialization function: comm.ErrorRate */
      c_obj->W0_errors = 0.0;
      c_obj->W1_symbols = 0.0;
      c_obj->W2_STDelay = 0;
      c_obj->W4_curTx = 0;
      for (i = 0; i < 2048; i++) {
        c_obj->W5_useFrame[i] = TRUE;
      }
    }

    c_obj = &b_obj->cSFunObject;

    /* System object Initialization function: comm.ErrorRate */
    c_obj->W0_errors = 0.0;
    c_obj->W1_symbols = 0.0;
    c_obj->W2_STDelay = 0;
    c_obj->W4_curTx = 0;
    for (i = 0; i < 2048; i++) {
      c_obj->W5_useFrame[i] = TRUE;
    }
  }

  b_obj = obj;
  i = 0;
  exitg2 = FALSE;
  while ((exitg2 == FALSE) && (i < 8)) {
    if (b_obj->inputVarSize1[i] != (unsigned int)iv41[i]) {
      for (i = 0; i < 8; i++) {
        b_obj->inputVarSize1[i] = (unsigned int)value[i];
      }

      exitg2 = TRUE;
    } else {
      i++;
    }
  }

  i = 0;
  exitg1 = FALSE;
  while ((exitg1 == FALSE) && (i < 8)) {
    if (b_obj->inputVarSize2[i] != (unsigned int)iv41[i]) {
      for (i = 0; i < 8; i++) {
        b_obj->inputVarSize2[i] = (unsigned int)value[i];
      }

      exitg1 = TRUE;
    } else {
      i++;
    }
  }

  b_obj = obj;
  c_obj = &b_obj->cSFunObject;
  if (!c_obj->S0_isInitialized) {
    c_obj->S0_isInitialized = TRUE;

    /* System object Initialization function: comm.ErrorRate */
    c_obj->W0_errors = 0.0;
    c_obj->W1_symbols = 0.0;
    c_obj->W2_STDelay = 0;
    c_obj->W4_curTx = 0;
    for (i = 0; i < 2048; i++) {
      c_obj->W5_useFrame[i] = TRUE;
    }
  }

  /* System object Outputs function: comm.ErrorRate */
  err = 0.0;
  sym = 0.0;
  ratio = 0.0;
  for (i = 0; i < 2048; i++) {
    c_obj->W3_txBuff = varargin_1[i];
    cur_fr = c_obj->W5_useFrame[i];
    if (c_obj->W4_curTx == 0) {
      c_obj->W4_curTx = 0;
    } else {
      c_obj->W4_curTx++;
    }

    if (c_obj->W2_STDelay < 0) {
      c_obj->W2_STDelay++;
    } else {
      if (cur_fr) {
        sym++;
        if (c_obj->W3_txBuff != varargin_2[i]) {
          err++;
        }
      }
    }
  }

  c_obj->W1_symbols += sym;
  c_obj->W0_errors += err;
  if (c_obj->W1_symbols > 0.0) {
    ratio = c_obj->W0_errors / c_obj->W1_symbols;
  }

  varargout_1[0U] = ratio;
  varargout_1[1U] = c_obj->W0_errors;
  varargout_1[2U] = c_obj->W1_symbols;
}

/* End of code generation (SystemCore.c) */
