/*
 * Alamouti_EncoderS.c
 *
 * Code generation for function 'Alamouti_EncoderS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "Alamouti_EncoderS.h"
#include "zPDCCH_v8_data.h"

/* Function Definitions */
void hTDEnc_not_empty_init(void)
{
  hTDEnc_not_empty = FALSE;
}

/* End of code generation (Alamouti_EncoderS.c) */
