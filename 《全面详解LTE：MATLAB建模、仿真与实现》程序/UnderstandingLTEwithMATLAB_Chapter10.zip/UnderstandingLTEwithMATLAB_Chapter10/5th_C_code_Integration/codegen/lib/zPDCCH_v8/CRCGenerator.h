/*
 * CRCGenerator.h
 *
 * Code generation for function 'CRCGenerator'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __CRCGENERATOR_H__
#define __CRCGENERATOR_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern commcodegen_CRCGenerator *CRCGenerator_CRCGenerator(commcodegen_CRCGenerator *obj);
#endif
/* End of code generation (CRCGenerator.h) */
