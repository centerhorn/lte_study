/*
 * zPDCCH_v8_types.h
 *
 * Code generation for function 'zPDCCH_v8'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __ZPDCCH_V8_TYPES_H__
#define __ZPDCCH_V8_TYPES_H__

/* Include files */
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_b_struct_T
#define typedef_b_struct_T
typedef struct
{
    double numInputSymbols;
    double numOutputSymbols;
    double numStates;
    double nextStates[128];
    double outputs[128];
} b_struct_T;
#endif /*typedef_b_struct_T*/
#ifndef typedef_c_struct_T
#define typedef_c_struct_T
typedef struct
{
    double Polynomial[25];
    double InitialConditions;
    boolean_T DirectMethod;
    boolean_T ReflectInputBytes;
    boolean_T ReflectChecksums;
    double FinalXOR;
    double ChecksumsPerFrame;
} c_struct_T;
#endif /*typedef_c_struct_T*/
#ifndef typedef_comm_AWGNChannel
#define typedef_comm_AWGNChannel
typedef struct
{
    boolean_T tunablePropertyChanged[5];
    boolean_T isInitialized;
    boolean_T isReleased;
    boolean_T TunablePropsChanged;
    unsigned int inputVarSize1[8];
    unsigned int inputVarSize2[8];
} comm_AWGNChannel;
#endif /*typedef_comm_AWGNChannel*/
#ifndef struct_comm_ConvolutionalEncoder_3
#define struct_comm_ConvolutionalEncoder_3
struct comm_ConvolutionalEncoder_3
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned int W0_currState;
    unsigned int P0_StateVec[128];
    unsigned int P1_OutputVec[128];
};
#endif /*struct_comm_ConvolutionalEncoder_3*/
#ifndef typedef_comm_ConvolutionalEncoder_3
#define typedef_comm_ConvolutionalEncoder_3
typedef struct comm_ConvolutionalEncoder_3 comm_ConvolutionalEncoder_3;
#endif /*typedef_comm_ConvolutionalEncoder_3*/
#ifndef struct_comm_ConvolutionalEncoder_4
#define struct_comm_ConvolutionalEncoder_4
struct comm_ConvolutionalEncoder_4
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned int W0_currState;
    unsigned int P0_StateVec[128];
    unsigned int P1_OutputVec[128];
};
#endif /*struct_comm_ConvolutionalEncoder_4*/
#ifndef typedef_comm_ConvolutionalEncoder_4
#define typedef_comm_ConvolutionalEncoder_4
typedef struct comm_ConvolutionalEncoder_4 comm_ConvolutionalEncoder_4;
#endif /*typedef_comm_ConvolutionalEncoder_4*/
#ifndef struct_comm_PNSequence_10
#define struct_comm_PNSequence_10
struct comm_PNSequence_10
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned char W0_shiftReg[31];
    unsigned char P0_Polynomial[32];
    unsigned char P1_Mask[31];
    unsigned int P2_MaxOutSize[2];
};
#endif /*struct_comm_PNSequence_10*/
#ifndef typedef_comm_PNSequence_10
#define typedef_comm_PNSequence_10
typedef struct comm_PNSequence_10 comm_PNSequence_10;
#endif /*typedef_comm_PNSequence_10*/
#ifndef struct_comm_PNSequence_9
#define struct_comm_PNSequence_9
struct comm_PNSequence_9
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned char W0_shiftReg[31];
    unsigned char P0_Polynomial[32];
    unsigned char P1_IniState[31];
    unsigned char P2_Mask[31];
    unsigned int P3_MaxOutSize[2];
};
#endif /*struct_comm_PNSequence_9*/
#ifndef typedef_comm_PNSequence_9
#define typedef_comm_PNSequence_9
typedef struct comm_PNSequence_9 comm_PNSequence_9;
#endif /*typedef_comm_PNSequence_9*/
#ifndef typedef_comm_internal_GoldSequenceXor
#define typedef_comm_internal_GoldSequenceXor
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    comm_PNSequence_9 pFirstSequence;
    comm_PNSequence_10 pSecondSequence;
} comm_internal_GoldSequenceXor;
#endif /*typedef_comm_internal_GoldSequenceXor*/
#ifndef typedef_comm_GoldSequence_2
#define typedef_comm_GoldSequence_2
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    comm_internal_GoldSequenceXor cGenerator;
} comm_GoldSequence_2;
#endif /*typedef_comm_GoldSequence_2*/
#ifndef struct_comm_PNSequence_14
#define struct_comm_PNSequence_14
struct comm_PNSequence_14
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned char W0_shiftReg[31];
    unsigned char P0_Polynomial[32];
    unsigned char P1_IniState[31];
    unsigned char P2_Mask[31];
    unsigned int P3_MaxOutSize[2];
};
#endif /*struct_comm_PNSequence_14*/
#ifndef typedef_comm_PNSequence_14
#define typedef_comm_PNSequence_14
typedef struct comm_PNSequence_14 comm_PNSequence_14;
#endif /*typedef_comm_PNSequence_14*/
#ifndef struct_comm_PNSequence_15
#define struct_comm_PNSequence_15
struct comm_PNSequence_15
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned char W0_shiftReg[31];
    unsigned char P0_Polynomial[32];
    unsigned char P1_Mask[31];
    unsigned int P2_MaxOutSize[2];
};
#endif /*struct_comm_PNSequence_15*/
#ifndef typedef_comm_PNSequence_15
#define typedef_comm_PNSequence_15
typedef struct comm_PNSequence_15 comm_PNSequence_15;
#endif /*typedef_comm_PNSequence_15*/
#ifndef typedef_comm_internal_GoldSequenceXor_1
#define typedef_comm_internal_GoldSequenceXor_1
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    comm_PNSequence_14 pFirstSequence;
    comm_PNSequence_15 pSecondSequence;
} comm_internal_GoldSequenceXor_1;
#endif /*typedef_comm_internal_GoldSequenceXor_1*/
#ifndef typedef_comm_GoldSequence_3
#define typedef_comm_GoldSequence_3
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    comm_internal_GoldSequenceXor_1 cGenerator;
} comm_GoldSequence_3;
#endif /*typedef_comm_GoldSequence_3*/
#ifndef typedef_comm_MIMOChannel
#define typedef_comm_MIMOChannel
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    unsigned int inputVarSize1[8];
    double pNumSamplesProcessed;
    unsigned int pWGNState[625];
    creal_T pGFilterState[636];
    double pIFilterPhase;
    creal_T pIFilterState[280];
    creal_T pIFilterNewSampLastOut[40];
    creal_T pIFilterLastOutputs[8];
    double pLinearInterpIndex;
} comm_MIMOChannel;
#endif /*typedef_comm_MIMOChannel*/
#ifndef struct_comm_CRCDetector_7
#define struct_comm_CRCDetector_7
struct comm_CRCDetector_7
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned int P0_CRCTable[256];
};
#endif /*struct_comm_CRCDetector_7*/
#ifndef typedef_comm_CRCDetector_7
#define typedef_comm_CRCDetector_7
typedef struct comm_CRCDetector_7 comm_CRCDetector_7;
#endif /*typedef_comm_CRCDetector_7*/
#ifndef typedef_commcodegen_CRCDetector
#define typedef_commcodegen_CRCDetector
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    unsigned int inputVarSize1[8];
    boolean_T inputDirectFeedthrough1;
    comm_CRCDetector_7 cSFunObject;
} commcodegen_CRCDetector;
#endif /*typedef_commcodegen_CRCDetector*/
#ifndef struct_comm_CRCGenerator_6
#define struct_comm_CRCGenerator_6
struct comm_CRCGenerator_6
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    unsigned int P0_CRCTable[256];
};
#endif /*struct_comm_CRCGenerator_6*/
#ifndef typedef_comm_CRCGenerator_6
#define typedef_comm_CRCGenerator_6
typedef struct comm_CRCGenerator_6 comm_CRCGenerator_6;
#endif /*typedef_comm_CRCGenerator_6*/
#ifndef typedef_commcodegen_CRCGenerator
#define typedef_commcodegen_CRCGenerator
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    unsigned int inputVarSize1[8];
    boolean_T inputDirectFeedthrough1;
    comm_CRCGenerator_6 cSFunObject;
} commcodegen_CRCGenerator;
#endif /*typedef_commcodegen_CRCGenerator*/
#ifndef struct_comm_ErrorRate_2
#define struct_comm_ErrorRate_2
struct comm_ErrorRate_2
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    double W0_errors;
    double W1_symbols;
    int W2_STDelay;
    double W3_txBuff;
    int W4_curTx;
    boolean_T W5_useFrame[2048];
};
#endif /*struct_comm_ErrorRate_2*/
#ifndef typedef_comm_ErrorRate_2
#define typedef_comm_ErrorRate_2
typedef struct comm_ErrorRate_2 comm_ErrorRate_2;
#endif /*typedef_comm_ErrorRate_2*/
#ifndef typedef_commcodegen_ErrorRate
#define typedef_commcodegen_ErrorRate
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    unsigned int inputVarSize1[8];
    unsigned int inputVarSize2[8];
    boolean_T inputDirectFeedthrough1;
    boolean_T inputDirectFeedthrough2;
    comm_ErrorRate_2 cSFunObject;
} commcodegen_ErrorRate;
#endif /*typedef_commcodegen_ErrorRate*/
#ifndef struct_comm_QPSKModulator_0
#define struct_comm_QPSKModulator_0
struct comm_QPSKModulator_0
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    double P0_modmap[8];
};
#endif /*struct_comm_QPSKModulator_0*/
#ifndef typedef_comm_QPSKModulator_0
#define typedef_comm_QPSKModulator_0
typedef struct comm_QPSKModulator_0 comm_QPSKModulator_0;
#endif /*typedef_comm_QPSKModulator_0*/
#ifndef typedef_commcodegen_QPSKModulator
#define typedef_commcodegen_QPSKModulator
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    unsigned int inputVarSize1[8];
    boolean_T inputDirectFeedthrough1;
    comm_QPSKModulator_0 cSFunObject;
} commcodegen_QPSKModulator;
#endif /*typedef_commcodegen_QPSKModulator*/
#ifndef struct_comm_ViterbiDecoder_5
#define struct_comm_ViterbiDecoder_5
struct comm_ViterbiDecoder_5
{
    boolean_T S0_isInitialized;
    boolean_T S1_isReleased;
    int W0_bMetric[8];
    int W1_stateMetric[64];
    int W2_tempMetric[64];
    unsigned int W3_tbState[2240];
    unsigned int W4_tbInput[2240];
    int W5_tbPtr;
    int W6_maxVal;
    unsigned int P0_StateVec[128];
    unsigned int P1_OutputVec[128];
};
#endif /*struct_comm_ViterbiDecoder_5*/
#ifndef typedef_comm_ViterbiDecoder_5
#define typedef_comm_ViterbiDecoder_5
typedef struct comm_ViterbiDecoder_5 comm_ViterbiDecoder_5;
#endif /*typedef_comm_ViterbiDecoder_5*/
#ifndef typedef_commcodegen_ViterbiDecoder
#define typedef_commcodegen_ViterbiDecoder
typedef struct
{
    boolean_T isInitialized;
    boolean_T isReleased;
    unsigned int inputVarSize1[8];
    boolean_T inputDirectFeedthrough1;
    comm_ViterbiDecoder_5 cSFunObject;
} commcodegen_ViterbiDecoder;
#endif /*typedef_commcodegen_ViterbiDecoder*/
#ifndef typedef_d_struct_T
#define typedef_d_struct_T
typedef struct
{
    char SpectrumType[5];
} d_struct_T;
#endif /*typedef_d_struct_T*/
#ifndef typedef_e_struct_T
#define typedef_e_struct_T
typedef struct
{
    double ReceiveDelay;
    double ComputationDelay;
    char Samples[12];
    boolean_T ResetInputPort;
} e_struct_T;
#endif /*typedef_e_struct_T*/
#ifndef struct_emxArray__common
#define struct_emxArray__common
struct emxArray__common
{
    void *data;
    int *size;
    int allocatedSize;
    int numDimensions;
    boolean_T canFreeData;
};
#endif /*struct_emxArray__common*/
#ifndef typedef_emxArray__common
#define typedef_emxArray__common
typedef struct emxArray__common emxArray__common;
#endif /*typedef_emxArray__common*/
#ifndef struct_emxArray_creal_T_10x4
#define struct_emxArray_creal_T_10x4
struct emxArray_creal_T_10x4
{
    creal_T data[40];
    int size[2];
};
#endif /*struct_emxArray_creal_T_10x4*/
#ifndef typedef_emxArray_creal_T_10x4
#define typedef_emxArray_creal_T_10x4
typedef struct emxArray_creal_T_10x4 emxArray_creal_T_10x4;
#endif /*typedef_emxArray_creal_T_10x4*/
#ifndef struct_emxArray_creal_T_1x4
#define struct_emxArray_creal_T_1x4
struct emxArray_creal_T_1x4
{
    creal_T data[4];
    int size[2];
};
#endif /*struct_emxArray_creal_T_1x4*/
#ifndef typedef_emxArray_creal_T_1x4
#define typedef_emxArray_creal_T_1x4
typedef struct emxArray_creal_T_1x4 emxArray_creal_T_1x4;
#endif /*typedef_emxArray_creal_T_1x4*/
#ifndef struct_emxArray_creal_T_3x4
#define struct_emxArray_creal_T_3x4
struct emxArray_creal_T_3x4
{
    creal_T data[12];
    int size[2];
};
#endif /*struct_emxArray_creal_T_3x4*/
#ifndef typedef_emxArray_creal_T_3x4
#define typedef_emxArray_creal_T_3x4
typedef struct emxArray_creal_T_3x4 emxArray_creal_T_3x4;
#endif /*typedef_emxArray_creal_T_3x4*/
#ifndef struct_emxArray_int32_T_2080
#define struct_emxArray_int32_T_2080
struct emxArray_int32_T_2080
{
    int data[2080];
    int size[1];
};
#endif /*struct_emxArray_int32_T_2080*/
#ifndef typedef_emxArray_int32_T_2080
#define typedef_emxArray_int32_T_2080
typedef struct emxArray_int32_T_2080 emxArray_int32_T_2080;
#endif /*typedef_emxArray_int32_T_2080*/
#ifndef struct_emxArray_int32_T_4160
#define struct_emxArray_int32_T_4160
struct emxArray_int32_T_4160
{
    int data[4160];
    int size[1];
};
#endif /*struct_emxArray_int32_T_4160*/
#ifndef typedef_emxArray_int32_T_4160
#define typedef_emxArray_int32_T_4160
typedef struct emxArray_int32_T_4160 emxArray_int32_T_4160;
#endif /*typedef_emxArray_int32_T_4160*/
#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T
struct emxArray_real_T
{
    double *data;
    int *size;
    int allocatedSize;
    int numDimensions;
    boolean_T canFreeData;
};
#endif /*struct_emxArray_real_T*/
#ifndef typedef_emxArray_real_T
#define typedef_emxArray_real_T
typedef struct emxArray_real_T emxArray_real_T;
#endif /*typedef_emxArray_real_T*/
#ifndef struct_emxArray_real_T_1x2
#define struct_emxArray_real_T_1x2
struct emxArray_real_T_1x2
{
    double data[2];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x2*/
#ifndef typedef_emxArray_real_T_1x2
#define typedef_emxArray_real_T_1x2
typedef struct emxArray_real_T_1x2 emxArray_real_T_1x2;
#endif /*typedef_emxArray_real_T_1x2*/
#ifndef struct_emxArray_real_T_1x8
#define struct_emxArray_real_T_1x8
struct emxArray_real_T_1x8
{
    double data[8];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x8*/
#ifndef typedef_emxArray_real_T_1x8
#define typedef_emxArray_real_T_1x8
typedef struct emxArray_real_T_1x8 emxArray_real_T_1x8;
#endif /*typedef_emxArray_real_T_1x8*/
#ifndef typedef_struct_T
#define typedef_struct_T
typedef struct
{
    double ecode;
} struct_T;
#endif /*typedef_struct_T*/

#endif
/* End of code generation (zPDCCH_v8_types.h) */
