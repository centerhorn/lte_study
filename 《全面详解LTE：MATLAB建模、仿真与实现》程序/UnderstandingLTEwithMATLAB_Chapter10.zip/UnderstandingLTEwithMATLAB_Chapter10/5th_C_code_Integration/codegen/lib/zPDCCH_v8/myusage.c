#include <stdlib.h>
#include <stdio.h>

void MyUsage( int argc, char *argv[], int *maxNumBits, int *maxNumErrs)
{
  printf("*************************************\n");
  printf("Main Simulation Loop of BER Analysis \n");
  if ( argc!= 3)
     {
        printf("Usage :./main.exe Max_Number_of_Bits Max_Number_of_Errors\n");
        printf("*************************************\n");
        exit(1);
     }
 
  *maxNumBits = atoi(argv[1]);
  *maxNumErrs = atoi(argv[2]);

  printf("Maximum Number of Bits   :  %d\n", *maxNumBits);
  printf("Maximum Number of Errors :  %d\n", *maxNumErrs);
  printf("*************************************\n");
}