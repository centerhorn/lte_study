/*
 * var.h
 *
 * Code generation for function 'var'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __VAR_H__
#define __VAR_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern double var(const creal_T x[6216]);
#endif
/* End of code generation (var.h) */
