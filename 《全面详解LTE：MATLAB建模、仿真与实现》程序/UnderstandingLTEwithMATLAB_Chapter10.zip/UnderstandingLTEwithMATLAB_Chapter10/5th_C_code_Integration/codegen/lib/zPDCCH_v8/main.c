
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "rtwtypes.h"
#include "myusage.h"
#include "zPDCCH_v8.h"

#define MIN_EBNO 1
#define MAX_EBNO 9

int main( int argc, char *argv[])
{
  int maxNumBits;
  int maxNumErrs;
  int EbNo;
  double ber_vector[MAX_EBNO];
  double    bits_vector[MAX_EBNO];
  time_t t1,t2;
  double elapsed, snr;

  MyUsage(argc, argv,  &maxNumBits, &maxNumErrs);
  
  t1=clock();
  zPDCCH_v8_initialize();
  for (EbNo=MIN_EBNO; EbNo<MAX_EBNO; EbNo++)
  {
   printf("Iteration number %2d\n", EbNo);
   snr = 0.5*((double)EbNo);
   zPDCCH_v8(snr, maxNumErrs, maxNumBits, &ber_vector[EbNo], &bits_vector[EbNo]);
  } 
  t2=clock();
  elapsed = ((double) (t2 - t1)) / CLOCKS_PER_SEC;

  printf("\nTotal elapsed time of %2d SNR values = %f (sec) in C\n\n", (MAX_EBNO-MIN_EBNO), elapsed);
  for (EbNo=MIN_EBNO; EbNo<MAX_EBNO; EbNo++) 
  {
      printf("Iteration %2d    Bits: %e   BER: %e\n", EbNo, bits_vector[EbNo],ber_vector[EbNo]);
  }
  return(0);

} /* end of main() */



