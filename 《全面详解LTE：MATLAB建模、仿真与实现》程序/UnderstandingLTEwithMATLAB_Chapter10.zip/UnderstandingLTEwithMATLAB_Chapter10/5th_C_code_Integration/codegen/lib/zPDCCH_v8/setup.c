/*
 * setup.c
 *
 * Code generation for function 'setup'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "setup.h"

/* Function Definitions */
void InitializeConditions(comm_ViterbiDecoder_5 *obj)
{
  int i;

  /* System object Initialization function: comm.ViterbiDecoder */
  /* Set state metric for all zeros state equal to zero and all other state metrics equal to max values */
  obj->W6_maxVal = 32767;
  obj->W1_stateMetric[0U] = 0;
  for (i = 0; i < 63; i++) {
    obj->W1_stateMetric[i + 1] = 32767;
  }

  /* Set traceback memory to zero */
  for (i = 0; i < 2240; i++) {
    obj->W4_tbInput[i] = 0U;
    obj->W3_tbState[i] = 0U;
  }

  obj->W5_tbPtr = 0;
}

void e_Destructor(comm_ViterbiDecoder_5 *obj)
{
  /* System object Destructor function: comm.ViterbiDecoder */
  if (obj->S0_isInitialized) {
    obj->S0_isInitialized = FALSE;
    if (!obj->S1_isReleased) {
      obj->S1_isReleased = TRUE;
    }
  }
}

void f_Destructor(comm_ErrorRate_2 *obj)
{
  /* System object Destructor function: comm.ErrorRate */
  if (obj->S0_isInitialized) {
    obj->S0_isInitialized = FALSE;
    if (!obj->S1_isReleased) {
      obj->S1_isReleased = TRUE;
    }
  }
}

/* End of code generation (setup.c) */
