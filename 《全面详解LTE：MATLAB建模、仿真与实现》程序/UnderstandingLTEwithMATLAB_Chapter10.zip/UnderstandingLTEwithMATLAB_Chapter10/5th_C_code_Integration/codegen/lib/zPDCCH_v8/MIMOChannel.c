/*
 * MIMOChannel.c
 *
 * Code generation for function 'MIMOChannel'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "MIMOChannel.h"

/* Function Definitions */
comm_MIMOChannel *MIMOChannel_MIMOChannel(comm_MIMOChannel *obj)
{
  comm_MIMOChannel *b_obj;
  comm_MIMOChannel *c_obj;
  b_obj = obj;
  c_obj = b_obj;
  c_obj->isInitialized = FALSE;
  c_obj->isReleased = FALSE;
  return b_obj;
}

/* End of code generation (MIMOChannel.c) */
