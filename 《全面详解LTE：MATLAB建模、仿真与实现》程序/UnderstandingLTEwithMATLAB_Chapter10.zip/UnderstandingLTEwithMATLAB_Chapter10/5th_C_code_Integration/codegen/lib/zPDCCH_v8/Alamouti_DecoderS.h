/*
 * Alamouti_DecoderS.h
 *
 * Code generation for function 'Alamouti_DecoderS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __ALAMOUTI_DECODERS_H__
#define __ALAMOUTI_DECODERS_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void hTDDec_not_empty_init(void);
#endif
/* End of code generation (Alamouti_DecoderS.h) */
