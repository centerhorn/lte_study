/*
 * FadingChannel.h
 *
 * Code generation for function 'FadingChannel'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __FADINGCHANNEL_H__
#define __FADINGCHANNEL_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void FadingChannel_generatePathGains(comm_MIMOChannel *obj);
extern void FadingChannel_stepImpl(comm_MIMOChannel *obj, const creal_T x[6216], creal_T varargout_1[6216], creal_T varargout_2[12432]);
extern void c_FadingChannel_GFilterGenerate(comm_MIMOChannel *obj);
extern void d_FadingChannel_GFilterGenerate(comm_MIMOChannel *obj, creal_T y[32]);
#endif
/* End of code generation (FadingChannel.h) */
