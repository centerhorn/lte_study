/*
 * permute.h
 *
 * Code generation for function 'permute'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __PERMUTE_H__
#define __PERMUTE_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void permute(const creal_T a[12432], creal_T b[12432]);
#endif
/* End of code generation (permute.h) */
