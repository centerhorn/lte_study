/*
 * zPDCCH_v8_data.c
 *
 * Code generation for function 'zPDCCH_v8_data'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "zPDCCH_v8_data.h"

/* Variable Definitions */
unsigned int state[625];
boolean_T state_not_empty;
boolean_T hTDEnc_not_empty;
boolean_T hTDDec_not_empty;

/* End of code generation (zPDCCH_v8_data.c) */
