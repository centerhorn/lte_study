/*
 * zPDCCH_v8_emxutil.h
 *
 * Code generation for function 'zPDCCH_v8_emxutil'
 *
 * C source code generated on: Tue Dec 31 15:43:43 2013
 *
 */

#ifndef __ZPDCCH_V8_EMXUTIL_H__
#define __ZPDCCH_V8_EMXUTIL_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void emxEnsureCapacity(emxArray__common *emxArray, int oldNumel, int elementSize);
extern void emxFree_real_T(emxArray_real_T **pEmxArray);
extern void emxInit_real_T(emxArray_real_T **pEmxArray, int numDimensions);
#endif
/* End of code generation (zPDCCH_v8_emxutil.h) */
