/*
 * _coder_zPDCCH_v8_info.h
 *
 * Code generation for function 'zPDCCH_v8'
 *
 * C source code generated on: Tue Dec 31 15:43:43 2013
 *
 */

#ifndef ___CODER_ZPDCCH_V8_INFO_H__
#define ___CODER_ZPDCCH_V8_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_zPDCCH_v8_info.h) */
