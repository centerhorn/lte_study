/*
 * ViterbiDecoder.c
 *
 * Code generation for function 'ViterbiDecoder'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "ViterbiDecoder.h"

/* Function Definitions */
commcodegen_ViterbiDecoder *ViterbiDecoder_ViterbiDecoder
  (commcodegen_ViterbiDecoder *obj)
{
  commcodegen_ViterbiDecoder *b_obj;
  commcodegen_ViterbiDecoder *c_obj;
  comm_ViterbiDecoder_5 *d_obj;
  int i;
  static const signed char iv6[128] = { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
    7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17,
    17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26,
    27, 27, 28, 28, 29, 29, 30, 30, 31, 31, 32, 32, 33, 33, 34, 34, 35, 35, 36,
    36, 37, 37, 38, 38, 39, 39, 40, 40, 41, 41, 42, 42, 43, 43, 44, 44, 45, 45,
    46, 46, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 52, 52, 53, 53, 54, 54, 55,
    55, 56, 56, 57, 57, 58, 58, 59, 59, 60, 60, 61, 61, 62, 62, 63, 63 };

  static const signed char iv7[128] = { 0, 7, 4, 3, 1, 6, 5, 2, 6, 1, 2, 5, 7, 0,
    3, 4, 7, 0, 3, 4, 6, 1, 2, 5, 1, 6, 5, 2, 0, 7, 4, 3, 3, 4, 7, 0, 2, 5, 6, 1,
    5, 2, 1, 6, 4, 3, 0, 7, 4, 3, 0, 7, 5, 2, 1, 6, 2, 5, 6, 1, 3, 4, 7, 0, 7, 0,
    3, 4, 6, 1, 2, 5, 1, 6, 5, 2, 0, 7, 4, 3, 0, 7, 4, 3, 1, 6, 5, 2, 6, 1, 2, 5,
    7, 0, 3, 4, 4, 3, 0, 7, 5, 2, 1, 6, 2, 5, 6, 1, 3, 4, 7, 0, 3, 4, 7, 0, 2, 5,
    6, 1, 5, 2, 1, 6, 4, 3, 0, 7 };

  b_obj = obj;
  c_obj = b_obj;
  c_obj->isInitialized = FALSE;
  c_obj->isReleased = FALSE;
  c_obj->inputDirectFeedthrough1 = FALSE;
  d_obj = &b_obj->cSFunObject;

  /* System object Constructor function: comm.ViterbiDecoder */
  d_obj->S0_isInitialized = FALSE;
  d_obj->S1_isReleased = FALSE;
  for (i = 0; i < 128; i++) {
    d_obj->P0_StateVec[i] = (unsigned int)iv6[i];
    d_obj->P1_OutputVec[i] = (unsigned int)iv7[i];
  }

  return b_obj;
}

/* End of code generation (ViterbiDecoder.c) */
