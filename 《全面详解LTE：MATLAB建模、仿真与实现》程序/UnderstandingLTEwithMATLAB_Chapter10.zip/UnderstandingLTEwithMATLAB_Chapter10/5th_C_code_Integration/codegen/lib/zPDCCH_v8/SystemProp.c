/*
 * SystemProp.c
 *
 * Code generation for function 'SystemProp'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "SystemProp.h"

/* Function Definitions */
void c_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj)
{
  obj->isInitialized = TRUE;
}

void d_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const unsigned int
  value[625])
{
  int i;
  for (i = 0; i < 625; i++) {
    obj->pWGNState[i] = value[i];
  }
}

void e_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value
  [636])
{
  int i3;
  for (i3 = 0; i3 < 636; i3++) {
    obj->pGFilterState[i3] = value[i3];
  }
}

void f_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value
  [280])
{
  int i4;
  for (i4 = 0; i4 < 280; i4++) {
    obj->pIFilterState[i4] = value[i4];
  }
}

void g_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value
  [40])
{
  int i5;
  for (i5 = 0; i5 < 40; i5++) {
    obj->pIFilterNewSampLastOut[i5] = value[i5];
  }
}

void h_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, double value)
{
  obj->pIFilterPhase = value;
}

void i_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, const creal_T value
  [8])
{
  int i6;
  for (i6 = 0; i6 < 8; i6++) {
    obj->pIFilterLastOutputs[i6] = value[i6];
  }
}

void j_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, double value)
{
  obj->pLinearInterpIndex = value;
}

void k_SystemProp_matlabCodegenSetAn(comm_MIMOChannel *obj, double value)
{
  obj->pNumSamplesProcessed = value;
}

/* End of code generation (SystemProp.c) */
