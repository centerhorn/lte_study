/*
 * MIMOFadingChanS.c
 *
 * Code generation for function 'MIMOFadingChanS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "MIMOFadingChanS.h"
#include "SystemCore.h"
#include "MIMOChannel.h"

/* Variable Definitions */
static comm_MIMOChannel chanObj;
static boolean_T chanObj_not_empty;

/* Function Definitions */
void MIMOFadingChanS(const creal_T in[6216], creal_T y[6216], creal_T h[12432])
{
  static creal_T G[12432];

  /*  MIMOFadingChan */
  if (!chanObj_not_empty) {
    MIMOChannel_MIMOChannel(&chanObj);
    chanObj_not_empty = TRUE;
  }

  d_SystemCore_step(&chanObj, in, y, G);
  memcpy(&h[0], &G[0], 12432U * sizeof(creal_T));
}

void chanObj_not_empty_init(void)
{
  chanObj_not_empty = FALSE;
}

/* End of code generation (MIMOFadingChanS.c) */
