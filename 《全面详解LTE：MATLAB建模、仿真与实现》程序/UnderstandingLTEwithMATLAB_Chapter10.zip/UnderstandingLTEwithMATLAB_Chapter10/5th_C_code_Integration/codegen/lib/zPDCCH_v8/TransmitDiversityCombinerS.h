/*
 * TransmitDiversityCombinerS.h
 *
 * Code generation for function 'TransmitDiversityCombinerS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __TRANSMITDIVERSITYCOMBINERS_H__
#define __TRANSMITDIVERSITYCOMBINERS_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void TransmitDiversityCombinerS(creal_T in[6216], const creal_T chEst[12432], creal_T y[3108]);
#endif
/* End of code generation (TransmitDiversityCombinerS.h) */
