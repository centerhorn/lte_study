#ifndef MYUSAGE
#define MYUSAGE


extern void MyUsage
        ( int argc, char *argv[], int *maxNumBits, int *maxNumErrs);


#endif
