/*
 * xor.c
 *
 * Code generation for function 'xor'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "xor.h"

/* Function Definitions */
void xor(const emxArray_real_T *s, const emxArray_real_T *t, boolean_T y_data
         [43200], int y_size[2])
{
  int loop_ub;
  int i0;
  y_size[0] = s->size[0];
  y_size[1] = s->size[1];
  loop_ub = s->size[0] * s->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    y_data[i0] = (((s->data[i0] != 0.0) ^ (t->data[i0] != 0.0)) != 0);
  }
}

/* End of code generation (xor.c) */
