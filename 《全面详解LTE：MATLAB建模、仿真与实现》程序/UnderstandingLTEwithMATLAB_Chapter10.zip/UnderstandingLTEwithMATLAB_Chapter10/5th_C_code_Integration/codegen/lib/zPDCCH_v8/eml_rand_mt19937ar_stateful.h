/*
 * eml_rand_mt19937ar_stateful.h
 *
 * Code generation for function 'eml_rand_mt19937ar_stateful'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __EML_RAND_MT19937AR_STATEFUL_H__
#define __EML_RAND_MT19937AR_STATEFUL_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void state_not_empty_init(void);
#endif
/* End of code generation (eml_rand_mt19937ar_stateful.h) */
