/*
 * Alamouti_DecoderS.c
 *
 * Code generation for function 'Alamouti_DecoderS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "Alamouti_DecoderS.h"
#include "zPDCCH_v8_data.h"

/* Function Definitions */
void hTDDec_not_empty_init(void)
{
  hTDDec_not_empty = FALSE;
}

/* End of code generation (Alamouti_DecoderS.c) */
