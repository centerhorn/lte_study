/*
 * var.c
 *
 * Code generation for function 'var'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "var.h"

/* Function Definitions */
double var(const creal_T x[6216])
{
  double y;
  int ix;
  double xbar_re;
  double xbar_im;
  int k;
  double c_re;
  double c_im;
  ix = 0;
  xbar_re = x[0].re;
  xbar_im = x[0].im;
  for (k = 0; k < 6215; k++) {
    ix++;
    xbar_re += x[ix].re;
    xbar_im += x[ix].im;
  }

  if (xbar_im == 0.0) {
    xbar_re /= 6216.0;
    xbar_im = 0.0;
  } else if (xbar_re == 0.0) {
    xbar_re = 0.0;
    xbar_im /= 6216.0;
  } else {
    xbar_re /= 6216.0;
    xbar_im /= 6216.0;
  }

  ix = 0;
  c_re = x[0].re - xbar_re;
  c_im = x[0].im - xbar_im;
  y = c_re * c_re + c_im * c_im;
  for (k = 0; k < 6215; k++) {
    ix++;
    c_re = x[ix].re - xbar_re;
    c_im = x[ix].im - xbar_im;
    y += c_re * c_re + c_im * c_im;
  }

  y /= 6215.0;
  return y;
}

/* End of code generation (var.c) */
