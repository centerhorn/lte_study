/*
 * fcn_RateDematcher.h
 *
 * Code generation for function 'fcn_RateDematcher'
 *
 * C source code generated on: Tue Dec 31 15:43:43 2013
 *
 */

#ifndef __FCN_RATEDEMATCHER_H__
#define __FCN_RATEDEMATCHER_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void b_eml_li_find(const boolean_T x[4160], int y_data[4160], int y_size[1]);
extern void fcn_RateDematcher(const double in[6216], double out[6216]);
#endif
/* End of code generation (fcn_RateDematcher.h) */
