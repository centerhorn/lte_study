/*
 * repmat.c
 *
 * Code generation for function 'repmat'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "repmat.h"

/* Function Definitions */
void b_repmat(const creal_T a[6216], creal_T b[12432])
{
  int ia;
  int ib;
  int iacol;
  int jcol;
  int itilerow;
  int k;
  ia = 1;
  ib = 0;
  iacol = 1;
  for (jcol = 0; jcol < 2; jcol++) {
    for (itilerow = 0; itilerow < 2; itilerow++) {
      ia = iacol;
      for (k = 0; k < 3108; k++) {
        b[ib] = a[ia - 1];
        ia++;
        ib++;
      }
    }

    iacol = ia;
  }
}

void repmat(const double a[3108], double b[12432])
{
  int ib;
  int jtilecol;
  int ia;
  int k;
  ib = 0;
  for (jtilecol = 0; jtilecol < 4; jtilecol++) {
    ia = 0;
    for (k = 0; k < 3108; k++) {
      b[ib] = a[ia];
      ia++;
      ib++;
    }
  }
}

/* End of code generation (repmat.c) */
