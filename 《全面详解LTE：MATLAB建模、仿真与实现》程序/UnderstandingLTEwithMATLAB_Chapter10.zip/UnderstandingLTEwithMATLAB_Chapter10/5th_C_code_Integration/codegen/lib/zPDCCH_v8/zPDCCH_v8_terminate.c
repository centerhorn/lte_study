/*
 * zPDCCH_v8_terminate.c
 *
 * Code generation for function 'zPDCCH_v8_terminate'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "zPDCCH_v8_terminate.h"
#include "fcn_Descrambler.h"
#include "fcn_Scrambler.h"

/* Function Definitions */
void zPDCCH_v8_terminate(void)
{
  zPDCCH_v8_free();
  fcn_Scrambler_free();
  fcn_Descrambler_free();
}

/* End of code generation (zPDCCH_v8_terminate.c) */
