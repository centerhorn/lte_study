/*
 * ErrorRate.h
 *
 * Code generation for function 'ErrorRate'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __ERRORRATE_H__
#define __ERRORRATE_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern commcodegen_ErrorRate *ErrorRate_ErrorRate(commcodegen_ErrorRate *obj);
#endif
/* End of code generation (ErrorRate.h) */
