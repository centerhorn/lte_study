/*
 * AWGNChannel.c
 *
 * Code generation for function 'AWGNChannel'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "AWGNChannel.h"
#include "randn.h"

/* Function Definitions */
void AWGNChannel_stepImpl(const creal_T x[6216], double varargin_1, creal_T y
  [6216])
{
  double b_std;
  static double b[6216];
  double dv26[6216];
  int i13;
  static creal_T randData[6216];
  double randData_im;
  int chanIdx;
  b_std = sqrt(varargin_1);
  randn(b);
  randn(dv26);
  for (i13 = 0; i13 < 6216; i13++) {
    randData[i13].re = dv26[i13] + 0.0 * b[i13];
    randData[i13].im = b[i13];
    randData_im = randData[i13].im;
    if (randData[i13].im == 0.0) {
      randData[i13].re /= 1.4142135623730951;
      randData[i13].im = 0.0;
    } else if (randData[i13].re == 0.0) {
      randData[i13].re = 0.0;
      randData[i13].im = randData_im / 1.4142135623730951;
    } else {
      randData[i13].re /= 1.4142135623730951;
      randData[i13].im = randData_im / 1.4142135623730951;
    }
  }

  for (chanIdx = 0; chanIdx < 2; chanIdx++) {
    for (i13 = 0; i13 < 3108; i13++) {
      y[i13 + 3108 * chanIdx].re = x[i13 + 3108 * chanIdx].re + b_std *
        randData[i13 + 3108 * chanIdx].re;
      y[i13 + 3108 * chanIdx].im = x[i13 + 3108 * chanIdx].im + b_std *
        randData[i13 + 3108 * chanIdx].im;
    }
  }
}

void c_AWGNChannel_validatePropertie(comm_AWGNChannel *obj)
{
  comm_AWGNChannel *b_obj;
  boolean_T flag;
  b_obj = obj;
  if (b_obj->isInitialized && (!b_obj->isReleased)) {
    flag = TRUE;
  } else {
    flag = FALSE;
  }

  if (flag) {
    b_obj->TunablePropsChanged = TRUE;
    b_obj->tunablePropertyChanged[0] = TRUE;
  }

  b_obj = obj;
  if (b_obj->isInitialized && (!b_obj->isReleased)) {
    flag = TRUE;
  } else {
    flag = FALSE;
  }

  if (flag) {
    b_obj->TunablePropsChanged = TRUE;
    b_obj->tunablePropertyChanged[1] = TRUE;
  }

  b_obj = obj;
  if (b_obj->isInitialized && (!b_obj->isReleased)) {
    flag = TRUE;
  } else {
    flag = FALSE;
  }

  if (flag) {
    b_obj->TunablePropsChanged = TRUE;
    b_obj->tunablePropertyChanged[2] = TRUE;
  }

  b_obj = obj;
  if (b_obj->isInitialized && (!b_obj->isReleased)) {
    flag = TRUE;
  } else {
    flag = FALSE;
  }

  if (flag) {
    b_obj->TunablePropsChanged = TRUE;
    b_obj->tunablePropertyChanged[3] = TRUE;
  }

  b_obj = obj;
  if (b_obj->isInitialized && (!b_obj->isReleased)) {
    flag = TRUE;
  } else {
    flag = FALSE;
  }

  if (flag) {
    b_obj->TunablePropsChanged = TRUE;
    b_obj->tunablePropertyChanged[4] = TRUE;
  }
}

/* End of code generation (AWGNChannel.c) */
