/*
 * zPDCCH_v8_data.h
 *
 * Code generation for function 'zPDCCH_v8_data'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __ZPDCCH_V8_DATA_H__
#define __ZPDCCH_V8_DATA_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Variable Declarations */
extern unsigned int state[625];
extern boolean_T state_not_empty;
extern boolean_T hTDEnc_not_empty;
extern boolean_T hTDDec_not_empty;
#endif
/* End of code generation (zPDCCH_v8_data.h) */
