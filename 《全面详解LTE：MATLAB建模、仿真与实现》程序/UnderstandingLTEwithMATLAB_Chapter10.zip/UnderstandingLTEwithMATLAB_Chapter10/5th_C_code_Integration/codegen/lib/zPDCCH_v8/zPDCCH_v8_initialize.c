/*
 * zPDCCH_v8_initialize.c
 *
 * Code generation for function 'zPDCCH_v8_initialize'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "zPDCCH_v8_initialize.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "fcn_Scrambler.h"
#include "Alamouti_EncoderS.h"
#include "MIMOFadingChanS.h"
#include "Alamouti_DecoderS.h"
#include "fcn_Descrambler.h"

/* Function Definitions */
void zPDCCH_v8_initialize(void)
{
  rt_InitInfAndNaN(8U);
  b_hSeqGen_not_empty_init();
  hTDDec_not_empty_init();
  chanObj_not_empty_init();
  hTDEnc_not_empty_init();
  hSeqGen_not_empty_init();
  state_not_empty_init();
  Modulator_not_empty_init();
}

/* End of code generation (zPDCCH_v8_initialize.c) */
