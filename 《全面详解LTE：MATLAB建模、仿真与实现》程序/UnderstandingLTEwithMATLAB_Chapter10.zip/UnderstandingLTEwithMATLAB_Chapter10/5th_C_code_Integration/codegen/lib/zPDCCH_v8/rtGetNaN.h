/*
 * rtGetNaN.h
 *
 * Code generation for function 'zPDCCH_v8'
 *
 * C source code generated on: Tue Dec 31 15:43:43 2013
 *
 */

#ifndef __RTGETNAN_H__
#define __RTGETNAN_H__

#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif
/* End of code generation (rtGetNaN.h) */
