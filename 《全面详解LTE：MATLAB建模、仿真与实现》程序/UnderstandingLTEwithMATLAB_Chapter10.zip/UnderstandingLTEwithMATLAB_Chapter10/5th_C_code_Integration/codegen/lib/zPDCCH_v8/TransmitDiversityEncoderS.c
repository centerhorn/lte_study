/*
 * TransmitDiversityEncoderS.c
 *
 * Code generation for function 'TransmitDiversityEncoderS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "TransmitDiversityEncoderS.h"
#include "zPDCCH_v8_data.h"

/* Type Definitions */
#ifndef struct_comm_OSTBCEncoder_11
#define struct_comm_OSTBCEncoder_11

struct comm_OSTBCEncoder_11
{
  boolean_T S0_isInitialized;
  boolean_T S1_isReleased;
};

#endif                                 /*struct_comm_OSTBCEncoder_11*/

#ifndef typedef_comm_OSTBCEncoder_11
#define typedef_comm_OSTBCEncoder_11

typedef struct comm_OSTBCEncoder_11 comm_OSTBCEncoder_11;

#endif                                 /*typedef_comm_OSTBCEncoder_11*/

/* Variable Definitions */
static comm_OSTBCEncoder_11 hTDEnc;

/* Function Definitions */
void TransmitDiversityEncoderS(creal_T in[3108], creal_T y[6216])
{
  int i;
  comm_OSTBCEncoder_11 *obj;
  int inIdx;
  int outIdx;
  double y_im;

  /*  Alamouti Transmit Diversty Encoder */
  /*  Space-Frequency to Space-Time transformation */
  for (i = 0; i < 1554; i++) {
    in[1 + (i << 1)].re = -in[1 + (i << 1)].re;
    in[1 + (i << 1)].im = -(-in[1 + (i << 1)].im);
  }

  /*  STBC Alamouti      */
  /*  STBCENC Space-Time Block Encoder */
  /*  Outputs the Space-Time block encoded matrix */
  if (!hTDEnc_not_empty) {
    /*  Use same object for either scheme */
    obj = &hTDEnc;

    /* System object Constructor function: comm.OSTBCEncoder */
    obj->S0_isInitialized = FALSE;
    obj->S1_isReleased = FALSE;
    hTDEnc_not_empty = TRUE;
  }

  /*  Alamouti Space-Time Block Encoder */
  /* System object Outputs function: comm.OSTBCEncoder */
  for (i = 0; i < 1554; i++) {
    inIdx = i << 1;
    outIdx = i << 1;
    y[outIdx] = in[inIdx];
    y[outIdx + 3109].re = in[inIdx].re;
    y[outIdx + 3109].im = -in[inIdx].im;
    inIdx++;
    y[outIdx + 3108] = in[inIdx];
    y[outIdx + 1].re = -in[inIdx].re;
    y[outIdx + 1].im = -(-in[inIdx].im);
  }

  /*  Scale */
  for (i = 0; i < 6216; i++) {
    y_im = y[i].im;
    if (y[i].im == 0.0) {
      y[i].re /= 1.4142135623730951;
      y[i].im = 0.0;
    } else if (y[i].re == 0.0) {
      y[i].re = 0.0;
      y[i].im = y_im / 1.4142135623730951;
    } else {
      y[i].re /= 1.4142135623730951;
      y[i].im = y_im / 1.4142135623730951;
    }
  }
}

/* End of code generation (TransmitDiversityEncoderS.c) */
