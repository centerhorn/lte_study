/*
 * TransmitDiversityCombinerS.c
 *
 * Code generation for function 'TransmitDiversityCombinerS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "TransmitDiversityCombinerS.h"
#include "zPDCCH_v8_data.h"

/* Type Definitions */
#ifndef struct_comm_OSTBCCombiner_12
#define struct_comm_OSTBCCombiner_12

struct comm_OSTBCCombiner_12
{
  boolean_T S0_isInitialized;
  boolean_T S1_isReleased;
};

#endif                                 /*struct_comm_OSTBCCombiner_12*/

#ifndef typedef_comm_OSTBCCombiner_12
#define typedef_comm_OSTBCCombiner_12

typedef struct comm_OSTBCCombiner_12 comm_OSTBCCombiner_12;

#endif                                 /*typedef_comm_OSTBCCombiner_12*/

/* Variable Definitions */
static comm_OSTBCCombiner_12 hTDDec;

/* Function Definitions */
void TransmitDiversityCombinerS(creal_T in[6216], const creal_T chEst[12432],
  creal_T y[3108])
{
  int k;
  comm_OSTBCCombiner_12 *obj;
  int i;
  double divtyAcc0_re;
  double divtyAcc0_im;
  double divtyAcc1_re;
  double divtyAcc1_im;
  double chEgyAcc_re;
  int inChEstIdx;
  int inRxIdx;

  /*  Alamouti Transmit Diversty Combiner */
  /*  Scale */
  for (k = 0; k < 6216; k++) {
    in[k].re *= 1.4142135623730951;
    in[k].im *= 1.4142135623730951;
  }

  /*  STBC Alamouti    */
  /*  STBC_DEC STBC Combiner */
  if (!hTDDec_not_empty) {
    obj = &hTDDec;

    /* System object Constructor function: comm.OSTBCCombiner */
    obj->S0_isInitialized = FALSE;
    obj->S1_isReleased = FALSE;
    hTDDec_not_empty = TRUE;
  }

  /* System object Outputs function: comm.OSTBCCombiner */
  for (i = 0; i < 1554; i++) {
    divtyAcc0_re = 0.0;
    divtyAcc0_im = 0.0;
    divtyAcc1_re = 0.0;
    divtyAcc1_im = 0.0;
    chEgyAcc_re = 0.0;
    for (k = 0; k < 2; k++) {
      inChEstIdx = (i << 1) + k * 6216;
      inRxIdx = (i << 1) + k * 3108;
      divtyAcc0_re += chEst[inChEstIdx].re * in[inRxIdx].re - -chEst[inChEstIdx]
        .im * in[inRxIdx].im;
      divtyAcc0_im += chEst[inChEstIdx].re * in[inRxIdx].im + -chEst[inChEstIdx]
        .im * in[inRxIdx].re;
      chEgyAcc_re += chEst[inChEstIdx].re * chEst[inChEstIdx].re -
        -chEst[inChEstIdx].im * chEst[inChEstIdx].im;
      inChEstIdx += 3108;
      inRxIdx++;
      divtyAcc0_re += chEst[inChEstIdx].re * in[inRxIdx].re - chEst[inChEstIdx].
        im * -in[inRxIdx].im;
      divtyAcc0_im += chEst[inChEstIdx].re * -in[inRxIdx].im + chEst[inChEstIdx]
        .im * in[inRxIdx].re;
      chEgyAcc_re += chEst[inChEstIdx].re * chEst[inChEstIdx].re -
        -chEst[inChEstIdx].im * chEst[inChEstIdx].im;
      inRxIdx--;
      divtyAcc1_re += chEst[inChEstIdx].re * in[inRxIdx].re - -chEst[inChEstIdx]
        .im * in[inRxIdx].im;
      divtyAcc1_im += chEst[inChEstIdx].re * in[inRxIdx].im + -chEst[inChEstIdx]
        .im * in[inRxIdx].re;
      inChEstIdx -= 3108;
      inRxIdx++;
      divtyAcc1_re -= chEst[inChEstIdx].re * in[inRxIdx].re - chEst[inChEstIdx].
        im * -in[inRxIdx].im;
      divtyAcc1_im -= chEst[inChEstIdx].re * -in[inRxIdx].im + chEst[inChEstIdx]
        .im * in[inRxIdx].re;
    }

    k = i << 1;
    y[k].re = divtyAcc0_re / chEgyAcc_re;
    y[k].im = divtyAcc0_im / chEgyAcc_re;
    y[k + 1].re = divtyAcc1_re / chEgyAcc_re;
    y[k + 1].im = divtyAcc1_im / chEgyAcc_re;
  }

  /*  Space-Frequency to Space-Time transformation */
  for (k = 0; k < 1554; k++) {
    y[1 + (k << 1)].re = -y[1 + (k << 1)].re;
    y[1 + (k << 1)].im = -(-y[1 + (k << 1)].im);
  }
}

/* End of code generation (TransmitDiversityCombinerS.c) */
