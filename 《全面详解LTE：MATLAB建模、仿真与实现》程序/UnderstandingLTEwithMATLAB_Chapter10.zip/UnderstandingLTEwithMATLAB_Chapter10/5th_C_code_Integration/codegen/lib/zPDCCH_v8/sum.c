/*
 * sum.c
 *
 * Code generation for function 'sum'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "sum.h"

/* Function Definitions */
void sum(const creal_T x[12432], creal_T y[6216])
{
  int iy;
  int ixstart;
  int j;
  iy = -1;
  ixstart = 6215;
  for (j = 0; j < 6216; j++) {
    ixstart++;
    iy++;
    y[iy].re = x[ixstart - 6216].re + x[ixstart].re;
    y[iy].im = x[ixstart - 6216].im + x[ixstart].im;
  }
}

/* End of code generation (sum.c) */
