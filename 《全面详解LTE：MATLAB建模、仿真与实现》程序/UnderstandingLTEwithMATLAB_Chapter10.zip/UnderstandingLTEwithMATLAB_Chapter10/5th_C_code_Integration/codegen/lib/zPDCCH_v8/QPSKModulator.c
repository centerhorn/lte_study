/*
 * QPSKModulator.c
 *
 * Code generation for function 'QPSKModulator'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "QPSKModulator.h"

/* Function Definitions */
commcodegen_QPSKModulator *QPSKModulator_QPSKModulator(commcodegen_QPSKModulator
  *obj)
{
  commcodegen_QPSKModulator *b_obj;
  commcodegen_QPSKModulator *c_obj;
  comm_QPSKModulator_0 *d_obj;
  int i;
  static const double dv0[8] = { 0.70710678118654757, 0.70710678118654746,
    -0.70710678118654746, 0.70710678118654757, -0.70710678118654768,
    -0.70710678118654746, 0.70710678118654735, -0.70710678118654768 };

  b_obj = obj;
  c_obj = b_obj;
  c_obj->isInitialized = FALSE;
  c_obj->isReleased = FALSE;
  c_obj->inputDirectFeedthrough1 = FALSE;
  d_obj = &b_obj->cSFunObject;

  /* System object Constructor function: comm.QPSKModulator */
  d_obj->S0_isInitialized = FALSE;
  d_obj->S1_isReleased = FALSE;
  for (i = 0; i < 8; i++) {
    d_obj->P0_modmap[i] = dv0[i];
  }

  return b_obj;
}

/* End of code generation (QPSKModulator.c) */
