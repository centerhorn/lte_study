/*
 * filter.c
 *
 * Code generation for function 'filter'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "filter.h"

/* Function Definitions */
void b_filter(const double b[160], const creal_T x[32], const creal_T zi[636],
              creal_T y[32], creal_T zf[636])
{
  int offset;
  int c;
  creal_T dbuffer[160];
  int j;
  int jp;
  int k;
  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[159 * c], 159U * sizeof(creal_T));
    for (j = 0; j < 8; j++) {
      jp = j + offset;
      for (k = 0; k < 159; k++) {
        dbuffer[k] = dbuffer[k + 1];
      }

      dbuffer[159].re = 0.0;
      dbuffer[159].im = 0.0;
      for (k = 0; k < 160; k++) {
        dbuffer[k].re += x[jp].re * b[k];
        dbuffer[k].im += x[jp].im * b[k];
      }

      y[jp] = dbuffer[0];
    }

    memcpy(&zf[159 * c], &dbuffer[1], 159U * sizeof(creal_T));
    offset += 8;
  }
}

void c_filter(const double b[8], const creal_T x[32], creal_T y[32], creal_T zf
              [28])
{
  int offset;
  int c;
  creal_T dbuffer[8];
  int k;
  int j;
  int jp;
  offset = 0;
  for (c = 0; c < 4; c++) {
    for (k = 0; k < 7; k++) {
      dbuffer[k + 1].re = 0.0;
      dbuffer[k + 1].im = 0.0;
    }

    for (j = 0; j < 8; j++) {
      jp = j + offset;
      for (k = 0; k < 7; k++) {
        dbuffer[k] = dbuffer[k + 1];
      }

      dbuffer[7].re = 0.0;
      dbuffer[7].im = 0.0;
      for (k = 0; k < 8; k++) {
        dbuffer[k].re += x[jp].re * b[k];
        dbuffer[k].im += x[jp].im * b[k];
      }

      y[jp] = dbuffer[0];
    }

    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset += 8;
  }
}

void d_filter(const creal_T x_data[4], const creal_T zi[636], creal_T y_data[4],
              int y_size[2], creal_T zf[636])
{
  int offset;
  static const signed char iv18[2] = { 1, 4 };

  int c;
  creal_T dbuffer[160];
  int k;
  static const double dv13[160] = { 0.00020734022246414918,
    -0.00081084049909333313, -0.0015574285397763192, -0.001744277804318311,
    -0.0012638202399326, -0.00024120372103262581, 0.00098521912428867187,
    0.0019603354452729627, 0.0022660802529595242, 0.001687308405922621,
    0.00032861110455255669, -0.0013742489345842596, -0.0027745657431385456,
    -0.003243666239213479, -0.0024344983277827144, -0.00047521126365496956,
    0.0020029390932531678, 0.004045985574384489, 0.00472616938006913,
    0.0035390715061251578, 0.00068639299203620348, -0.0028963710224001529,
    -0.0058208275638068786, -0.0067635547685208309, -0.0050355983813114768,
    -0.000967589928717348, 0.0040813501835335417, 0.0081490951031496974,
    0.0094107184606608048, 0.0069626846175100615, 0.0013248295405041321,
    -0.0055893552474813226, -0.011090581578491038, -0.012734683083533324,
    -0.0093684616257651478, -0.0017656762675479459, 0.0074616877720527523,
    0.014725364488994945, 0.016827151678095408, 0.012320178286729943,
    0.002300854682371521, -0.0097586179841960448, -0.019172513859684135,
    -0.021827026573516817, -0.015921516640539195, -0.0029471349220455676,
    0.012576377707853947, 0.024625138177639842, 0.027963052144175386,
    0.02034573813254344, 0.0037327609946035544, -0.016081041065056985,
    -0.031421139997519151, -0.035641264358293845, -0.025904721030532915,
    -0.0047085120150009629, 0.020583084239321436, 0.040201716885208509,
    0.045645194054426311, 0.0332104684281104, 0.0059727769777884925,
    -0.026725549260968855, -0.052321720198655768, -0.059670612279128905,
    -0.04362023750768277, -0.0077370961885165814, 0.036063901870864876,
    0.071165493462922766, 0.082126313599517636, 0.060812924864894279,
    0.010533429310363503, -0.053543588654858768, -0.10819738867533979,
    -0.12922818389491864, -0.099603606538627071, -0.015959335624459343,
    0.10886799283037112, 0.24837271802487987, 0.36941749146410591,
    0.44168955337970589, 0.446623479913719, 0.3829454186073904,
    0.26705406259687203, 0.12811572707392149, -0.000545669714019206,
    -0.091013089730268087, -0.12829735295466771, -0.11356066308250336,
    -0.062252892878759271, 0.0019563659976709483, 0.055254750352941993,
    0.0810540769086944, 0.074335400084854217, 0.041815406726272639,
    -0.0017513405410259906, -0.03955219418317911, -0.058754260100062593,
    -0.054541342923408072, -0.030952203351685782, 0.0014681022696409066,
    0.030081943546751234, 0.04488853464960936, 0.04186060204827529,
    0.023823987372947972, -0.0012130833093049571, -0.023450014092414855,
    -0.035023711360047359, -0.032694972158886115, -0.018606590906680209,
    0.0009925164872346575, 0.018410523356918743, 0.027464464712022286,
    0.025611393944788365, 0.014548436845236174, -0.00080215518407318566,
    -0.014403268096425404, -0.021430033303521005, -0.019933677737479366,
    -0.011287377554718059, 0.0006379572131508303, 0.01114326938277216,
    0.016516636877191227, 0.015306149826107136, 0.0086299657977982735,
    -0.000497165081270339, -0.0084724024075379274, -0.012497113645997577,
    -0.011525812160140817, -0.0064642325371760522, 0.00037801447919415921,
    0.0062961393868087726, 0.009233676527135486, 0.008467638580821257,
    0.0047201285332940613, -0.00027933995198139723, -0.0045532364085178918,
    -0.0066354699086354106, -0.0060476543881273284, -0.0033497111290991693,
    0.00020026832234539715, 0.0031999201232901049, 0.0046361952698607128,
    0.0042032593774481387, 0.002316490753683796, -0.00014000490091163007,
    -0.0022011368943896138, -0.0031816533337982815, -0.0028822028317866811,
    -0.0015894356445932355, 9.7691279134238331E-5, 0.0015255463234707493,
    0.0022226084371633954, 0.0020362633301083998, 0.0011395387511910933,
    -7.2315723478944344E-5, -0.001142652224319771, -0.001710723025169674,
    -0.0016176733751603709, -0.00093789381302212453, 6.266263644144435E-5 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv18[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[159 * c], 159U * sizeof(creal_T));
    for (k = 0; k < 159; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[159].re = 0.0;
    dbuffer[159].im = 0.0;
    for (k = 0; k < 160; k++) {
      dbuffer[k].re += x_data[offset].re * dv13[k];
      dbuffer[k].im += x_data[offset].im * dv13[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[159 * c], &dbuffer[1], 159U * sizeof(creal_T));
    offset++;
  }
}

void e_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv19[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv14[8] = { -0.0019589738603249776, 0.0109082344693896,
    -0.035989677276361709, 0.10791557218888112, 0.9681927178992048,
    -0.061569262286000404, 0.014813780273185613, -0.0024025612507599893 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv19[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv14[k];
      dbuffer[k].im += x_data[offset].im * dv14[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void f_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv20[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv15[8] = { -0.00376453503293513, 0.021176872368889415,
    -0.0712703802736878, 0.22794835312566583, 0.90964787755623577,
    -0.10613792657749883, 0.026616398139977914, -0.0043858741222753987 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv20[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv15[k];
      dbuffer[k].im += x_data[offset].im * dv15[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void filter(const double b[160], const creal_T x[640], const creal_T zi[636],
            creal_T y[640], creal_T zf[636])
{
  int offset;
  int c;
  creal_T dbuffer[160];
  int j;
  int jp;
  int k;
  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[159 * c], 159U * sizeof(creal_T));
    for (j = 0; j < 160; j++) {
      jp = j + offset;
      for (k = 0; k < 159; k++) {
        dbuffer[k] = dbuffer[k + 1];
      }

      dbuffer[159].re = 0.0;
      dbuffer[159].im = 0.0;
      for (k = 0; k < 160; k++) {
        dbuffer[k].re += x[jp].re * b[k];
        dbuffer[k].im += x[jp].im * b[k];
      }

      y[jp] = dbuffer[0];
    }

    memcpy(&zf[159 * c], &dbuffer[1], 159U * sizeof(creal_T));
    offset += 160;
  }
}

void g_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv21[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv16[8] = { -0.0052572973707263517, 0.029894617451689004,
    -0.1028141798547984, 0.35522105070832621, 0.82754879586814256,
    -0.13380513634594685, 0.034801520990625751, -0.0058200453803686977 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv21[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv16[k];
      dbuffer[k].im += x_data[offset].im * dv16[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void h_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv22[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv17[8] = { -0.00629795036486299, 0.036223512333436354,
    -0.12757732587818868, 0.48438115499037193, 0.72600168782452,
    -0.14545302205145352, 0.03907848141175424, -0.0066261522652795949 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv22[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv17[k];
      dbuffer[k].im += x_data[offset].im * dv17[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void i_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv23[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv18[8] = { -0.00677751383068747, 0.039457774230985246,
    -0.14265809342844146, 0.60983636066166247, 0.60983636066166247,
    -0.14265809342844146, 0.039457774230985246, -0.00677751383068747 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv23[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv18[k];
      dbuffer[k].im += x_data[offset].im * dv18[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void j_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv24[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv19[8] = { -0.0066261522652795949, 0.03907848141175424,
    -0.14545302205145352, 0.72600168782452, 0.48438115499037193,
    -0.12757732587818868, 0.036223512333436354, -0.00629795036486299 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv24[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv19[k];
      dbuffer[k].im += x_data[offset].im * dv19[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void k_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv25[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv20[8] = { -0.0058200453803686977, 0.034801520990625751,
    -0.13380513634594685, 0.82754879586814256, 0.35522105070832621,
    -0.1028141798547984, 0.029894617451689004, -0.0052572973707263517 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv25[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv20[k];
      dbuffer[k].im += x_data[offset].im * dv20[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void l_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv26[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv21[8] = { -0.0043858741222753987, 0.026616398139977914,
    -0.10613792657749883, 0.90964787755623577, 0.22794835312566583,
    -0.0712703802736878, 0.021176872368889415, -0.00376453503293513 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv26[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv21[k];
      dbuffer[k].im += x_data[offset].im * dv21[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void m_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv27[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv22[8] = { -0.0024025612507599893, 0.014813780273185613,
    -0.061569262286000404, 0.9681927178992048, 0.10791557218888112,
    -0.035989677276361709, 0.0109082344693896, -0.0019589738603249776 };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv27[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv22[k];
      dbuffer[k].im += x_data[offset].im * dv22[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

void n_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4],
              int y_size[2], creal_T zf[28])
{
  int offset;
  static const signed char iv28[2] = { 1, 4 };

  int c;
  creal_T dbuffer[8];
  int k;
  static const double dv23[8] = { -2.0499417134388578E-13,
    6.8058746136427585E-13, -1.234126341546299E-12, 1.000000000001485,
    -1.234126341546299E-12, 6.8058746136427585E-13, -2.0499417134388578E-13, 0.0
  };

  for (offset = 0; offset < 2; offset++) {
    y_size[offset] = iv28[offset];
  }

  offset = 0;
  for (c = 0; c < 4; c++) {
    memcpy(&dbuffer[1], &zi[7 * c], 7U * sizeof(creal_T));
    for (k = 0; k < 7; k++) {
      dbuffer[k] = dbuffer[k + 1];
    }

    dbuffer[7].re = 0.0;
    dbuffer[7].im = 0.0;
    for (k = 0; k < 8; k++) {
      dbuffer[k].re += x_data[offset].re * dv23[k];
      dbuffer[k].im += x_data[offset].im * dv23[k];
    }

    y_data[offset] = dbuffer[0];
    memcpy(&zf[7 * c], &dbuffer[1], 7U * sizeof(creal_T));
    offset++;
  }
}

/* End of code generation (filter.c) */
