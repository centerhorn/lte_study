/*
 * fcn_Descrambler.c
 *
 * Code generation for function 'fcn_Descrambler'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "fcn_Descrambler.h"
#include "step.h"
#include "zPDCCH_v8_emxutil.h"
#include "SystemCore.h"
#include "GoldSequence.h"

/* Type Definitions */
#ifndef struct_comm_IntegerToBit_13
#define struct_comm_IntegerToBit_13

struct comm_IntegerToBit_13
{
  boolean_T S0_isInitialized;
  boolean_T S1_isReleased;
};

#endif                                 /*struct_comm_IntegerToBit_13*/

#ifndef typedef_comm_IntegerToBit_13
#define typedef_comm_IntegerToBit_13

typedef struct comm_IntegerToBit_13 comm_IntegerToBit_13;

#endif                                 /*typedef_comm_IntegerToBit_13*/

/* Variable Definitions */
static comm_GoldSequence_3 b_hSeqGen;
static boolean_T b_hSeqGen_not_empty;
static comm_IntegerToBit_13 b_hInt2Bit;

/* Function Definitions */
void b_hSeqGen_not_empty_init(void)
{
  b_hSeqGen_not_empty = FALSE;
}

void fcn_Descrambler(const double u[6216], double nS, double y[6216])
{
  comm_IntegerToBit_13 *obj;
  int bitIdx;
  unsigned int b_u;
  int j;
  double iniStates[31];
  emxArray_real_T *r1;

  /*    Downlink descrambling   */
  if (!b_hSeqGen_not_empty) {
    b_GoldSequence_GoldSequence(&b_hSeqGen);
    b_hSeqGen_not_empty = TRUE;
    obj = &b_hInt2Bit;

    /* System object Constructor function: comm.IntegerToBit */
    obj->S0_isInitialized = FALSE;
    obj->S1_isReleased = FALSE;
  }

  /*  Initial conditions */
  /*  Convert to binary vector */
  /* System object Outputs function: comm.IntegerToBit */
  /* Integer to Bit Conversion */
  bitIdx = 30;
  b_u = (unsigned int)(16384.0 + floor(nS / 2.0) * 512.0);
  for (j = 0; j < 31; j++) {
    iniStates[bitIdx] = (int)b_u & 1;
    b_u >>= 1;
    bitIdx--;
  }

  emxInit_real_T(&r1, 2);

  /*  Generate scrambling sequence */
  f_SystemCore_step(&b_hSeqGen, iniStates, r1);

  /*  Descramble */
  for (bitIdx = 0; bitIdx < 6216; bitIdx++) {
    y[bitIdx] = (((u[bitIdx] != 0.0) ^ (r1->data[bitIdx] != 0.0)) != 0);
  }

  emxFree_real_T(&r1);
}

void fcn_Descrambler_free(void)
{
  d_Destructor(&b_hSeqGen.cGenerator.pFirstSequence);
}

/* End of code generation (fcn_Descrambler.c) */
