/*
 * Nondirect1.c
 *
 * Code generation for function 'Nondirect1'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "Nondirect1.h"

/* Function Definitions */
void Nondirect_stepImpl(const double varargin_1[2072], double varargout_1[2048])
{
  int bitNumber;
  int i;
  int j;

  /* System object Outputs function: comm.CRCDetector */
  /* Initialize for current sub-frame */
  bitNumber = 0;
  for (i = 0; i < 259; i++) {
    for (j = 0; j < 8; j++) {
      if (bitNumber < 2048) {
        varargout_1[bitNumber] = (unsigned int)varargin_1[bitNumber] & 1U;

        /* Build input data chunk */
        bitNumber++;
      }
    }

    /* Retrieve value from CRC table and update register */
  }

  /* Process the leftover bits */
  /* Apply final XOR */
  /* Output flag to indicate if error occurred (0 => no error) */
}

/* End of code generation (Nondirect1.c) */
