/*
 * permute.c
 *
 * Code generation for function 'permute'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "permute.h"

/* Function Definitions */
void permute(const creal_T a[12432], creal_T b[12432])
{
  short outsz[4];
  int iwork[4];
  int k;
  static const short iv29[4] = { 3108, 2, 2, 1 };

  int inc[4];
  static const signed char iv30[4] = { 0, 3, 2, 1 };

  int idest;
  int isrc;
  int32_T exitg1;
  outsz[0] = 3108;
  outsz[1] = 1;
  outsz[2] = 2;
  outsz[3] = 2;
  for (k = 0; k < 4; k++) {
    iwork[k] = 1;
  }

  for (k = 0; k < 2; k++) {
    iwork[k + 1] = iwork[k] * iv29[k];
  }

  iwork[3] = iwork[2];
  for (k = 0; k < 4; k++) {
    inc[k] = iwork[iv30[k]];
  }

  for (k = 0; k < 4; k++) {
    iwork[k] = 0;
  }

  idest = 0;
  do {
    isrc = 0;
    for (k = 0; k < 3; k++) {
      isrc += iwork[k + 1] * inc[k + 1];
    }

    for (k = 0; k < 3108; k++) {
      b[idest] = a[isrc];
      idest++;
      isrc += inc[0];
    }

    k = 1;
    do {
      exitg1 = 0;
      iwork[k]++;
      if (iwork[k] < outsz[k]) {
        exitg1 = 2;
      } else if (k + 1 == 4) {
        exitg1 = 1;
      } else {
        iwork[k] = 0;
        k++;
      }
    } while (exitg1 == 0);
  } while (!(exitg1 == 1));
}

/* End of code generation (permute.c) */
