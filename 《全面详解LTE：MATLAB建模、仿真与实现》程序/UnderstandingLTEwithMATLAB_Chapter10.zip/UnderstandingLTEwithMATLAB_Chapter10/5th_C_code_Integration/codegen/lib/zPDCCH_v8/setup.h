/*
 * setup.h
 *
 * Code generation for function 'setup'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __SETUP_H__
#define __SETUP_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void InitializeConditions(comm_ViterbiDecoder_5 *obj);
extern void e_Destructor(comm_ViterbiDecoder_5 *obj);
extern void f_Destructor(comm_ErrorRate_2 *obj);
#endif
/* End of code generation (setup.h) */
