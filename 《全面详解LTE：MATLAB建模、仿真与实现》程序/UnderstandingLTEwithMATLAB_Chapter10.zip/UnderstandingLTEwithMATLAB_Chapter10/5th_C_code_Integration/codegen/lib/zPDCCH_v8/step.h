/*
 * step.h
 *
 * Code generation for function 'step'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __STEP_H__
#define __STEP_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void Destructor(comm_ConvolutionalEncoder_3 *obj);
extern void b_Destructor(comm_ConvolutionalEncoder_4 *obj);
extern void c_Destructor(comm_PNSequence_9 *obj);
extern void d_Destructor(comm_PNSequence_14 *obj);
#endif
/* End of code generation (step.h) */
