/*
 * SystemCore.h
 *
 * Code generation for function 'SystemCore'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __SYSTEMCORE_H__
#define __SYSTEMCORE_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void SystemCore_reset(commcodegen_ErrorRate *obj);
extern void SystemCore_step(commcodegen_CRCGenerator *obj, const double varargin_1[2048], double varargout_1[2072]);
extern void b_SystemCore_step(comm_GoldSequence_2 *obj, const double varargin_1[31], emxArray_real_T *varargout_1);
extern void c_SystemCore_step(commcodegen_QPSKModulator *obj, const double varargin_1[6216], creal_T varargout_1[3108]);
extern void d_SystemCore_step(comm_MIMOChannel *obj, const creal_T varargin_1[6216], creal_T varargout_1[6216], creal_T varargout_2[12432]);
extern void e_SystemCore_step(comm_AWGNChannel *obj, const creal_T varargin_1[6216], double varargin_2, creal_T varargout_1[6216]);
extern void f_SystemCore_step(comm_GoldSequence_3 *obj, const double varargin_1[31], emxArray_real_T *varargout_1);
extern void g_SystemCore_step(commcodegen_ViterbiDecoder *obj, const double varargin_1[12432], double varargout_1[4144]);
extern void h_SystemCore_step(commcodegen_CRCDetector *obj, const double varargin_1[2072], double varargout_1[2048]);
extern void i_SystemCore_step(commcodegen_ErrorRate *obj, const double varargin_1[2048], const double varargin_2[2048], double varargout_1[3]);
#endif
/* End of code generation (SystemCore.h) */
