/*
 * floor.c
 *
 * Code generation for function 'floor'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "floor.h"

/* Function Definitions */
void b_floor(double x[3108])
{
  int k;
  for (k = 0; k < 3108; k++) {
    x[k] = floor(x[k]);
  }
}

/* End of code generation (floor.c) */
