/*
 * Alamouti_EncoderS.h
 *
 * Code generation for function 'Alamouti_EncoderS'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __ALAMOUTI_ENCODERS_H__
#define __ALAMOUTI_ENCODERS_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void hTDEnc_not_empty_init(void);
#endif
/* End of code generation (Alamouti_EncoderS.h) */
