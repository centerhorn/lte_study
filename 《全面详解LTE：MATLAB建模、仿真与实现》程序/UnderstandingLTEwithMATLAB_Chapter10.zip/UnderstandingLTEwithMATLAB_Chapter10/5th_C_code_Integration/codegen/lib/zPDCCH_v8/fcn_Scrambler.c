/*
 * fcn_Scrambler.c
 *
 * Code generation for function 'fcn_Scrambler'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "fcn_Scrambler.h"
#include "step.h"
#include "zPDCCH_v8_emxutil.h"
#include "SystemCore.h"
#include "GoldSequence.h"

/* Type Definitions */
#ifndef struct_comm_IntegerToBit_8
#define struct_comm_IntegerToBit_8

struct comm_IntegerToBit_8
{
  boolean_T S0_isInitialized;
  boolean_T S1_isReleased;
};

#endif                                 /*struct_comm_IntegerToBit_8*/

#ifndef typedef_comm_IntegerToBit_8
#define typedef_comm_IntegerToBit_8

typedef struct comm_IntegerToBit_8 comm_IntegerToBit_8;

#endif                                 /*typedef_comm_IntegerToBit_8*/

/* Variable Definitions */
static comm_GoldSequence_2 hSeqGen;
static boolean_T hSeqGen_not_empty;
static comm_IntegerToBit_8 hInt2Bit;

/* Function Definitions */
void fcn_Scrambler(const double u[6216], double nS, double y[6216])
{
  comm_IntegerToBit_8 *obj;
  int bitIdx;
  unsigned int b_u;
  int j;
  double iniStates[31];
  emxArray_real_T *r0;

  /*    Downlink scrambling  */
  if (!hSeqGen_not_empty) {
    GoldSequence_GoldSequence(&hSeqGen);
    hSeqGen_not_empty = TRUE;
    obj = &hInt2Bit;

    /* System object Constructor function: comm.IntegerToBit */
    obj->S0_isInitialized = FALSE;
    obj->S1_isReleased = FALSE;
  }

  /*  Initial conditions */
  /*  Convert initial condition to binary vector */
  /* System object Outputs function: comm.IntegerToBit */
  /* Integer to Bit Conversion */
  bitIdx = 30;
  b_u = (unsigned int)(16384.0 + floor(nS / 2.0) * 512.0);
  for (j = 0; j < 31; j++) {
    iniStates[bitIdx] = (int)b_u & 1;
    b_u >>= 1;
    bitIdx--;
  }

  emxInit_real_T(&r0, 2);

  /*  Generate the scrambling sequence */
  b_SystemCore_step(&hSeqGen, iniStates, r0);

  /*  Scramble input with the scrambling sequence */
  for (bitIdx = 0; bitIdx < 6216; bitIdx++) {
    y[bitIdx] = (((u[bitIdx] != 0.0) ^ (r0->data[bitIdx] != 0.0)) != 0);
  }

  emxFree_real_T(&r0);
}

void fcn_Scrambler_free(void)
{
  c_Destructor(&hSeqGen.cGenerator.pFirstSequence);
}

void hSeqGen_not_empty_init(void)
{
  hSeqGen_not_empty = FALSE;
}

/* End of code generation (fcn_Scrambler.c) */
