/*
 * Nondirect1.h
 *
 * Code generation for function 'Nondirect1'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __NONDIRECT1_H__
#define __NONDIRECT1_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void Nondirect_stepImpl(const double varargin_1[2072], double varargout_1[2048]);
#endif
/* End of code generation (Nondirect1.h) */
