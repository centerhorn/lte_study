/*
 * ErrorRate.c
 *
 * Code generation for function 'ErrorRate'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "ErrorRate.h"

/* Function Definitions */
commcodegen_ErrorRate *ErrorRate_ErrorRate(commcodegen_ErrorRate *obj)
{
  commcodegen_ErrorRate *b_obj;
  commcodegen_ErrorRate *c_obj;
  comm_ErrorRate_2 *d_obj;
  b_obj = obj;
  c_obj = b_obj;
  c_obj->isInitialized = FALSE;
  c_obj->isReleased = FALSE;
  c_obj->inputDirectFeedthrough1 = FALSE;
  c_obj->inputDirectFeedthrough2 = FALSE;
  d_obj = &b_obj->cSFunObject;

  /* System object Constructor function: comm.ErrorRate */
  d_obj->S0_isInitialized = FALSE;
  d_obj->S1_isReleased = FALSE;
  return b_obj;
}

/* End of code generation (ErrorRate.c) */
