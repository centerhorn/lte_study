/*
 * rand.c
 *
 * Code generation for function 'rand'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "rand.h"
#include "randn.h"
#include "zPDCCH_v8_data.h"

/* Function Definitions */
void b_rand(double r[2048])
{
  unsigned int uv2[625];
  int k;
  double d0;
  if (!state_not_empty) {
    eml_rand_mt19937ar(uv2);
    memcpy(&state[0], &uv2[0], 625U * sizeof(unsigned int));
    state_not_empty = TRUE;
  }

  for (k = 0; k < 2048; k++) {
    d0 = genrandu(state);
    r[k] = d0;
  }
}

/* End of code generation (rand.c) */
