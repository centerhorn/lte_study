/*
 * FadingChannel.c
 *
 * Code generation for function 'FadingChannel'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "FadingChannel.h"
#include "SystemProp.h"
#include "permute.h"
#include "sum.h"
#include "repmat.h"
#include "mod.h"
#include "floor.h"
#include "diff.h"
#include "filter.h"
#include "randn.h"
#include "zPDCCH_v8_rtwutil.h"

/* Type Definitions */
#ifndef struct_emxArray_creal_T_2x4
#define struct_emxArray_creal_T_2x4

struct emxArray_creal_T_2x4
{
  creal_T data[8];
  int size[2];
};

#endif                                 /*struct_emxArray_creal_T_2x4*/

#ifndef typedef_emxArray_creal_T_2x4
#define typedef_emxArray_creal_T_2x4

typedef struct emxArray_creal_T_2x4 emxArray_creal_T_2x4;

#endif                                 /*typedef_emxArray_creal_T_2x4*/

/* Function Declarations */
static void FadingChannel_channelFilter(const creal_T x[6216], const creal_T
  pathGains[12432], const double activeMIdx[4], creal_T y[6216]);
static void FadingChannel_scalePathGains(const creal_T z[12432], creal_T g[12432]);
static void b_FadingChannel_generatePathGai(comm_MIMOChannel *obj, creal_T y
  [12432]);
static void c_FadingChannel_polyphaseFilter(comm_MIMOChannel *obj, double N,
  creal_T y_data[8], int y_size[2]);
static void e_FadingChannel_GFilterGenerate(comm_MIMOChannel *obj, creal_T
  y_data[4], int y_size[2]);
static double rt_remd_snf(double u0, double u1);

/* Function Definitions */
static void FadingChannel_channelFilter(const creal_T x[6216], const creal_T
  pathGains[12432], const double activeMIdx[4], creal_T y[6216])
{
  static creal_T b_x[12432];
  int k;
  static creal_T z[12432];
  static creal_T g[12432];
  static creal_T c_x[12432];
  static creal_T b_y[12432];
  static creal_T c_y[12432];
  for (k = 0; k < 4; k++) {
    memcpy(&b_x[3108 * k], &pathGains[3108 * ((int)activeMIdx[k] - 1)], 3108U *
           sizeof(creal_T));
  }

  b_repmat(x, c_x);
  for (k = 0; k < 12432; k++) {
    z[k] = b_x[k];
    g[k] = z[k];
    b_y[k] = c_x[k];
    c_y[k].re = b_y[k].re * g[k].re - b_y[k].im * g[k].im;
    c_y[k].im = b_y[k].re * g[k].im + b_y[k].im * g[k].re;
  }

  sum(c_y, y);
}

static void FadingChannel_scalePathGains(const creal_T z[12432], creal_T g[12432])
{
  int i12;
  for (i12 = 0; i12 < 12432; i12++) {
    g[i12].re = z[i12].re;
    g[i12].im = z[i12].im;
  }
}

static void b_FadingChannel_generatePathGai(comm_MIMOChannel *obj, creal_T y
  [12432])
{
  double startIdx;
  double numNewOutputs;
  int i;
  int i10;
  creal_T prevOutputs_data[8];
  int newOutputs_size[2];
  creal_T newOutputs_data[8];
  int linearInterpSamples_size[2];
  int i11;
  creal_T linearInterpSamples_data[16];
  int loop_ub;
  creal_T tmp_data[12];
  creal_T D_data[16];
  static double k[3108];
  double b;
  static double b_b[3108];
  double c_b[3108];
  static double dv25[12432];
  startIdx = obj->pLinearInterpIndex;
  numNewOutputs = ceil((((startIdx + 3108.0) - 1.0) - 1.0) / 4389.0);
  if (startIdx <= 2.0) {
    i = 1;
    for (i10 = 0; i10 < 4; i10++) {
      prevOutputs_data[i10] = obj->pIFilterLastOutputs[1 + (i10 << 1)];
    }

    numNewOutputs = (numNewOutputs + 1.0) - 1.0;
  } else {
    i = 2;
    for (i10 = 0; i10 < 8; i10++) {
      prevOutputs_data[i10] = obj->pIFilterLastOutputs[i10];
    }

    numNewOutputs = (numNewOutputs + 1.0) - 2.0;
  }

  if ((numNewOutputs > 0.0) && (numNewOutputs <= 2.0)) {
    c_FadingChannel_polyphaseFilter(obj, numNewOutputs, newOutputs_data,
      newOutputs_size);
    linearInterpSamples_size[0] = i + newOutputs_size[0];
    linearInterpSamples_size[1] = 4;
    for (i10 = 0; i10 < 4; i10++) {
      for (i11 = 0; i11 < i; i11++) {
        linearInterpSamples_data[i11 + linearInterpSamples_size[0] * i10] =
          prevOutputs_data[i11 + i * i10];
      }
    }

    for (i10 = 0; i10 < 4; i10++) {
      loop_ub = newOutputs_size[0];
      for (i11 = 0; i11 < loop_ub; i11++) {
        linearInterpSamples_data[(i11 + i) + linearInterpSamples_size[0] * i10] =
          newOutputs_data[i11 + newOutputs_size[0] * i10];
      }
    }
  } else {
    linearInterpSamples_size[0] = i;
    linearInterpSamples_size[1] = 4;
    loop_ub = i * 4;
    for (i10 = 0; i10 < loop_ub; i10++) {
      linearInterpSamples_data[i10] = prevOutputs_data[i10];
    }
  }

  diff(linearInterpSamples_data, linearInterpSamples_size, tmp_data,
       newOutputs_size);
  for (i10 = 0; i10 < 4; i10++) {
    loop_ub = newOutputs_size[0];
    for (i11 = 0; i11 < loop_ub; i11++) {
      D_data[i11 + (newOutputs_size[0] + 1) * i10] = tmp_data[i11 +
        newOutputs_size[0] * i10];
    }
  }

  for (i10 = 0; i10 < 4; i10++) {
    D_data[newOutputs_size[0] + (newOutputs_size[0] + 1) * i10].re = 0.0;
    D_data[newOutputs_size[0] + (newOutputs_size[0] + 1) * i10].im = 0.0;
  }

  numNewOutputs = obj->pLinearInterpIndex - 1.0;
  for (i10 = 0; i10 < 3108; i10++) {
    b = (numNewOutputs + (double)i10) / 4389.0;
    k[i10] = b;
    b_b[i10] = b;
  }

  b_floor(k);
  for (i = 0; i < 3108; i++) {
    c_b[i] = b_b[i] - k[i];
  }

  repmat(c_b, dv25);
  for (i10 = 0; i10 < 4; i10++) {
    for (i11 = 0; i11 < 3108; i11++) {
      y[i11 + 3108 * i10].re = linearInterpSamples_data[((int)(k[i11] + 1.0) +
        linearInterpSamples_size[0] * i10) - 1].re + dv25[i11 + 3108 * i10] *
        D_data[((int)(k[i11] + 1.0) + (newOutputs_size[0] + 1) * i10) - 1].re;
      y[i11 + 3108 * i10].im = linearInterpSamples_data[((int)(k[i11] + 1.0) +
        linearInterpSamples_size[0] * i10) - 1].im + dv25[i11 + 3108 * i10] *
        D_data[((int)(k[i11] + 1.0) + (newOutputs_size[0] + 1) * i10) - 1].im;
    }
  }

  j_SystemProp_matlabCodegenSetAn(obj, rt_remd_snf((startIdx + 3108.0) - 1.0,
    4389.0) + 1.0);
}

static void c_FadingChannel_polyphaseFilter(comm_MIMOChannel *obj, double N,
  creal_T y_data[8], int y_size[2])
{
  double startPhase;
  double cdiff;
  double m0;
  int ndbl;
  int apnd;
  double b_y_data[2];
  int i7;
  int i8;
  creal_T y[8];
  int x_size[2];
  creal_T x_data[4];
  creal_T filterOut_data[40];
  signed char filterOut_size[2];
  static const signed char iv16[2] = { 10, 4 };

  creal_T filterState[280];
  creal_T dcv10[28];
  creal_T tmp_data[4];
  creal_T filterOut[40];
  y_size[0] = (int)N;
  y_size[1] = 4;
  startPhase = b_mod(obj->pIFilterPhase, 10.0) + 1.0;
  cdiff = b_mod(10.0 - (startPhase - 1.0), 10.0);
  if ((cdiff <= N) || rtIsNaN(N)) {
    m0 = cdiff;
  } else {
    m0 = N;
  }

  if (m0 > 0.0) {
    if (m0 < 1.0) {
      ndbl = 0;
      cdiff = m0;
    } else {
      ndbl = (int)floor((m0 - 1.0) + 0.5);
      apnd = ndbl + 1;
      cdiff = (1.0 + (double)ndbl) - m0;
      if (fabs(cdiff) < 4.4408920985006262E-16 * m0) {
        ndbl++;
        cdiff = m0;
      } else if (cdiff > 0.0) {
        cdiff = 1.0 + ((double)ndbl - 1.0);
      } else {
        ndbl++;
        cdiff = apnd;
      }
    }

    if (ndbl > 0) {
      b_y_data[0] = 1.0;
      if (ndbl > 1) {
        b_y_data[0] = 1.0;
        b_y_data[1] = cdiff;
      }
    }

    for (i7 = 0; i7 < 4; i7++) {
      for (i8 = 0; i8 < ndbl; i8++) {
        y[i8 + ndbl * i7] = obj->pIFilterNewSampLastOut[((int)((b_y_data[i8] +
          startPhase) - 1.0) + 10 * i7) - 1];
      }
    }

    for (i7 = 0; i7 < 4; i7++) {
      for (i8 = 0; i8 < ndbl; i8++) {
        y_data[i8 + (int)N * i7] = y[i8 + ndbl * i7];
      }
    }
  }

  cdiff = ceil((N - m0) / 10.0);
  if ((cdiff > 0.0) && (cdiff <= 1.0)) {
    e_FadingChannel_GFilterGenerate(obj, x_data, x_size);
    for (i7 = 0; i7 < 2; i7++) {
      filterOut_size[i7] = iv16[i7];
    }

    for (i7 = 0; i7 < 280; i7++) {
      filterState[i7] = obj->pIFilterState[i7];
    }

    e_filter(x_data, *(creal_T (*)[28])&filterState[0], tmp_data, x_size, dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * i7], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    f_filter(x_data, *(creal_T (*)[28])&filterState[28], tmp_data, x_size, dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[1 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (4 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    g_filter(x_data, *(creal_T (*)[28])&filterState[56], tmp_data, x_size, dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[2 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (8 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    h_filter(x_data, *(creal_T (*)[28])&filterState[84], tmp_data, x_size, dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[3 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (12 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    i_filter(x_data, *(creal_T (*)[28])&filterState[112], tmp_data, x_size,
             dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[4 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (16 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    j_filter(x_data, *(creal_T (*)[28])&filterState[140], tmp_data, x_size,
             dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[5 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (20 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    k_filter(x_data, *(creal_T (*)[28])&filterState[168], tmp_data, x_size,
             dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[6 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (24 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    l_filter(x_data, *(creal_T (*)[28])&filterState[196], tmp_data, x_size,
             dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[7 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (28 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    m_filter(x_data, *(creal_T (*)[28])&filterState[224], tmp_data, x_size,
             dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[8 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (32 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    n_filter(x_data, *(creal_T (*)[28])&filterState[252], tmp_data, x_size,
             dcv10);
    for (i7 = 0; i7 < 4; i7++) {
      filterOut_data[9 + filterOut_size[0] * i7] = tmp_data[x_size[0] * i7];
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterState[7 * (36 + i7)], &dcv10[7 * i7], 7U * sizeof(creal_T));
    }

    f_SystemProp_matlabCodegenSetAn(obj, filterState);
    cdiff = N - m0;
    if (1.0 > cdiff) {
      apnd = -1;
    } else {
      apnd = (int)cdiff - 1;
    }

    if (m0 + 1.0 > N) {
      i7 = 0;
    } else {
      i7 = (int)(m0 + 1.0) - 1;
    }

    for (i8 = 0; i8 < 4; i8++) {
      for (ndbl = 0; ndbl <= apnd; ndbl++) {
        y_data[(i7 + ndbl) + (int)N * i8] = filterOut_data[ndbl +
          filterOut_size[0] * i8];
      }
    }

    for (i7 = 0; i7 < 4; i7++) {
      memcpy(&filterOut[10 * i7], &filterOut_data[filterOut_size[0] * i7], 10U *
             sizeof(creal_T));
    }

    g_SystemProp_matlabCodegenSetAn(obj, filterOut);
  }

  h_SystemProp_matlabCodegenSetAn(obj, b_mod((startPhase + (N - 1.0)) - 1.0,
    10.0) + 1.0);
  if (N == 1.0) {
    for (i7 = 0; i7 < 4; i7++) {
      y[i7 << 1] = obj->pIFilterLastOutputs[1 + (i7 << 1)];
    }

    for (i7 = 0; i7 < 4; i7++) {
      y[1 + (i7 << 1)] = y_data[i7];
    }

    i_SystemProp_matlabCodegenSetAn(obj, y);
  } else {
    for (i7 = 0; i7 < 4; i7++) {
      for (i8 = 0; i8 < 2; i8++) {
        y[i8 + (i7 << 1)] = y_data[((int)((double)(int)N - (1.0 - (double)i8)) +
                                    (int)N * i7) - 1];
      }
    }

    i_SystemProp_matlabCodegenSetAn(obj, y);
  }
}

static void e_FadingChannel_GFilterGenerate(comm_MIMOChannel *obj, creal_T
  y_data[4], int y_size[2])
{
  double w2_data[8];
  signed char w2_size[2];
  int i;
  static const signed char iv17[2] = { 1, 8 };

  unsigned int b_state[625];
  creal_T tmp_data[4];
  creal_T dcv11[636];
  for (i = 0; i < 2; i++) {
    w2_size[i] = iv17[i];
  }

  for (i = 0; i < 625; i++) {
    b_state[i] = obj->pWGNState[i];
  }

  for (i = 0; i < 8; i++) {
    w2_data[w2_size[0] * i] = c_eml_rand_mt19937ar(b_state);
  }

  d_SystemProp_matlabCodegenSetAn(obj, b_state);
  for (i = 0; i < 4; i++) {
    tmp_data[i].re = 0.70710678118654746 * (w2_data[w2_size[0] * i] + 0.0 *
      w2_data[w2_size[0] * (4 + i)]);
    tmp_data[i].im = 0.70710678118654746 * w2_data[w2_size[0] * (4 + i)];
  }

  d_filter(tmp_data, obj->pGFilterState, y_data, y_size, dcv11);
  e_SystemProp_matlabCodegenSetAn(obj, dcv11);
}

static double rt_remd_snf(double u0, double u1)
{
  double y;
  double b_u1;
  double tr;
  if (u1 < 0.0) {
    b_u1 = ceil(u1);
  } else {
    b_u1 = floor(u1);
  }

  if ((u1 != 0.0) && (u1 != b_u1) && ((!rtIsNaN(u0)) && (!rtIsInf(u0)) &&
       ((!rtIsNaN(u1)) && (!rtIsInf(u1))))) {
    tr = u0 / u1;
    if (fabs(tr - rt_roundd_snf(tr)) <= DBL_EPSILON * fabs(tr)) {
      y = 0.0;
    } else {
      y = fmod(u0, u1);
    }
  } else {
    y = fmod(u0, u1);
  }

  return y;
}

void FadingChannel_generatePathGains(comm_MIMOChannel *obj)
{
  double startIdx;
  double numNewOutputs;
  emxArray_creal_T_2x4 b_obj;
  comm_MIMOChannel *c_obj;
  startIdx = obj->pLinearInterpIndex;
  numNewOutputs = ceil((((startIdx + 1.0) - 1.0) - 1.0) / 4389.0);
  if (startIdx <= 2.0) {
    numNewOutputs = (numNewOutputs + 1.0) - 1.0;
  } else {
    numNewOutputs = (numNewOutputs + 1.0) - 2.0;
  }

  if ((numNewOutputs > 0.0) && (numNewOutputs <= 2.0)) {
    c_FadingChannel_polyphaseFilter(obj, numNewOutputs, b_obj.data, b_obj.size);
  }

  c_obj = obj;
  c_obj->pLinearInterpIndex = rt_remd_snf((startIdx + 1.0) - 1.0, 4389.0) + 1.0;
}

void FadingChannel_stepImpl(comm_MIMOChannel *obj, const creal_T x[6216],
  creal_T varargout_1[6216], creal_T varargout_2[12432])
{
  static creal_T z[12432];
  static creal_T b_z[12432];
  double dv24[4];
  int i9;
  double varargout_2_im;
  static creal_T y[12432];
  b_FadingChannel_generatePathGai(obj, z);
  memcpy(&b_z[0], &z[0], 12432U * sizeof(creal_T));
  FadingChannel_scalePathGains(b_z, z);
  for (i9 = 0; i9 < 4; i9++) {
    dv24[i9] = 1.0 + (double)i9;
  }

  FadingChannel_channelFilter(x, z, dv24, varargout_1);
  for (i9 = 0; i9 < 6216; i9++) {
    varargout_2_im = varargout_1[i9].im;
    if (varargout_1[i9].im == 0.0) {
      varargout_1[i9].re /= 1.4142135623730951;
      varargout_1[i9].im = 0.0;
    } else if (varargout_1[i9].re == 0.0) {
      varargout_1[i9].re = 0.0;
      varargout_1[i9].im = varargout_2_im / 1.4142135623730951;
    } else {
      varargout_1[i9].re /= 1.4142135623730951;
      varargout_1[i9].im = varargout_2_im / 1.4142135623730951;
    }
  }

  memcpy(&y[0], &z[0], 12432U * sizeof(creal_T));
  permute(y, varargout_2);
  for (i9 = 0; i9 < 12432; i9++) {
    varargout_2_im = varargout_2[i9].im;
    if (varargout_2[i9].im == 0.0) {
      varargout_2[i9].re /= 1.4142135623730951;
      varargout_2[i9].im = 0.0;
    } else if (varargout_2[i9].re == 0.0) {
      varargout_2[i9].re = 0.0;
      varargout_2[i9].im = varargout_2_im / 1.4142135623730951;
    } else {
      varargout_2[i9].re /= 1.4142135623730951;
      varargout_2[i9].im = varargout_2_im / 1.4142135623730951;
    }
  }

  k_SystemProp_matlabCodegenSetAn(obj, obj->pNumSamplesProcessed + 3108.0);
}

void c_FadingChannel_GFilterGenerate(comm_MIMOChannel *obj)
{
  unsigned int b_state[625];
  int i;
  double w2[1280];
  int colIdx;
  creal_T dcv6[640];
  creal_T dcv7[636];
  creal_T y[640];
  static const double dv11[160] = { 0.00020734022246414918,
    -0.00081084049909333313, -0.0015574285397763192, -0.001744277804318311,
    -0.0012638202399326, -0.00024120372103262581, 0.00098521912428867187,
    0.0019603354452729627, 0.0022660802529595242, 0.001687308405922621,
    0.00032861110455255669, -0.0013742489345842596, -0.0027745657431385456,
    -0.003243666239213479, -0.0024344983277827144, -0.00047521126365496956,
    0.0020029390932531678, 0.004045985574384489, 0.00472616938006913,
    0.0035390715061251578, 0.00068639299203620348, -0.0028963710224001529,
    -0.0058208275638068786, -0.0067635547685208309, -0.0050355983813114768,
    -0.000967589928717348, 0.0040813501835335417, 0.0081490951031496974,
    0.0094107184606608048, 0.0069626846175100615, 0.0013248295405041321,
    -0.0055893552474813226, -0.011090581578491038, -0.012734683083533324,
    -0.0093684616257651478, -0.0017656762675479459, 0.0074616877720527523,
    0.014725364488994945, 0.016827151678095408, 0.012320178286729943,
    0.002300854682371521, -0.0097586179841960448, -0.019172513859684135,
    -0.021827026573516817, -0.015921516640539195, -0.0029471349220455676,
    0.012576377707853947, 0.024625138177639842, 0.027963052144175386,
    0.02034573813254344, 0.0037327609946035544, -0.016081041065056985,
    -0.031421139997519151, -0.035641264358293845, -0.025904721030532915,
    -0.0047085120150009629, 0.020583084239321436, 0.040201716885208509,
    0.045645194054426311, 0.0332104684281104, 0.0059727769777884925,
    -0.026725549260968855, -0.052321720198655768, -0.059670612279128905,
    -0.04362023750768277, -0.0077370961885165814, 0.036063901870864876,
    0.071165493462922766, 0.082126313599517636, 0.060812924864894279,
    0.010533429310363503, -0.053543588654858768, -0.10819738867533979,
    -0.12922818389491864, -0.099603606538627071, -0.015959335624459343,
    0.10886799283037112, 0.24837271802487987, 0.36941749146410591,
    0.44168955337970589, 0.446623479913719, 0.3829454186073904,
    0.26705406259687203, 0.12811572707392149, -0.000545669714019206,
    -0.091013089730268087, -0.12829735295466771, -0.11356066308250336,
    -0.062252892878759271, 0.0019563659976709483, 0.055254750352941993,
    0.0810540769086944, 0.074335400084854217, 0.041815406726272639,
    -0.0017513405410259906, -0.03955219418317911, -0.058754260100062593,
    -0.054541342923408072, -0.030952203351685782, 0.0014681022696409066,
    0.030081943546751234, 0.04488853464960936, 0.04186060204827529,
    0.023823987372947972, -0.0012130833093049571, -0.023450014092414855,
    -0.035023711360047359, -0.032694972158886115, -0.018606590906680209,
    0.0009925164872346575, 0.018410523356918743, 0.027464464712022286,
    0.025611393944788365, 0.014548436845236174, -0.00080215518407318566,
    -0.014403268096425404, -0.021430033303521005, -0.019933677737479366,
    -0.011287377554718059, 0.0006379572131508303, 0.01114326938277216,
    0.016516636877191227, 0.015306149826107136, 0.0086299657977982735,
    -0.000497165081270339, -0.0084724024075379274, -0.012497113645997577,
    -0.011525812160140817, -0.0064642325371760522, 0.00037801447919415921,
    0.0062961393868087726, 0.009233676527135486, 0.008467638580821257,
    0.0047201285332940613, -0.00027933995198139723, -0.0045532364085178918,
    -0.0066354699086354106, -0.0060476543881273284, -0.0033497111290991693,
    0.00020026832234539715, 0.0031999201232901049, 0.0046361952698607128,
    0.0042032593774481387, 0.002316490753683796, -0.00014000490091163007,
    -0.0022011368943896138, -0.0031816533337982815, -0.0028822028317866811,
    -0.0015894356445932355, 9.7691279134238331E-5, 0.0015255463234707493,
    0.0022226084371633954, 0.0020362633301083998, 0.0011395387511910933,
    -7.2315723478944344E-5, -0.001142652224319771, -0.001710723025169674,
    -0.0016176733751603709, -0.00093789381302212453, 6.266263644144435E-5 };

  for (i = 0; i < 625; i++) {
    b_state[i] = obj->pWGNState[i];
  }

  for (i = 0; i < 160; i++) {
    for (colIdx = 0; colIdx < 8; colIdx++) {
      w2[i + 160 * colIdx] = c_eml_rand_mt19937ar(b_state);
    }
  }

  d_SystemProp_matlabCodegenSetAn(obj, b_state);
  for (i = 0; i < 4; i++) {
    for (colIdx = 0; colIdx < 160; colIdx++) {
      dcv6[colIdx + 160 * i].re = 0.70710678118654746 * (w2[colIdx + 160 * i] +
        0.0 * w2[colIdx + 160 * (4 + i)]);
      dcv6[colIdx + 160 * i].im = 0.70710678118654746 * w2[colIdx + 160 * (4 + i)];
    }
  }

  filter(dv11, dcv6, obj->pGFilterState, y, dcv7);
  e_SystemProp_matlabCodegenSetAn(obj, dcv7);
}

void d_FadingChannel_GFilterGenerate(comm_MIMOChannel *obj, creal_T y[32])
{
  unsigned int b_state[625];
  int i;
  double w2[64];
  int colIdx;
  creal_T dcv8[32];
  creal_T dcv9[636];
  static const double dv12[160] = { 0.00020734022246414918,
    -0.00081084049909333313, -0.0015574285397763192, -0.001744277804318311,
    -0.0012638202399326, -0.00024120372103262581, 0.00098521912428867187,
    0.0019603354452729627, 0.0022660802529595242, 0.001687308405922621,
    0.00032861110455255669, -0.0013742489345842596, -0.0027745657431385456,
    -0.003243666239213479, -0.0024344983277827144, -0.00047521126365496956,
    0.0020029390932531678, 0.004045985574384489, 0.00472616938006913,
    0.0035390715061251578, 0.00068639299203620348, -0.0028963710224001529,
    -0.0058208275638068786, -0.0067635547685208309, -0.0050355983813114768,
    -0.000967589928717348, 0.0040813501835335417, 0.0081490951031496974,
    0.0094107184606608048, 0.0069626846175100615, 0.0013248295405041321,
    -0.0055893552474813226, -0.011090581578491038, -0.012734683083533324,
    -0.0093684616257651478, -0.0017656762675479459, 0.0074616877720527523,
    0.014725364488994945, 0.016827151678095408, 0.012320178286729943,
    0.002300854682371521, -0.0097586179841960448, -0.019172513859684135,
    -0.021827026573516817, -0.015921516640539195, -0.0029471349220455676,
    0.012576377707853947, 0.024625138177639842, 0.027963052144175386,
    0.02034573813254344, 0.0037327609946035544, -0.016081041065056985,
    -0.031421139997519151, -0.035641264358293845, -0.025904721030532915,
    -0.0047085120150009629, 0.020583084239321436, 0.040201716885208509,
    0.045645194054426311, 0.0332104684281104, 0.0059727769777884925,
    -0.026725549260968855, -0.052321720198655768, -0.059670612279128905,
    -0.04362023750768277, -0.0077370961885165814, 0.036063901870864876,
    0.071165493462922766, 0.082126313599517636, 0.060812924864894279,
    0.010533429310363503, -0.053543588654858768, -0.10819738867533979,
    -0.12922818389491864, -0.099603606538627071, -0.015959335624459343,
    0.10886799283037112, 0.24837271802487987, 0.36941749146410591,
    0.44168955337970589, 0.446623479913719, 0.3829454186073904,
    0.26705406259687203, 0.12811572707392149, -0.000545669714019206,
    -0.091013089730268087, -0.12829735295466771, -0.11356066308250336,
    -0.062252892878759271, 0.0019563659976709483, 0.055254750352941993,
    0.0810540769086944, 0.074335400084854217, 0.041815406726272639,
    -0.0017513405410259906, -0.03955219418317911, -0.058754260100062593,
    -0.054541342923408072, -0.030952203351685782, 0.0014681022696409066,
    0.030081943546751234, 0.04488853464960936, 0.04186060204827529,
    0.023823987372947972, -0.0012130833093049571, -0.023450014092414855,
    -0.035023711360047359, -0.032694972158886115, -0.018606590906680209,
    0.0009925164872346575, 0.018410523356918743, 0.027464464712022286,
    0.025611393944788365, 0.014548436845236174, -0.00080215518407318566,
    -0.014403268096425404, -0.021430033303521005, -0.019933677737479366,
    -0.011287377554718059, 0.0006379572131508303, 0.01114326938277216,
    0.016516636877191227, 0.015306149826107136, 0.0086299657977982735,
    -0.000497165081270339, -0.0084724024075379274, -0.012497113645997577,
    -0.011525812160140817, -0.0064642325371760522, 0.00037801447919415921,
    0.0062961393868087726, 0.009233676527135486, 0.008467638580821257,
    0.0047201285332940613, -0.00027933995198139723, -0.0045532364085178918,
    -0.0066354699086354106, -0.0060476543881273284, -0.0033497111290991693,
    0.00020026832234539715, 0.0031999201232901049, 0.0046361952698607128,
    0.0042032593774481387, 0.002316490753683796, -0.00014000490091163007,
    -0.0022011368943896138, -0.0031816533337982815, -0.0028822028317866811,
    -0.0015894356445932355, 9.7691279134238331E-5, 0.0015255463234707493,
    0.0022226084371633954, 0.0020362633301083998, 0.0011395387511910933,
    -7.2315723478944344E-5, -0.001142652224319771, -0.001710723025169674,
    -0.0016176733751603709, -0.00093789381302212453, 6.266263644144435E-5 };

  for (i = 0; i < 625; i++) {
    b_state[i] = obj->pWGNState[i];
  }

  for (i = 0; i < 8; i++) {
    for (colIdx = 0; colIdx < 8; colIdx++) {
      w2[i + (colIdx << 3)] = c_eml_rand_mt19937ar(b_state);
    }
  }

  d_SystemProp_matlabCodegenSetAn(obj, b_state);
  for (i = 0; i < 4; i++) {
    for (colIdx = 0; colIdx < 8; colIdx++) {
      dcv8[colIdx + (i << 3)].re = 0.70710678118654746 * (w2[colIdx + (i << 3)]
        + 0.0 * w2[colIdx + ((4 + i) << 3)]);
      dcv8[colIdx + (i << 3)].im = 0.70710678118654746 * w2[colIdx + ((4 + i) <<
        3)];
    }
  }

  b_filter(dv12, dcv8, obj->pGFilterState, y, dcv9);
  e_SystemProp_matlabCodegenSetAn(obj, dcv9);
}

/* End of code generation (FadingChannel.c) */
