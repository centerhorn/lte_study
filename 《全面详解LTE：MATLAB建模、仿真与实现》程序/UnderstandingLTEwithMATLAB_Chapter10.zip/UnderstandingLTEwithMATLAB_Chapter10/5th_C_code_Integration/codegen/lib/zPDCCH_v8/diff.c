/*
 * diff.c
 *
 * Code generation for function 'diff'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "diff.h"

/* Function Definitions */
void diff(const creal_T x_data[16], const int x_size[2], creal_T y_data[12], int
          y_size[2])
{
  int ixStart;
  int iyStart;
  int r;
  int ixLead;
  int iyLead;
  double work_re;
  double work_im;
  int m;
  double tmp2_re;
  double tmp2_im;
  if (x_size[0] <= 1) {
    y_size[0] = 0;
    y_size[1] = 4;
  } else {
    y_size[0] = x_size[0] - 1;
    y_size[1] = 4;
    ixStart = 1;
    iyStart = 0;
    for (r = 0; r < 4; r++) {
      ixLead = ixStart;
      iyLead = iyStart;
      work_re = x_data[ixStart - 1].re;
      work_im = x_data[ixStart - 1].im;
      for (m = 2; m <= x_size[0]; m++) {
        tmp2_re = work_re;
        tmp2_im = work_im;
        work_re = x_data[ixLead].re;
        work_im = x_data[ixLead].im;
        tmp2_re = x_data[ixLead].re - tmp2_re;
        tmp2_im = x_data[ixLead].im - tmp2_im;
        ixLead++;
        y_data[iyLead].re = tmp2_re;
        y_data[iyLead].im = tmp2_im;
        iyLead++;
      }

      ixStart += x_size[0];
      iyStart = (iyStart + x_size[0]) - 1;
    }
  }
}

/* End of code generation (diff.c) */
