/*
 * filter.h
 *
 * Code generation for function 'filter'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

#ifndef __FILTER_H__
#define __FILTER_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "zPDCCH_v8_types.h"

/* Function Declarations */
extern void b_filter(const double b[160], const creal_T x[32], const creal_T zi[636], creal_T y[32], creal_T zf[636]);
extern void c_filter(const double b[8], const creal_T x[32], creal_T y[32], creal_T zf[28]);
extern void d_filter(const creal_T x_data[4], const creal_T zi[636], creal_T y_data[4], int y_size[2], creal_T zf[636]);
extern void e_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void f_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void filter(const double b[160], const creal_T x[640], const creal_T zi[636], creal_T y[640], creal_T zf[636]);
extern void g_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void h_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void i_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void j_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void k_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void l_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void m_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
extern void n_filter(const creal_T x_data[4], const creal_T zi[28], creal_T y_data[4], int y_size[2], creal_T zf[28]);
#endif
/* End of code generation (filter.h) */
