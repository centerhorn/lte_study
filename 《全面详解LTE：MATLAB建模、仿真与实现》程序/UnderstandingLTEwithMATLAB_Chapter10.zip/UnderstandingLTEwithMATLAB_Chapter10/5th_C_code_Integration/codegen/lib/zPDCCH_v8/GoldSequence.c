/*
 * GoldSequence.c
 *
 * Code generation for function 'GoldSequence'
 *
 * C source code generated on: Tue Dec 31 15:43:42 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "zPDCCH_v8.h"
#include "GoldSequence.h"

/* Function Definitions */
comm_GoldSequence_2 *GoldSequence_GoldSequence(comm_GoldSequence_2 *obj)
{
  comm_GoldSequence_2 *b_obj;
  comm_GoldSequence_2 *c_obj;
  b_obj = obj;
  c_obj = b_obj;
  c_obj->isInitialized = FALSE;
  c_obj->isReleased = FALSE;
  return b_obj;
}

comm_GoldSequence_3 *b_GoldSequence_GoldSequence(comm_GoldSequence_3 *obj)
{
  comm_GoldSequence_3 *b_obj;
  comm_GoldSequence_3 *c_obj;
  b_obj = obj;
  c_obj = b_obj;
  c_obj->isInitialized = FALSE;
  c_obj->isReleased = FALSE;
  return b_obj;
}

/* End of code generation (GoldSequence.c) */
