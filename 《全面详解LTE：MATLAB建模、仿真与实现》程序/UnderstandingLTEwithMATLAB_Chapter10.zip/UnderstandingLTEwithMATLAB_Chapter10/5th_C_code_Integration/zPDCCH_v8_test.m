EbNo=1;
maxNumBits=1e5;
maxNumErrs=1e5;
zPDCCH_v8(EbNo, maxNumErrs, maxNumBits)
