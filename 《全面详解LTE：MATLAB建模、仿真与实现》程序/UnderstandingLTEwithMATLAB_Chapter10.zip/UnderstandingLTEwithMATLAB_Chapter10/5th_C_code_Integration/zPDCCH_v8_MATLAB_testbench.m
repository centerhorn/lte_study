MaxSNR=8;
MaxNumBits=1e7;
MaxNumErrs=1e7;
ber_vector=zeros(MaxSNR,1);
fprintf(1,'\nMATLAB testbench for PDCCH algorithm\n');
fprintf(1,'Maximum number of errors : %9d\n', MaxNumErrs);
fprintf(1,'Maximum number of bits     : %9d\n\n', MaxNumBits);
tic;
for snr=1:MaxSNR
fprintf(1,'Iteration number %d\r',snr);
EbNo=snr/2;
ber= zPDCCH_v9(EbNo, MaxNumErrs, MaxNumBits);
ber_vector(snr)=ber;
end
time_8=toc;
fprintf(1,'\nTime to complete %d iterations = %6.4f (sec)\n\n', MaxSNR, time_8);
for snr = 1:MaxSNR
fprintf(1,'Iteration %2d EbNo %3.1f BER %e\n', snr, snr/2, ber_vector(snr));
end