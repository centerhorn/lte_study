function y = TransmitDiversityCombinerS(in, chEst)
%#codegen
% Alamouti Transmit Diversty Combiner
% Scale
in = sqrt(2) * in; 
% STBC Alamouti   
y =  Alamouti_DecoderS(in, chEst);
% Space-Frequency to Space-Time transformation
y(2:2:end) = -conj(y(2:2:end));