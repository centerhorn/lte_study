MaxSize = 4200;
u=randi([0 1], MaxSize,1);
codegen Modulator -args {coder.typeof(0,[MaxSize 1],1)} 