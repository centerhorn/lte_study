u=randi([0 1], 2048,1)
y=Modulator(u);
