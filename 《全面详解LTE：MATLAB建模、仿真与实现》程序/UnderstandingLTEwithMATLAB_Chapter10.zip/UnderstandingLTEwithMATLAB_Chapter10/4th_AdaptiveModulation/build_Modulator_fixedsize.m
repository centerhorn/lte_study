u=randi([0 1], 4200,1 );
codegen Modulator -args {u}