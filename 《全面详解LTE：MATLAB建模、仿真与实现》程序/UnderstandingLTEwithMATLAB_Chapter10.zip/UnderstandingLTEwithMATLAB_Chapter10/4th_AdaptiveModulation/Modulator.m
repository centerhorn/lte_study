function y=Modulator(u)
persistent QPSK
if isempty(QPSK)
    QPSK          = comm.PSKModulator(4, 'BitInput', true, 'PhaseOffset', pi/4, ...
        'SymbolMapping', 'Custom', 'CustomSymbolMapping', [0 2 3 1]);
end
y=step(QPSK, u);