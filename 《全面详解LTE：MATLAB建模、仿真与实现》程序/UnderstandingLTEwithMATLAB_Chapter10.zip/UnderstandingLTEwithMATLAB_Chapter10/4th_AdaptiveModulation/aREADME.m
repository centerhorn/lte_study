% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter10\4th_AdaptiveModulation)
%
% This folder contains a series of MATLAB functions and scripts that showcase 
% Support for Variable-Sized Data for an adaptive modulation function
% as presented in chapter 10 of the "Understanding LTE with MATLAB"
%
% How to run the demos:
% You can experiment with fixed-size, bounded variable sized and unbounded
% variable size code generation by executing respectively the following testbenches:
% build_Modulator_fixedsize
% build_Modulator_bounded
% build_Modulator_unbounded
% The rrsulting MEX function wil be Modulator_mex.mexw64.
% By running the resulting mex function with different inouts we can repeat the exercises in the chapter 10.

