function [ber, bits]=zTurboExample_gpu4(EbNo, maxNumErrs, maxNumBits)
FRM=2432;
Indices = single(lteIntrlvrIndices(FRM));
M=4;k=log2(M);
R= FRM/(3* FRM + 4*3);
snr = EbNo + 10*log10(k) + 10*log10(R);
noiseVar = single(10.^(-snr/10));
numIter=6; trellis =  poly2trellis(4, [13 15], 13);
numFrames = 30;                            %Run 30 frames in parallel
persistent hTEnc Modulator AWGN DeModulator hTDec  hBER
if isempty(Modulator)
    hTEnc = comm.TurboEncoder('TrellisStructure',trellis , 'InterleaverIndices', Indices);
    Modulator      = comm.gpu.PSKModulator(4,'OutputDataType', 'single', ...
        'BitInput', true,  'PhaseOffset', pi/4, 'SymbolMapping', 'Custom', ...
                                                                       'CustomSymbolMapping', [0 2 3 1]);
    AWGN             =comm.gpu.AWGNChannel('NoiseMethod', 'Variance', 'VarianceSource', 'Input port');
    DeModulator =  comm.gpu.PSKDemodulator(...
        'ModulationOrder', 4, ...
        'BitOutput', true, ...
        'PhaseOffset', pi/4, 'SymbolMapping', 'Custom', ...
        'CustomSymbolMapping', [0 2 3 1],...
        'DecisionMethod', 'Approximate log-likelihood ratio', ...
        'VarianceSource', 'Input port');
    % Turbo Decoder with MultiFrame processing
    hTDec  = comm.gpu.TurboDecoder('TrellisStructure', trellis,'InterleaverIndices', Indices, ...
        'NumIterations', numIter, 'NumFrames', numFrames);
    % BER measurement
    hBER = comm.ErrorRate;
end
%% Processing loop
    Measures = zeros(3,1); %initialize BER output 
    while (( Measures(2)< maxNumErrs) && (Measures(3) < maxNumBits))
        data = single(randi([0 1], numFrames*FRM, 1));
        % Encode random data bits
        yEnc = gpuArray(multiframeStep(hTEnc, data, numFrames));
        % Add noise to real bipolar data
        modout = step(Modulator, yEnc);
        rData = step(AWGN, modout,noiseVar );
        % Convert to log-likelihood ratios for decoding
         llrData = step( DeModulator, rData, noiseVar);
        % Turbo Decode
        decData = step(hTDec, -llrData);
        % Calculate errors 
        Measures = step(hBER, data, gather(decData));
    end
bits = Measures(3);
ber= Measures(1);
reset(hBER);   
end
function y = multiframeStep(h, x, nf)
    xr = reshape(x,[], nf);
    ytmp = step(h,xr(:,1));
    y = zeros(size(ytmp,1), nf, class(ytmp));
    y(:,1) = ytmp;
    for ii =2:nf,
        y(:,ii) = step(h,xr(:,ii));
    end    
    y = reshape(y, [], 1);
end