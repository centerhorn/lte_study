MaxSNR=7;
Snrs=0:0.2:1.2;
MaxNumBits=1e6;
%% Baseline Algorithm on a CPU
N=1;
fprintf(1,'\nVersion 1: Everything on CPU\n\n');
tic;
for idx = 1:MaxSNR
    fprintf(1,'Iteration number %d\r',idx);
    EbNo=Snrs(idx);
    ber= zTurboExample_gpu0(EbNo, MaxNumBits, MaxNumBits);
end
time_CPU=toc;
fprintf(1,'Version 1: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_CPU);
Report_Timing_Results(N,time_CPU,time_CPU,'Everything on CPU');
%% GPU processing
GPU_is_There=parallel.gpu.GPUDevice.isAvailable;
if ~GPU_is_There
    fprintf(1,'The rest of exercises in this testbench will run only when a supported GPU is available\n');
else
%% Turbo Decoder on a GPU
N=2;
fprintf(1,'\nVersion 2: Turbo coding Only on GPU\n\n');
tic;
for idx = 1:MaxSNR
    fprintf(1,'Iteration number %d\r',idx);
    EbNo=Snrs(idx);
    ber= zTurboExample_gpu1(EbNo, MaxNumBits, MaxNumBits);
end
time_GPU1=toc;
fprintf(1,'Version 2: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_GPU1);
Report_Timing_Results(N,time_CPU,time_GPU1,'Turbo coding Only on GPU');
%% Multiple System Objects on GPU
N=3;
fprintf(1,'\nVersion 3:  Four GPU algorithms + Single-frame\n\n');
tic;
for idx = 1:MaxSNR
    fprintf(1,'Iteration number %d\r',idx);
    EbNo=Snrs(idx);
    ber= zTurboExample_gpu2(EbNo, MaxNumBits, MaxNumBits);
end
time_GPU2=toc;
fprintf(1,'Version 3: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_GPU2);
Report_Timing_Results(N,time_CPU,time_GPU2,'Four GPU algorithms + Single-frame');
%% Multiple Frames and Large Data Sizes
N=4;
fprintf(1,'\nVersion 4:  Four GPU algorithms + Multi-frame\n\n');
tic;
for idx = 1:MaxSNR
    fprintf(1,'Iteration number %d\r',idx);
    EbNo=Snrs(idx);
    ber= zTurboExample_gpu3(EbNo, MaxNumBits, MaxNumBits);
end
time_GPU3=toc;
fprintf(1,'Version 3: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_GPU3);
Report_Timing_Results(N,time_CPU,time_GPU3,'Four GPU algorithms + Multi-frame');
%% Using Single-Precision Data Type
N=5;
fprintf(1,'\nVersion 5:  Four GPU algorithms + Multi-frame + float\n\n');
tic;
for idx = 1:MaxSNR
    fprintf(1,'Iteration number %d\r',idx);
    EbNo=Snrs(idx);
    ber= zTurboExample_gpu4(EbNo, MaxNumBits, MaxNumBits);
end
time_GPU4=toc;
fprintf(1,'Version 4: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_GPU4);
Report_Timing_Results(N,time_CPU,time_GPU4,'Four GPU algorithms + Multi-frame + float');
%% 
end