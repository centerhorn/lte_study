% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter9\TurboCodingonGPU)
%
% This folder contains a series of MATLAB functions and scripts that showcase 
% how GPUs can be used to accelerate turbo-coding,  an essential part of the LTE standard, 
% as presented in chapter 9 of the "Understanding LTE with MATLAB"
%
% How to run the demo:
% Run the following MATLAB script:       
% zScript_TurboGPUAcceleration
% or 
% First, type edit zScript_TurboGPUAcceleration.m 
% and run the script in a cell-mode (running each cell and advancing to the next)
% which performs the same list of operations.
%
% You will see that we start with baseline implementations that runs Turbo coding on CPU and through successive code updates 
% introduce 4 optimization techniques:
% Turbo Decoder on a GPU
% Multiple System Objects on GPU
% Multiple Frames and Large Data Sizes
% Using Single-Precision Data Type
%