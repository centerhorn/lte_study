function [ber, bits]=zTurboExample_gpu1(EbNo, maxNumErrs, maxNumBits)
FRM=2432;                                         
Indices = lteIntrlvrIndices(FRM);
M=4;k=log2(M);
R= FRM/(3* FRM + 4*3);
snr = EbNo + 10*log10(k) + 10*log10(R);
noiseVar = 10.^(-snr/10);
numIter=6; trellis =  poly2trellis(4, [13 15], 13);
persistent hTEnc Modulator AWGN DeModulator hTDec  hBER
if isempty(Modulator)
    hTEnc = comm.TurboEncoder('TrellisStructure',trellis , 'InterleaverIndices', Indices);
    Modulator      = comm.PSKModulator(4, ...
        'BitInput', true,  'PhaseOffset', pi/4, 'SymbolMapping', 'Custom', ...
                                                                       'CustomSymbolMapping', [0 2 3 1]);
    AWGN             = comm.AWGNChannel('NoiseMethod', 'Variance', 'VarianceSource', 'Input port');
    DeModulator =  comm.PSKDemodulator(...
        'ModulationOrder', 4, ...
        'BitOutput', true, ...
        'PhaseOffset', pi/4, 'SymbolMapping', 'Custom', ...
        'CustomSymbolMapping', [0 2 3 1],...
        'DecisionMethod', 'Approximate log-likelihood ratio', ...
        'VarianceSource', 'Input port');
    % Turbo Decoder
    hTDec  = comm.gpu.TurboDecoder('TrellisStructure', trellis,'InterleaverIndices', Indices, 'NumIterations', numIter);
    % BER measurement
    hBER = comm.ErrorRate;
end
%% Processing loop
    Measures = zeros(3,1); %initialize BER output 
    while (( Measures(2)< maxNumErrs) && (Measures(3) < maxNumBits))
        data = randi([0 1], FRM, 1);
        % Encode random data bits
        yEnc = step(hTEnc, data);
        % Add noise to real bipolar data
        modout = step(Modulator, yEnc);
        rData = step(AWGN, modout,noiseVar );
        % Convert to log-likelihood ratios for decoding
         llrData = step( DeModulator, rData, noiseVar);
        % Turbo Decode
        decData = step(hTDec, -llrData);
        % Calculate errors 
        Measures = step(hBER, data, decData);
    end
bits = Measures(3);
ber= Measures(1);
reset(hBER);   