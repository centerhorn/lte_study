function y= Alamouti_Encoder2(u)
% Space-Time Block Encoder
Tx=2;
LEN=size(u,1);
idx1=1:Tx:LEN-1;
idx2=idx1+1;
% Alamouti Space-Time Block Encoder
%   G =  [  s1       s2 ]       
%        [ -s2*      s1*]
y=complex(zeros(LEN,Tx));
y(idx1,1)=u(idx1);
y(idx1,2)=u(idx2);
y(idx2,1)=-conj(u(idx2));
y(idx2,2)=conj(u(idx1));
