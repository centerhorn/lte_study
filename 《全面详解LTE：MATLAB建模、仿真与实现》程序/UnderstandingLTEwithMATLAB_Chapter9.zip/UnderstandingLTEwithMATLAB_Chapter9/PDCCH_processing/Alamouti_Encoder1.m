function y= Alamouti_Encoder1(u)
% Space-Time Block Encoder
Tx=2;
LEN=size(u,1);
idx1=1:Tx:LEN-1;
idx2=idx1+1;
% Alamouti Space-Time Block Encoder
%   G = [  s1       s2 ]       
%       [ -s2*      s1*]
y=[];
for n=1:LEN/Tx
    G=[       u(idx1(n))       u(idx2(n));...
        -conj(u(idx2(n))) conj(u(idx1(n)))];
    y=[y;G];
end
