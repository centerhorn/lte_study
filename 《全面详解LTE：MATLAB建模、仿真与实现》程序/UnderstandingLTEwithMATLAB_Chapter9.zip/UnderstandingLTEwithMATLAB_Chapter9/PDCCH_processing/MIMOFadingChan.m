function [y, h] = MIMOFadingChan(in)
% MIMOFadingChan
numTx=2;
numRx=2;
chanSRate=(2048*15000);Doppler=70;PathDelays = 0;PathGains  = 0;
persistent chanObj
if isempty(chanObj)
    chanObj = mimochan(numTx,numRx,(1/chanSRate),Doppler,PathDelays,PathGains);
    chanObj.NormalizePathGains = 1;
    chanObj.StorePathGains = 1;
    chanObj.ResetBeforeFiltering = 1;
end
y            = filter(chanObj, in);
ChGains = chanObj.PathGains;
Len         = size(in,1);
h     = complex(zeros(Len,numTx,numRx));
h(:) = ChGains(:,1,:,:);