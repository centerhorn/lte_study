function y = TransmitDiversityEncoder2(in)
%#codegen
% Alamouti Transmit Diversty Encoder
% Space-Frequency to Space-Time transformation
in(2:2:end) = -conj(in(2:2:end));    
% STBC Alamouti     
y = Alamouti_Encoder2(in);
% Scale
y = y/sqrt(2);