fprintf(1,'\nVersion 14: Version 8 Simulink rapid accel. optimized + parfor\n\n');
tic;
parfor EbNo=1:MaxSNR
    fprintf(1,'Iteration number %d\r',EbNo);
    sim('zPDCCH_v8s_optimized_rapid','SimulationMode','rapid', 'RapidAcceleratorUpToDateCheck', 'off');
end
time_14=toc;
fprintf(1,'Version 14: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_14);
