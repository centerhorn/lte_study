profile on;
ber=zPDCCH_v1(0,1e5,1e5);
profile viewer;