fprintf(1,'\nVersion 16: Version 8 + Viterbi decoder on GPU + spmd\n\n');
tic;
ber= zPDCCH_vH(1:snr, MaxNumBits, MaxNumBits);
time_16=toc;
fprintf(1,'Version 16: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_16);
