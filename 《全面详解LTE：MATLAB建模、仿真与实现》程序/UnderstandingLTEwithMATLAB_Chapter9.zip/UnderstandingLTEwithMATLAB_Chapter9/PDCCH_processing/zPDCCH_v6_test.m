fprintf(1,'\nVersion 6: System objects for MIMO & Channel modeling\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v6 (snr, MaxNumBits, MaxNumBits);
end
time_6=toc;
fprintf(1,'Version 6: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_6);
