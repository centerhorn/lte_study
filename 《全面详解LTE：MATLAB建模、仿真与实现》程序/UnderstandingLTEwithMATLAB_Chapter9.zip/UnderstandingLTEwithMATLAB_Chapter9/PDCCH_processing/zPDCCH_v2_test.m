fprintf(1,'\nVersion 2: Vectorization\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v2 (snr, MaxNumBits, MaxNumBits);
end
time_2=toc;
fprintf(1,'Version 2: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_2);
