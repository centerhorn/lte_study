fprintf(1,'\nVersion 9: MATLAB to C code generation (MEX)\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v9(snr, MaxNumBits, MaxNumBits);
end
time_9=toc;
fprintf(1,'Version 9: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_9);
