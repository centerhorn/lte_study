function [ber, bits]=zPDCCH_v4(EbNo, maxNumErrs, maxNumBits)
%% Constants
FRM=2048;
M=4; k=log2(M); codeRate=1/3;
snr = EbNo + 10*log10(k) + 10*log10(codeRate);
trellis=poly2trellis(7, [133 171 165]);
L=FRM+24;C=6; Index=[L+1:(3*L/2) (L/2+1):L];
%% Initializations
persistent Modulator Demodulator  CRCgen CRCdet
if isempty(Modulator)
    Modulator     = modem.pskmod('M', 4, 'PhaseOffset', pi/4, 'SymbolOrder', 'Gray', 'InputType', 'Bit');
    Demodulator = modem.pskdemod('M', 4, 'PhaseOffset', pi/4, 'SymbolOrder', 'Gray', 'OutputType', 'Bit');
    CRCgen         = crc.generator([1 1 zeros(1, 16) 1 1 0 0 0 1 1]);
    CRCdet          = crc.detector   ([1 1 zeros(1, 16) 1 1 0 0 0 1 1]);
end
%% Processsing loop 
numErrs = 0; numBits = 0; nS=0;
while ((numErrs < maxNumErrs) && (numBits < maxNumBits))
    % Transmitter
    u               = randi([0 1], FRM,1);                             % Generate bit payload
    u1             = generate(CRCgen,u);                           % CRC insertion
    u2             = u1((end-C+1):end);                              % Tail-biting covolutional coding
    [~, state]  = convenc(u2,trellis);           
    u3             = convenc(u1,trellis,state);
    u4             = fcn_RateMatcher(u3, L, codeRate);    % Rate matching 
    u5             = fcn_Scrambler(u4, nS);                        % Scrambling
    u6             = modulate(Modulator, u5);                   % Modulation
    u7             = TransmitDiversityEncoder2(u6);          % MIMO Alamouti encoder 
    % Channel
    [u8, h8]    = MIMOFadingChan(u7);                         % MIMO fading channel
    sigpower  = 10*log10(real(var(u8(:))));
    u9             = awgn(u8,snr,sigpower,'dB');
    % Receiver
    uA             =  TransmitDiversityCombiner3(u9, h8); % MIMO Alamouti combiner
    uB             = demodulate(Demodulator,uA);             % Demodulation
    uC             = fcn_Descrambler(uB, nS);                     % Descrambling
    uD             = fcn_RateDematcher(uC, L);                  % Rate de-matching
    uE             = [uD;uD];                                                 % Tail-biting 
    uF             = vitdec(uE ,trellis,34,'trunc','hard');        % Viterbi decoding
    uG            = uF(Index);                                                
    y               = detect(CRCdet, uG );                              % CRC detection
    numErrs   = numErrs + sum( y~=u );                           % Update number of bit errors
    numBits   = numBits + FRM;   
    nS             = nS + 2; nS = mod(nS, 20);
end
%% Clean up & collect results
ber = numErrs/numBits;
bits=numBits;