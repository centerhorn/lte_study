profile on;
ber=zPDCCH_v6(0,1e5,1e5);
profile viewer;