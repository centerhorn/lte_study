function s = Alamouti_DecoderS(u,H)
%#codegen
% STBC_DEC STBC Combiner
persistent hTDDec
if isempty(hTDDec)
    hTDDec= comm.OSTBCCombiner(...
        'NumTransmitAntennas',2,'NumReceiveAntennas',2);
end
s = step(hTDDec, u, H);