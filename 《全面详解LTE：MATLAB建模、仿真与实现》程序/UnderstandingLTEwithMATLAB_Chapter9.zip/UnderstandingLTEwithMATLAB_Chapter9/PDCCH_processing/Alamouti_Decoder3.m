function y = Alamouti_Decoder3(u,Ch)
%#codegen
% STBC_DEC STBC Combiner
LEN=size(u,1);
BlkSize=2;
NoBlks=LEN/BlkSize;
Nr=size(u,2);
idx1=1:BlkSize:LEN;
idx2=idx1+1;
% Initalize outputs
s=complex(zeros(LEN,Nr));
mynorm=complex(zeros(LEN,BlkSize));
vec_u=complex(zeros(NoBlks,BlkSize));
% Alamouti code for 2 Tx
H=complex(zeros(NoBlks,BlkSize));
for n=1:Nr
    vec_u(:,1)           = u(idx1,n);
    vec_u(:,2)          = conj(u(idx2,n));
    H(:)                    = Ch(1:BlkSize:end,:,n);
    conjH                 = conj(H);
    cn1                    = [conjH(:,1), H(:,2)];
    s(idx1,n)            = sum(cn1.*vec_u,2);
    mynorm(idx1,n) = sum(H.*conj(H),2);
    cn2                    = [conjH(:,2), -H(:,1)];
    s(idx2,n)            = sum(cn2.*vec_u,2);
end;
nn=sum(mynorm,2);
nn(idx2)=nn(idx1);
y=sum(s,2)./nn;
end