fprintf(1,'\nGenerating MEX function for zPDCCH_v8.m \r');
codegen -args {snr,maxNumBits,maxNumBits} zPDCCH_v8.m -o zPDCCH_v9;
fprintf(1,'Done.\r');
