function s = Alamouti_Decoder2(u,H)
%#codegen
% STBC_DEC STBC Combiner
%   Outputs the recovered symbol vector
LEN=size(u,1);
BlkSize=2;
NoBlks=LEN/BlkSize;
T=[0 1;-1 0];
% Initialize outputs
s=complex(zeros(LEN,1));
% Alamouti code for 2 Tx
h=complex(zeros(BlkSize,BlkSize));
for m=1:NoBlks
    indexU=(m-1)*BlkSize+(1:BlkSize);
    h(:)=H(2*m-1,:,:);
    h_norm=sum(h(:).*conj(h(:)));
    r=u(indexU,:);
    r(2,:)=conj(r(2,:));
    H1=conj(h);
    H2=T*h;
    M=[H1(:,1),H2(:,1),H1(:,2),H2(:,2)];
    s(indexU)=(M*r(:))/h_norm; % Maximum-likelihood combining
end