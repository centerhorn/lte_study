fprintf(1,'\nVersion 15: Version 8 + Viterbi decoder on GPU\n\n');
tic;
for snr = 1:MaxSNR
ber= zPDCCH_vG(snr, MaxNumBits, MaxNumBits);
end
time_15=toc;
fprintf(1,'Version 15: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_15);
