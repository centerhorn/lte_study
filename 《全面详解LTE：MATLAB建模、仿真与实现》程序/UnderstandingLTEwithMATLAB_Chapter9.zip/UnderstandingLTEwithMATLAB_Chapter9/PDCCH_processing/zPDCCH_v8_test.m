fprintf(1,'\nVersion 8: Using All available System objects\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v8(snr, MaxNumBits, MaxNumBits);
end
time_8=toc;
fprintf(1,'Version 8: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_8);
