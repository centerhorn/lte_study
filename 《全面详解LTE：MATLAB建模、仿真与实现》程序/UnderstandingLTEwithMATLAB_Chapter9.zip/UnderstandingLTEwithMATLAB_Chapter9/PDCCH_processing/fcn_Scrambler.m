function y = fcn_Scrambler(u, nS)
%   Downlink scrambling 
maxG=43200;
persistent hSeqGen hInt2Bit
if isempty(hSeqGen)
    hSeqGen = comm.GoldSequence('FirstPolynomial',[1 zeros(1, 27) 1 0 0 1],...
                                'FirstInitialConditions', [zeros(1, 30) 1], ...
                                'SecondPolynomial', [1 zeros(1, 27) 1 1 1 1],...
                                'SecondInitialConditionsSource', 'Input port',... 
                                'Shift', 1600,...
                                'VariableSizeOutput', true,...
                                'MaximumOutputSize', [maxG 1]);
    hInt2Bit = comm.IntegerToBit('BitsPerInteger', 31);
end
% Initial conditions
RNTI = 1; 
NcellID = 0;
q =0;
c_init = RNTI*(2^14) + q*(2^13) + floor(nS/2)*(2^9) + NcellID;

% Convert initial condition to binary vector
iniStates = step(hInt2Bit, c_init);

% Generate the scrambling sequence
seq = zeros(size(u));
nSamp=size(u,1);
seq(:) = step(hSeqGen, iniStates, nSamp);

% Scramble input with the scrambling sequence
y = double(xor(u, seq));
