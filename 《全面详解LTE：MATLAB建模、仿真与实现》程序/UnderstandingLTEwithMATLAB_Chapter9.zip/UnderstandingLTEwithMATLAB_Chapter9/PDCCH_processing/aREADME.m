% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter9\PDCCH_processing)
%
% This folder contains a series of MATLAB functions and scripts that showcase 
% optimizations applied to the simulation of the LTE control channel
% processing algorithm as presented in chapter 9 of the "Understanding LTE with MATLAB"
%
% How to run the demo:
% Run the following MATLAB script:       
% zScript_SimulationAcceleration
% or 
% First, type edit zScript_SimulationAcceleration.m 
% and run the script in a cell-mode (running each cell and advancing to the next)
% which performs the same list of operations.
%
% You will see that we start with baseline implementations and through successive profiling and code updates 
% introduce 6 optimization techniques:
% better MATLAB serial programming (vectorization, preallocation)
% using System objects, 
% MATLAB to C code generation, 
% parallel computing, 
% GPU-optimized System objects, and 
% using the rapid accelerator mode of simulation in Simulink. 
%