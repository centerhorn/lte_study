function s = Alamouti_Decoder1(u,H)
%#codegen
% STBC_DEC STBC Combiner
%   Outputs the recovered symbol vector
LEN=size(u,1);
Nr=size(u,2);
BlkSize=2;
NoBlks=LEN/BlkSize;
% Initialize outputs
h=complex(zeros(1,2));
s=complex(zeros(LEN,1));
% Alamouti code for 2 Tx
indexU=(1:BlkSize);
for m=1:NoBlks
    t_hat=complex(zeros(BlkSize,1));
    h_norm=0.0;
    for n=1:Nr
        h(:)=H(2*m-1,:,n);
        h_norm=h_norm+real(h*h');
        r=u(indexU,n);
        r(2)=conj(r(2));
        shat=[conj(h(1)), h(2); conj(h(2)), -h(1)]*r;
        t_hat=t_hat+shat;
    end
    s(indexU)=t_hat/h_norm; % Maximum-likelihood combining
    indexU=indexU+BlkSize;
end
end