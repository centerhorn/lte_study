fprintf(1,'\nVersion 7: System objects for MIMO & Channel & Viterbi\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v7 (snr, MaxNumBits, MaxNumBits);
end
time_7=toc;
fprintf(1,'Version 7: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_7);
