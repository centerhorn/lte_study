fprintf(1,'\nVersion 10: Parallel computing (parfor) + MEX \n\n');
tic;
parfor snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v9(snr, MaxNumBits, MaxNumBits);
end
time_A=toc;
fprintf(1,'Version 10: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_A);
