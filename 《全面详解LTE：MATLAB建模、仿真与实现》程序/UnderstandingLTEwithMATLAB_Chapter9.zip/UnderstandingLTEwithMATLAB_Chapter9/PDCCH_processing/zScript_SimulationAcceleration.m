snr=0;
MaxSNR=8;
MaxNumBits=1e6;
maxNumBits=MaxNumBits;
maxNumErrs=MaxNumBits;
save z_version8.mat -append maxNumBits maxNumErrs
numBits=4e4;
%% %%%%%%%%%%%
%% Code optimizations
%% %%%%%%%%%%%
%% Version 1: Baseline
zPDCCH_v1_test;
Report_Timing_Results(1,time_1,time_1,'Baseline');
profile on
zPDCCH_v1(snr,numBits,numBits);
profile('viewer');
%% Version 2: Vectorization
zPDCCH_v2_test;
Report_Timing_Results(2,time_1,time_2,'Vectorization');
profile on
zPDCCH_v2(snr,numBits,numBits);
profile('viewer');
%% Version 3: Vectorization - along large dimension
zPDCCH_v3_test;
Report_Timing_Results(3,time_1,time_3,'Vectorization along larger dimension');
profile on
zPDCCH_v3(snr,numBits,numBits);
profile('viewer');
%% Version 4: Vectorization + Preallocation
zPDCCH_v4_test;
Report_Timing_Results(4,time_1,time_4,'Vectorization + Preallocation');
profile on
zPDCCH_v4(snr,numBits,numBits);
profile('viewer');
%% Version 5: System objects for MIMO
zPDCCH_v5_test;Report_Timing_Results(5,time_1,time_5,'System objects for MIMO');
profile on
zPDCCH_v5(snr,numBits,numBits);
profile('viewer');
%% Version 6: System objects for MIMO & Channel 
zPDCCH_v6_test;Report_Timing_Results(6,time_1,time_6,'System objects for MIMO & Channel');
profile on
zPDCCH_v6(snr,numBits,numBits);
profile('viewer');
%% Version 7: System objects for MIMO & Channel & Viterbi decoder
zPDCCH_v7_test;Report_Timing_Results(7,time_1,time_7,'System objects for MIMO & Channel & Viterbi');
profile on
zPDCCH_v7(snr,numBits,numBits);
profile('viewer');
%% Version 8: Using all available System objects 
zPDCCH_v8_test;Report_Timing_Results(8,time_1,time_8,'System objects for all');
profile on
zPDCCH_v8(snr,numBits,numBits);
profile('viewer');
%% %%%%%%%%%%%
%% Acceleration features : MATLAB Coder & parfor 
%% %%%%%%%%%%%
%% Version 9: MATLAB to C code generation (MEX)
zPDCCH_v9_build;
zPDCCH_v9_test;Report_Timing_Results(9,time_1,time_9,'Version 8 + MATLAB to C code generation (MEX)');
%% Version 10: Parallel computing (parfor) + MEX
zPDCCH_vA_parallel_setup;
zPDCCH_vA_test;Report_Timing_Results(10,time_1,time_A,'Version 8 + MEX + Parallel computing (parfor)');
%% Simulink & rapid accelerator & parfor 
%% %%%%%%%%%%%
%% Version 11: Version 8 as a Simulink model
zPDCCH_vB_test;Report_Timing_Results(11,time_1,time_11,'Simulink normal mode');
%% Version 12: Version 8 as a Simulink model + optimization
zPDCCH_vC_test;Report_Timing_Results(12,time_1,time_12,'Simulink normal mode optimized');
%% Version 13: Version 8 as a Simulink model + rapid accelerator 
zPDCCH_vE_test;Report_Timing_Results(13,time_1,time_13,'Simulink rapid accelerator');
%% Version 14: Version 8 as a Simulink model + rapid accelerator + parfor
zPDCCH_vF_test;Report_Timing_Results(14,time_1,time_14,'Simulink rapid accelerator + parfor');
%% GPU processing (only if a GPU is available)
GPU_is_There=parallel.gpu.GPUDevice.isAvailable;
if ~GPU_is_There
    fprintf(1,'The rest of exercises in this testbench will run only when a supported GPU is available\n');
else
    %% Version 15: Version 8 + Viterbi decoder on GPU
    zPDCCH_vG_test;Report_Timing_Results(15,time_1,time_15,'Version 8 + Viterbi decoder on GPU');
    %% Version 16: Version 8 + Viterbi decoder on GPU + spmd
    zPDCCH_vH_test;Report_Timing_Results(16,time_1,time_16,'Version 8 + Viterbi decoder on GPU + spmd');
end