fprintf(1,'Building the model ...\n');
EbNo=0; sim('zPDCCH_v8s_optimized');
fprintf(1,'\nVersion 12: Version 8 Simulink normal mode optimized\n\n');
tic;
for EbNo=1:MaxSNR
    fprintf(1,'Iteration number %d\r',EbNo);
    sim('zPDCCH_v8s_optimized');
end
time_12=toc;
fprintf(1,'Version 12: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_12);
