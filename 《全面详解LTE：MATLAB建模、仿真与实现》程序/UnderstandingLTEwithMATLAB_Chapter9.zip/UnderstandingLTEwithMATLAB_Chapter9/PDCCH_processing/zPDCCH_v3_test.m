fprintf(1,'\nVersion 3: Vectorization along larger dimension\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v3 (snr, MaxNumBits, MaxNumBits);
end
time_3=toc;
fprintf(1,'Version 3: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_3);
