fprintf(1,'\n\nParallel Computing Toolbox: Setting of number of parallel workers ...\n');
if verLessThan('matlab','8.2')
    isOpen = matlabpool('size') > 0;
    if ~isOpen
        fprintf(1,'Parallel Computing Toolbox is starting ...\n');
        matlabpool;
    end
    numW=matlabpool('size');
else
    delete(gcp);
    myPool = parpool;
    numW=myPool.NumWorkers;
end
fprintf(1,'There are %d workers in the pool running parallel jobs\n',numW);
%% test out parfor
n=0;
parfor k=1:8
    n=10+k;
end