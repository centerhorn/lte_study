fprintf(1,'\nVersion 1: Baseline algorithm\n\n');
tic;
for snr=1:MaxSNR
    fprintf(1,'Iteration number %d\r',snr);
    ber= zPDCCH_v1 (snr, MaxNumBits, MaxNumBits);
end
time_1=toc;
fprintf(1,'Version 1: Time to complete %d iterations = %6.4f (sec)\n', MaxSNR, time_1);
