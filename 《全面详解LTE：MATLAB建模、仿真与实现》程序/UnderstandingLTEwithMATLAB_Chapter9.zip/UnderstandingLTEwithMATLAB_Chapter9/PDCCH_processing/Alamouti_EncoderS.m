function y = Alamouti_EncoderS(u)
% STBCENC Space-Time Block Encoder
% Outputs the Space-Time block encoded matrix
persistent hTDEnc;
if isempty(hTDEnc)
    % Use same object for either scheme
    hTDEnc = comm.OSTBCEncoder('NumTransmitAntennas', 2);
end
% Alamouti Space-Time Block Encoder
y = step(hTDEnc, u);
