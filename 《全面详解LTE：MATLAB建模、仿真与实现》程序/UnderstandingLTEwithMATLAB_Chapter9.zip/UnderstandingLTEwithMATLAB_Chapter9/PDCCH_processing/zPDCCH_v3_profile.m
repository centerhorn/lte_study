profile on;
ber=zPDCCH_v3(0,1e5,1e5);
profile viewer;