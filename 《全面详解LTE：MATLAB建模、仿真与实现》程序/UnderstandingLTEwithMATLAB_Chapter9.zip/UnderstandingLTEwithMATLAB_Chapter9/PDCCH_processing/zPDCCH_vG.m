function [ber, bits]=zPDCCH_vG(EbNo, maxNumErrs, maxNumBits)
%% Constants
FRM=2048;
M=4; k=log2(M); codeRate=1/3;
snr = EbNo + 10*log10(k) + 10*log10(codeRate);
trellis=poly2trellis(7, [133 171 165]);
L=FRM+24;C=6; Index=[L+1:(3*L/2) (L/2+1):L];
%% Initializations
persistent Modulator AWGN DeModulator BitError ConvEncoder1 ConvEncoder2 Viterbi CRCGen CRCDet
if isempty(Modulator)
    Modulator      = comm.QPSKModulator('BitInput',true);
    AWGN             = comm.AWGNChannel('NoiseMethod', 'Variance', 'VarianceSource', 'Input port');
    DeModulator =  comm.QPSKDemodulator('BitOutput',true);
    BitError           = comm.ErrorRate;
    ConvEncoder1=comm.ConvolutionalEncoder('TrellisStructure', trellis, 'FinalStateOutputPort', true, ...
        'TerminationMethod','Truncated');
    ConvEncoder2 =  comm.ConvolutionalEncoder('TerminationMethod','Truncated', 'InitialStateInputPort', true,...
        'TrellisStructure', trellis);
    Viterbi=comm.gpu.ViterbiDecoder('TrellisStructure', trellis, 'InputFormat','Hard','TerminationMethod','Truncated');
    CRCGen = comm.CRCGenerator('Polynomial',[1 1 zeros(1, 16) 1 1 0 0 0 1 1]);
    CRCDet = comm.CRCDetector   ('Polynomial',[1 1 zeros(1, 16) 1 1 0 0 0 1 1]);
end
%% Processsing loop modeling transmitter, channel model and receiver
numErrs = 0; numBits = 0; nS=0;
results=zeros(3,1);
while ((numErrs < maxNumErrs) && (numBits < maxNumBits))
    % Transmitter
    u               = randi([0 1], FRM,1);                           % Generate bit payload
    u1             = step(CRCGen, u);                               % CRC insertion
    u2             = u1((end-C+1):end);                            % Tail-biting covolutional coding
    [~, state]  = step(ConvEncoder1, u2);
    u3             = step(ConvEncoder2, u1,state);
    u4             = fcn_RateMatcher(u3, L, codeRate);  % Rate matching 
    u5             = fcn_Scrambler(u4, nS);                       % Scrambling
    u8             = step(Modulator, u5);                          % Modulation
    u7             = TransmitDiversityEncoderS(u8);         % MIMO Alamouti encoder
     % Channel
    [u8, h8]     = MIMOFadingChanS(u7);                     % MIMO fading channel
    noise_var = real(var(u8(:)))/(10.^(0.1*snr));
    u9             = step(AWGN, u8, noise_var);               % AWGN
    % Receiver
    uA             =  TransmitDiversityCombinerS(u9, h8);% MIMO Alamouti combiner
    uB             = step(DeModulator, uA);                      % Demodulation
    uC             = fcn_Descrambler(uB, nS);                   % Descrambling
    uD             = fcn_RateDematcher(uC, L);                % Rate de-matching
    uE             = [uD;uD];                                               % Tail-biting 
    uF             = step(Viterbi, uE);                                  % Viterbi decoding
    uG             = uF(Index);
    y               = step(CRCDet, uG );                               % CRC detection
    results      = step(BitError, u, y);                               % Update number of bit errors
    numErrs    = results(2);
    numBits    = results(3);
    nS              = nS + 2; nS = mod(nS, 20);
end
%% Clean up & collect results
ber = results(1); bits= results(3);
reset(BitError);