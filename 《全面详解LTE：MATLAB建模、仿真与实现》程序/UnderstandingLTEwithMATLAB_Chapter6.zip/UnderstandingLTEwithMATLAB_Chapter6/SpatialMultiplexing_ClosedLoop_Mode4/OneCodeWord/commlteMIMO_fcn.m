function [ber, bits] = commlteMIMO_fcn(snrdB, prmLTEPDSCH, prmLTEDLSCH, prmMdl)
%#codegen
persistent hPBer
if isempty(hPBer)
    hPBer = comm.ErrorRate;
end
%% Simulation loop
maxNumErrs=prmMdl.maxNumErrs;
maxNumBits=prmMdl.maxNumBits;
nS = 0; % Slot number, one of [0:2:18]
Measures = zeros(3,1); %initialize BER output
while (( Measures(2)< maxNumErrs) && (Measures(3) < maxNumBits))
   [dataIn, dataOut] = commlteMIMO_SM_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
    % Calculate  bit errors
    Measures = step(hPBer, dataIn, dataOut);
    % Update subframe number
    nS = nS + 2; if nS > 19, nS = mod(nS, 20); end;
end
ber=Measures(1);
bits=Measures(3);
reset(hPBer);