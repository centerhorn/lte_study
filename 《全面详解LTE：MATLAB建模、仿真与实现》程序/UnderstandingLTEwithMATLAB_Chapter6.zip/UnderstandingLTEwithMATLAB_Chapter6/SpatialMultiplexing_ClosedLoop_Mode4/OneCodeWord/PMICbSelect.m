function cbIdx = PMICbSelect(h, enPMIfback, numTx, numLayers, snrdB) 
%#codegen
% LTE Codebook selection using minimum MSE criterion
if (enPMIfback)
    snr = 10^(0.1*snrdB);    
    numk = size(h, 1);
    
    if (numTx == 2)
        cbLen = 2; % Only indices 1 and 2 are used for 2-layer closed-loop Spatial MUX
        MSEcb = zeros(cbLen, 1);
        for cbIdx = 1:cbLen
           Wn = PrecoderMatrix(cbIdx, numTx, numLayers);
            for idx = 1:numk
                hk = h(idx, :, :);                            % numTx x numRx
                hk = reshape(hk(:), numLayers, numLayers).';  % numRx x numTx                
                currMSE = real(trace((snr/numLayers)*inv(eye(numLayers) + (snr/numLayers) * (Wn'*(hk'*hk)*Wn)))); %#ok
                MSEcb(cbIdx) = MSEcb(cbIdx) + currMSE;
            end
        end
        [~, cbIdx] = min(MSEcb); % 0-based, note 0 and 3 are not used
    else % for numTx=4
        cbLen = 2^numLayers;
        MSEcb = zeros(cbLen, 1);
        for cbIdx = 1:cbLen
           Wn = PrecoderMatrix(cbIdx-1, numTx, numLayers);
            for idx = 1:numk
                hk = h(idx, :, :);                            % numTx x numRx
                hk = reshape(hk(:), numLayers, numLayers).';  % numRx x numTx
                currMSE = real(trace((snr/numLayers)*inv(eye(numLayers) + (snr/numLayers) * (Wn'*(hk'*hk)*Wn)))); %#ok
                MSEcb(cbIdx) = MSEcb(cbIdx) + currMSE;
            end
        end
        [~, cbIdx] = min(MSEcb);   % 1-based
        cbIdx = cbIdx-1;        % 0-based
    end
else
    cbIdx = 1;
end
