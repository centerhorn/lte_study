function hD = ChanEstimate_mTx(prmLTE, Rx, Ref, Mode)
%#codegen
Nrb           = prmLTE.Nrb;     % Number of resource blocks
Nrb_sc      = prmLTE.Nrb_sc;                 % 12 for normal mode
Ndl_symb = prmLTE.Ndl_symb;        % 7    for normal mode
numTx      = prmLTE.numTx;
numRx      = prmLTE.numRx;
% Initialize output buffer
switch numTx
    case 1                                                                                       % Case of 1 Tx
        hD = complex(zeros(Nrb*Nrb_sc, Ndl_symb*2,numRx));   % Iniitalize Output
        % size(Rx) = [2*Nrb,  4,numRx]  size(Ref) = [2*Nrb, 4] 
        Edges=[0,3,0,3];
        for n=1:numRx                                                                     
            Rec=Rx(:,:,n);
            hp= Rec./Ref;    
            hD(:,:,n)=gridResponse(hp, Nrb, Nrb_sc, Ndl_symb, Edges,Mode);
        end
    case 2                                                           % Case of 2 Tx
        hD = complex(zeros(Nrb*Nrb_sc, Ndl_symb*2,numTx, numRx));
        % size(Rx) = [4*Nrb,  4,numRx]  size(Ref) = [2*Nrb, 4, numTx] 
        for n=1:numRx
            Rec=Rx(:,:,n);
            for m=1:numTx
                [R,Edges]=getBoundaries2(m, Rec);
                T=Ref(:,:,m);
                hp= R./T;
                hD(:,:,m,n)=gridResponse(hp, Nrb, Nrb_sc, Ndl_symb, Edges,Mode);
            end
        end
    case 4
        hD = complex(zeros(Nrb*Nrb_sc, Ndl_symb*2,numTx, numRx));
        % size(Rx) = [4*Nrb,  4,numRx]  size(Ref) = [2*Nrb, 4, numTx] 
        for n=1:numRx
            Rec=Rx(:,:,n);
            for m=1:numTx
                [R,idx3, Edges]=getBoundaries4(m, Rec);
                T=Ref(:,idx3,m);
                hp= R./T;
                hD(:,:,m,n)=gridResponse(hp, Nrb, Nrb_sc, Ndl_symb, Edges,Mode);
            end
        end
end
end
%% Helper function
function [R,idx3, Edges]=getBoundaries4(m,  Rec)
coder.varsize('Edges');coder.varsize('idx3');
numPN=size(Rec,1);
idx_0=(1:2:numPN);
idx_1=(2:2:numPN);
Edges=[0,3,0,3];
idx3=1:4;
switch m
    case 1
        index=[idx_0,  2*numPN+idx_1, 3*numPN+idx_0,  5*numPN+idx_1]';
        Edges=[0,3,0,3];   idx3=1:4;
    case 2
        index=[idx_1,  2*numPN+idx_0, 3*numPN+idx_1,  5*numPN+idx_0]';
        Edges=[3,0,3,0];    idx3=1:4;
    case 3
        index=[numPN+idx_0,  4*numPN+idx_1]';
        Edges=[0,3];           idx3=[1 3];
    case 4
        index=[numPN+idx_1,  4*numPN+idx_0]';
        Edges=[3,0];          idx3=[1 3];
end
R=reshape(Rec(index),numPN/2,numel(Edges));
end
%% Helper function
function [R, Edges]=getBoundaries2(m, Rec)
numPN=size(Rec,1);
idx_0=(1:2:numPN);
idx_1=(2:2:numPN);
Edges=[0,3,0,3]; 
switch m
    case 1
        index=[idx_0,  numPN+idx_1, 2*numPN+idx_0, 3*numPN+idx_1]';
        Edges=[0,3,0,3]; 
    case 2
        index=[idx_1,  numPN+idx_0, 2*numPN+idx_1,  3*numPN+idx_0]';
        Edges=[3,0,3,0];  
end
R=reshape(Rec(index),numPN/2,4);
end