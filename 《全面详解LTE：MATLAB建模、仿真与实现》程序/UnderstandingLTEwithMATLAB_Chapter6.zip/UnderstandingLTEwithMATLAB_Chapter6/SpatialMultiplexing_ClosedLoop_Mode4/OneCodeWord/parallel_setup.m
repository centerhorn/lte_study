fprintf(1,'\n\nParallel Computing Toolbox: Setting of number of parallel workers ...\n'); 
isOpen = matlabpool('size') > 0;
if ~isOpen
    fprintf(1,'Parallel Computing Toolbox is starting ...\n');
    matlabpool local;
end
fprintf(1,'There are %d workers in the pool running parallel jobs\n',matlabpool('size'));