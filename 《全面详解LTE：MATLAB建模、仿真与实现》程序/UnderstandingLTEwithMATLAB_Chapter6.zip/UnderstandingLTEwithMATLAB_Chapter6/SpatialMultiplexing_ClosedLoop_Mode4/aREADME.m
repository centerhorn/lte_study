% This directory is composed of 2 distinct sub-directories:
% Spatial multiplexing mode 4 with 1 codeword 
% Spatial multiplexing mode 4 with 2 codewords 
% For a detailed description of how to perform experiments and run
% simulation testbenches of each section, please go to each sub-directory and
% consult its own zREADME.m file
