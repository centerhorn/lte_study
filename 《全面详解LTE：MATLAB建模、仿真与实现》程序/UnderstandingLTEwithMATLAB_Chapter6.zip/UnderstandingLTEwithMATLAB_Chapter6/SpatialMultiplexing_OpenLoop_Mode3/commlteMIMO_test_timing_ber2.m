% Script for MIMO LTE (mode 3)
%
% Single codeword transmission only,
%
clear all
clear functions
%% Set simulation parametrs & initialize parameter structures
copyfile('commlteMIMO_params_QPSK.m','commlteMIMO_params.m');
commlteMIMO_params;
maxNumErrs=5e7; 
maxNumBits=5e7;
[prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_initialize(txMode, ...
chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, corrLvl, ...
    chEstOn, numCodeWords, snrdB, maxNumErrs, maxNumBits);
clear txMode chanBW contReg modType Eqmode numTx numRx cRate maxIter fullDecode chanMdl corrLvl chEstOn numCodeWords snrdB maxNumErrs maxNumBits
%%
disp('Simulating the LTE Mode 3: Multiple Tx & Rx antrennas with open loop Spatial Multiplexing');
zReport_data_rate(prmLTEPDSCH, prmLTEDLSCH);
%% Geerate code and setp parallelism
disp('Generating code for commlteMIMO_fcn.m ...');
arg1=coder.Constant(prmLTEPDSCH);
arg2=coder.Constant( prmLTEDLSCH);
arg3=coder.Constant(prmMdl);
codegen commlteMIMO_fcn -args {16, arg1, arg2, arg3} -report
disp('Done.');
parallel_setup;
%%
MaxIter=8;
snr_vector=getSnrVector(prmLTEPDSCH.modType, MaxIter);
ber_vector=zeros(size(snr_vector));
maxNumBits=prmMdl.maxNumBits;
tic;
parfor n=1:MaxIter
    fprintf(1,'Iteration %2d out of %2d:  Processing %10d bits. SNR = %3d\n', ...
        n, MaxIter, maxNumBits, snr_vector(n));
    [ber, ~] = commlteMIMO_fcn_mex(snr_vector(n), prmLTEPDSCH, prmLTEDLSCH, prmMdl);
    ber_vector(n)=ber;
end;
toc;
semilogy(snr_vector, ber_vector);
title('BER - commlteMIMO SM');xlabel('SNR (dB)');ylabel('ber');grid;