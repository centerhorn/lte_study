function H = IdChEst(prmLTEPDSCH, prmMdl, chPathG)
% Ideal channel estimation for LTE subframes
%
%   Given the system parameters and the MIMO channel path Gains, provide
%   the ideal channel estimates for the RE corresponding to the data.
%   Limitation - will work for path delays that are multiple of channel sample
%   time and largest pathDelay < size of FFT
%   Implementation based on FFT of channel impulse response
persistent hFFT; 
if isempty(hFFT) 
   hFFT = dsp.FFT; 
end 
% get parameters
numDataTones = prmLTEPDSCH.Nrb*12; % Nrb_sc = 12
N                        = prmLTEPDSCH.N;
cpLen0               = prmLTEPDSCH.cpLen0;
cpLenR               = prmLTEPDSCH.cpLenR;
Ndl_symb           = prmLTE.Ndl_symb;        % 7    for normal mode
slotLen               = (N*Ndl_symb + cpLen0 + cpLenR*6);
% Get path delays
pathDelays = prmMdl.PathDelays;
% Delays, in terms of number of channel samples, +1 for indexing
sampIdx = round(pathDelays/(1/prmLTEPDSCH.chanSRate)) + 1;
[~, numPaths, numTx, numRx] = size(chPathG);
% Initialize output 
H = complex(zeros(numDataTones, 2*Ndl_symb, numTx, numRx));
for i= 1:numTx
    for j = 1:numRx
        link_PathG = chPathG(:, :, i, j);
        % Split this per OFDM symbol
        g = complex(zeros(2*Ndl_symb, numPaths));
        for n = 1:2 % over two slots
            % First OFDM symbol
            Index=(n-1)*slotLen + (1:(N+cpLen0));
            g((n-1)*Ndl_symb+1, :) = mean(link_PathG(Index, :), 1);           
            % Next 6 OFDM symbols
            for k = 1:6
                Index=(n-1)*slotLen+cpLen0+k*N+(k-1)*cpLenR + (1:(N+cpLenR));
                g((n-1)*Ndl_symb+k+1, :) = mean(link_PathG(Index, :), 1);
            end
        end
        hImp = complex(zeros(2*Ndl_symb, N));
        % assign pathGains at impulse response sample locations
        hImp(:, sampIdx) = g; 
        % FFT of impulse response
        h = step(hFFT, hImp.'); 
        % Reorder, remove DC, Unpack channel gains
        h = [h(N/2+1:N, :); h(1:N/2, :)];
        H(:, :, i, j) = [h(N/2-numDataTones/2+1:N/2, :); h(N/2+2:N/2+1+numDataTones/2, :)];
    end
end