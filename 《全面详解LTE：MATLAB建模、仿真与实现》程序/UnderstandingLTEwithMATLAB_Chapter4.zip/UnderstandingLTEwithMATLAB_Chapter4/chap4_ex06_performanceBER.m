%% Comparing BER performance of transport block processing 
%% as a function of max. number of iterations
maxNumErrs=1e4;
maxNumBits=1e7;
%%  Adaptive modulation and coding parameters
CodingRate=1/2;          % Choose any coding rate between 1/3 to 0.99
Mode=1;                       % Choose either of 1 for QPSK or 2 for QAM16 or 3 for QAM64
maxEbNo=2;                 % Range of SNR values examined
Modulation={'QPSK','QAM16','QAM64'};
snr=linspace(0,maxEbNo,6);
ber=zeros(6,numel(snr));
%%
for nIter=1:6
    prmLTE.Mode=Mode;
    prmLTE.Rate=CodingRate;
    prmLTE.maxIter=nIter;
for n=1:numel(snr)
    EbNo=snr(n);
    fprintf(1,'Modulation = %s; Rate = %8.4f ; Iters = %4.0f ; EbNo = %8.5f\n',Modulation{Mode}, CodingRate, nIter, EbNo);
    ber(nIter, n)=chap4_ex06(EbNo, maxNumErrs, maxNumBits, prmLTE);
    fprintf(1,'BER = %12.8f\n',ber(nIter,n));
end
end
%% Visualize results
zVisualize_ex06(snr, ber);
