% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter4)
%
% This folder contains a series of MATLAB scripts (testbenches) that showcase 
% modulation, scrambling and coding functionalities used in the LTE standard 
% for DLSCH and PDSCH as presented in chapter 4 of the "Understanding LTE with
% MATLAB"
% Testbenches performing experiments 1 to 6 depend on calling main functions 
% chap4_ex01.m,  chap4_ex02.m all the way to chap6_ex06.m.
%
% How to run the demos:
% 1. To perform experiment 1 and 2, use the BERTOOL of the Communications
% System Toolbox. 
% type bertool at the MATLAB command prompt. Go to Monte Carlo tab, choose
% either chap4_ex01.m or chap4_ex02.m in the "Simulation MATLAB file ..." edit
% box, set a range of EbNo values, set the BER variable name to ber, and
% set typical values for parameters Number of errors & Number of bits. 
% For better results, the experiments have to be long enough, 
% which usually means parametrers Number of errors or Number of bits
% need to be larger than 1e4 and 1e7 respectively. 
% Exploration:
% By successively commenting and uncommenting lines 5-7 
% in MATLAB files chap4_ex01.m or chap4_ex02.m,
% you effectively choose a different modulation mode of either QPSK, QAM16 and QAM64.
% Repeat the above process after changing the modulation mode.
%
% 2. To perform the 3rd experiment, you can run the following testbenches: 
% a) chap4_ex03_performanceBER.m
% Compares BER performance of turbo coders as a function of number of
% decoding iterations
% b) chap4_ex03_performanceProfiling.m
% Profiles the transceiver system model and identifies which component takes the most time  
% c) chap4_ex03_performanceTiming.m 
% Computates simulation time for system transceivers that include  turbo coders 
% as a function of number of iterations
%
% 3. To perform the 4th experiment, you can run the following testbenches: 
% a) chap4_ex04_performanceBER.m
% Compares BER performance of system transceivers that include turbo coders 
% with and without early termination decoding and shows how close the performances are 
% b) chap4_ex04_performanceTiming.m
% Computates simulation time for system transceivers that include turbo coders 
% with and without early termination decoding. It shows how similar
% the performance in early termination case to that of the regular case with much less 
% computation time. 
%
% 4.  To perform the 5th experiment, you can run the following testbench: 
% chap4_ex05_performanceBER.m
% It Compares BER performances of system transceivers including turbo coders 
% as a function of coding rate (effect of rate matching)
%
% 5. To perform the 6th experiment, you can run the following testbench: 
% chap4_ex06_performanceBER.m
% The corresponding main function  chap4_ex06.m implements a fairly acurate
% version of Transport channel processing (in Downlink DLSCH processing) 
% together with scrambling and modulation mapping operations of PDSCH processing.
% When you run the testbench, you compare BER performance of transport block processing 
% as a function of max. number of iterations.