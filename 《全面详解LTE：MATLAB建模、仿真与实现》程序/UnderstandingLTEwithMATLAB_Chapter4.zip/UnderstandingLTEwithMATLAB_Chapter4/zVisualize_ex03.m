function zVisualize(snrV, berV, snr1, ber1, snr3, ber3, snr5, ber5)
close all
semilogy(snrV,berV,'ob')
hold on
semilogy(snr1,ber1,'*r')
semilogy(snr3,ber3,'dk')
semilogy(snr5,ber5,'+g')
%%
xlabel('SNR (dB)')
ylabel('BER')
title('BER performance: Turbo & Viterbi coders as a function of SNR');
legend('Viterbi 1/3 soft', 'Turbo 1/3 Iterations = 1', 'Turbo 1/3 Iterations = 3', 'Turbo 1/3 Iterations = 5')
%%
semilogy(snrV,berV,'b')
semilogy(snr1,ber1,'r')
semilogy(snr3,ber3,'k')
semilogy(snr5,ber5,'g')
hold off