%% Comparing BER performance of turbo coders 
%% as a function of coding rate (effect of rate matching)
maxNumErrs=1e4;
maxNumBits=1e7;
%% Turbo 1/3 rate - with early termination - Number of decoding iterations = 6
CodingRate=1/3;
snr=linspace(0,1.4,6);
ber_third=zeros(size(snr));
tic;
for n=1:numel(snr)
    EbNo=snr(n);
    fprintf(1,' Turbo 1/3 rate - Max. number of decoding iterations = 6 ; SNR = %4.2f\n', EbNo);
    ber_third(n)=chap4_ex05_rate(EbNo, maxNumErrs, maxNumBits, CodingRate);
end
toc;
%% Turbo 1/2 rate - with early termination - Number of decoding iterations = 6
CodingRate=1/2;
snr=linspace(0,1.4,6);
ber_half=zeros(size(snr));
tic;
for n=1:numel(snr)
    EbNo=snr(n);
    fprintf(1,' Turbo 1/2 rate - Max. number of decoding iterations = 6 ; SNR = %4.2f\n', EbNo);
    ber_half(n)=chap4_ex05_rate(EbNo, maxNumErrs, maxNumBits, CodingRate);
end
toc;
%% Visualize results
zVisualize_ex05(snr, ber_third,  ber_half);