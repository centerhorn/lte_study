function y=ConvolutionalEncoder(u)
%#codegen
persistent Conv
if isempty(Conv)
    Conv = comm.ConvolutionalEncoder('TrellisStructure',poly2trellis(7, [133 171 165]), ...
        'TerminationMethod',  'Terminated');
end
y=step(Conv,u);