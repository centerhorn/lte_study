function zVisualize_ex05(snr6, ber6, ber6_crc)
close all
semilogy(snr,ber6,'ob')
hold on
semilogy(snr,ber6_crc,'og')
%%
xlabel('SNR (dB)')
ylabel('BER')
grid;
title('Effect of coding rate on BER performance; Number of iterations = 6');
legend('Rate 1/2 turbo coding', 'Rate 1/3 turbo coding')
%%
semilogy(snr6,ber6,'b')
semilogy(snr6,ber6_crc,'g')
hold off