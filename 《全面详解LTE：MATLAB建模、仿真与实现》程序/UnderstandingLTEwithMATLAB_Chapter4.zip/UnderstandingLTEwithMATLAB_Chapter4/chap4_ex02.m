function [ber, numBits]=chap4_ex02(EbNo, maxNumErrs, maxNumBits)
%% Constants
FRM=2400;      % Size of bit frame
clear functions
% ModulationMode=1;                     % QPSK
% ModulationMode=2;                     % QAM16
ModulationMode=3;                         % QAM64
k=2*ModulationMode;                     % Number of bits per modulation symbol
snr = EbNo + 10*log10(k);
noiseVar = 10.^(0.1.*(-snr));                        % Compute noise variance
%% Processsing loop: transmitter, channel model and receiver
numErrs = 0; 
numBits = 0;
nS=0;
while ((numErrs < maxNumErrs) && (numBits < maxNumBits))
    % Transmitter
    u  = randi([0 1], FRM,1);                                                    % Randomly generated input bits
    t0 = Scrambler(u, nS);                                                        % Scrambler
    t1 = Modulator(t0, ModulationMode);                              % Modulator
    % Channel
    c0 =  AWGNChannel(t1, snr);                                            % AWGN channel
    % Receiver
    r0 =  DemodulatorSoft(c0, ModulationMode, noiseVar);  % Demodulator
    r1 =  DescramblerSoft(r0, nS);                                           % Descrambler
    y  = 0.5*(1-sign(r1));                                                          % Recover output bits
    % Measurements
    numErrs     = numErrs + sum(y~=u);                                  % Update number of bit errors
    numBits     = numBits + FRM;                                            % Update number of bits processed
    % Manage slot number with each subframe processed
    nS = nS + 2;
    nS = mod(nS, 20);
end
%% Clean up & collect results
ber = numErrs/numBits;                                          % Compute Bit Error Rate (BER)