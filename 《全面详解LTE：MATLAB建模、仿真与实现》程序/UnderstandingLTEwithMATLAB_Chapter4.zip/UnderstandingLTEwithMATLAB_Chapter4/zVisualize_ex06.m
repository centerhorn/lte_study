function zVisualize_ex06(snr, ber)
close all
semilogy(snr,ber')
hold on
semilogy(snr,ber','o')
%%
xlabel('SNR (dB)')
ylabel('BER')
title('Transport channel BER performance; Coding Rate = 1/2');
legend('no. iterations = 1', 'no. iterations = 2', 'no. iterations = 3', ...
    'no. iterations = 4', 'no. iterations = 5', 'no. iterations = 6')
hold off