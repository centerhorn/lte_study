function zVisualize_ex04(snr6, ber6, ber6_crc)
close all
semilogy(snr6,ber6,'ob')
hold on
semilogy(snr6,ber6_crc,'*r')
%%
xlabel('SNR (dB)')
ylabel('BER')
title('BER performance: Turbo coding as a function of SNR');
legend('Fixed number of decding iterations = 6', 'Variable decoding iterations based on CRC')
%%
semilogy(snr6,ber6,'b')
semilogy(snr6,ber6_crc,'r')
hold off