%% Comparing BER performance of turbo coders 
%% with and without early termination decoding 
maxNumErrs=1e4;
maxNumBits=1e7;
%% Turbo 1/3 rate - without early termination mechanism in turbo decoder
%    Number of decoding iterations = 6
snr6=0:0.25:1.25;
ber6=zeros(size(snr6));
tic;
for n=1:numel(snr6)
    EbNo=snr6(n);
    fprintf(1,' Turbo 1/3 rate - Number of decoding iterations = 6 ; SNR = %4.2f\n', EbNo);
    ber6(n)=chap4_ex04(EbNo, maxNumErrs, maxNumBits);
end
toc;
%% Turbo 1/3 rate - WITH early termination mechanism in turbo decoder
%    Number of decoding iterations = 6
snr6=0:0.25:1.25;
ber6_crc=zeros(size(snr6));
tic;
for n=1:numel(snr6)
    EbNo=snr6(n);
    fprintf(1,' Turbo 1/3 rate - Early termiination - Max. decoding iterations = 6 ; SNR = %4.2f\n', EbNo);
    ber6_crc(n)=chap4_ex04_crc(EbNo, maxNumErrs, maxNumBits);
end
toc;
%% Visualize results
zVisualize_ex04(snr6, ber6,  ber6_crc);