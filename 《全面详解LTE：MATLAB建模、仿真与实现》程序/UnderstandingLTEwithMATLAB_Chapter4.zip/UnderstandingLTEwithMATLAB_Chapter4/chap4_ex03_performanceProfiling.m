%% Profiling the turbo coder system model 
EbNo=1;
maxNumErrs=1e7;
maxNumBits=1e7;
profile on
ber=chap4_ex03_nIter(EbNo, maxNumErrs, maxNumBits , 1);
profile viewer