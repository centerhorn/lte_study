%% Computation time of turbo coder 
%% as a function of number of iterations
EbNo=1;
maxNumErrs=1e6;
maxNumBits=1e6;
for nIter=1:6
    clear functions
    tic;
    ber=chap4_ex03_nIter(EbNo, maxNumErrs, maxNumBits , nIter);
    toc;
end