EbNo=1; maxNumErrs=1e7; maxNumBits=1e7;
%%

tic; [a,b]=chap4_ex04(EbNo,maxNumErrs, maxNumBits); toc;
%%
tic; [c,d]=chap4_ex04_crc(EbNo,maxNumErrs, maxNumBits); toc;
%%
fprintf(1,'Regular BER %8.6f  - Early termination BER %8.6f \n',a,c);
fprintf(1,'Regular Bits processed %8.0f \n',b);
fprintf(1,'Early termination Bits processed %8.0f \n',d);