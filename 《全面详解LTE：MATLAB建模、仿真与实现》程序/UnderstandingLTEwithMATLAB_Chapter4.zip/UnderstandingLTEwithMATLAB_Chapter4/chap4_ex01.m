function [ber, numBits]=chap4_ex01(EbNo, maxNumErrs, maxNumBits)
%% Constants
FRM=2400;      % Size of bit frame
%% Modulation Mode
ModulationMode=1;                               % QPSK
% ModulationMode=2;                           % QAM16
%ModulationMode=3;                            % QAM64
k=2*ModulationMode;                           % Number of bits per modulation symbol
snr = EbNo + 10*log10(k);
%% Processsing loop: transmitter, channel model and receiver
numErrs = 0; 
numBits = 0;
while ((numErrs < maxNumErrs) && (numBits < maxNumBits))
    % Transmitter
    u  = randi([0 1], FRM,1);                                          %  Randomly generated input bits
    t0 = Modulator(u, ModulationMode);                     % Modulator
    % Channel
    c0 =  AWGNChannel(t0, snr);                                  % AWGN channel
    % Receiver
    r0 =  DemodulatorHard(c0, ModulationMode);      % Demodulator, Hard-decision
    y  = r0(1:FRM);                                                        % Recover output bits
    % Measurements
    numErrs     = numErrs + sum(y~=u);                        % Update number of bit errors
    numBits     = numBits + FRM;                                  % Update number of bits processed
end
%% Clean up & collect results
ber = numErrs/numBits;                                            