%% Comparing BER performance of turbo coders 
%% as a function of number of iterations
maxNumErrs=1e4;
maxNumBits=1e7;
%% Turbo 1/3 rate - Number of decoding iterations = 1
clear functions
nIter=1;
snr1=0:0.5:3;
ber1=zeros(size(snr1));
for n=1:numel(snr1)
    EbNo=snr1(n);
    fprintf(1,' Turbo 1/3 rate - Number of decoding iterations = 1 ; SNR = %3.1f\n', EbNo);
    ber1(n)=chap4_ex03_nIter(EbNo, maxNumErrs, maxNumBits , nIter);
end
%% Turbo 1/3 rate - Number of decoding iterations = 3
clear functions
nIter=3;
snr3=0:0.5:1.5;
ber3=zeros(size(snr3));
for n=1:numel(snr3)
    EbNo=snr3(n);
    fprintf(1,' Turbo 1/3 rate - Number of decoding iterations = 3 ; SNR = %3.1f\n', EbNo);
    ber3(n)=chap4_ex03_nIter(EbNo, maxNumErrs, maxNumBits , nIter);
end
%% Turbo 1/3 rate - Number of decoding iterations = 5
clear functions
nIter=5;
snr5=0:0.25:1.25;
ber5=zeros(size(snr5));
for n=1:numel(snr5)
    EbNo=snr5(n);
    fprintf(1,' Turbo 1/3 rate - Number of decoding iterations = 5 ; SNR = %4.2f\n', EbNo);
    ber5(n)=chap4_ex03_nIter(EbNo, maxNumErrs, maxNumBits , nIter);
end
%% Viterbi decoder 1/3 rate - soft-decision decoding
clear functions
snrV=0:0.5:3;
berV=zeros(size(snrV));
for n=1:numel(snrV)
    EbNo=snrV(n);
    fprintf(1,'  Viterbi decoder 1/3 rate - soft-decision decoding; SNR = %3.1f\n', EbNo);
    berV(n)=chap4_ex03_viterbi(EbNo, maxNumErrs, maxNumBits );
end
%% Visualize results
zVisualize_ex03(snrV, berV, snr1, ber1, snr3, ber3, snr5, ber5);