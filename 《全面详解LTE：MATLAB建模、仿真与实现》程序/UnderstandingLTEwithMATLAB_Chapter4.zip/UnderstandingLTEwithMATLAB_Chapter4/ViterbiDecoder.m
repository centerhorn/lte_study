function y=ViterbiDecoder(u)
%#codegen
persistent Viterbi
if isempty(Viterbi)
    Viterbi = comm.ViterbiDecoder('TrellisStructure',  poly2trellis(7, [133 171 165]),...
       'TerminationMethod',  'Terminated', 'OutputDataType','double');
end
y=step(Viterbi,u);