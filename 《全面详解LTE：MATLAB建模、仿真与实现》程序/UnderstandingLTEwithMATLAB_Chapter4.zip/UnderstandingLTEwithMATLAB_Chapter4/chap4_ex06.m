function [ber, numBits]=chap4_ex06(EbNo, maxNumErrs, maxNumBits, prmLTE)
%% Constants
 clear functions
FRM=2432-24;                                          
ModulationMode=prmLTE.Mode;
CodingRate=prmLTE.Rate;
k=2*ModulationMode;
snr = EbNo + 10*log10(k) + 10*log10(CodingRate);
noiseVar = 10.^(-snr/10);
%% Processsing loop modeling transmitter, channel model and receiver
numErrs = 0; numBits = 0; nS=0; 
while ((numErrs < maxNumErrs) && (numBits < maxNumBits))
    % Transmitter
    u  =  randi([0 1], FRM,1);                                                           % Randomly generated input bits
    data= CbCRCGenerator(u);                                                        % Transport block CRC code
    [t1, Kplus, C] = TbChannelCoding(data,prmLTE);                     % Transport Channel encoding
    t2 = Scrambler(t1, nS);                                                                % Scrambler
    t3 = Modulator(t2, ModulationMode);                                       % Modulator
    % Channel
    c0 = AWGNChannel(t3, snr);                                                      % AWGN channel
    % Receiver
    r0 = DemodulatorSoft(c0, ModulationMode, noiseVar);            % Demodulator
    r1 = DescramblerSoft(r0, nS);                                                     % Descrambler
     r2= TbChannelDecoding(r1, Kplus, C, prmLTE);                        % Transport Channel decoding
    y   =  CbCRCDetector(r2);                                                           % Code block CRC dtector
    % Measurements
    numErrs     = numErrs + sum(y~=u);                                           % Update number of bit errors
    numBits     = numBits + FRM;                                                     % Update number of bits processed
    % Manage slot number with each subframe processed
    nS = nS + 2; nS = mod(nS, 20);
end
%% Clean up & collect results
ber = numErrs/numBits; 