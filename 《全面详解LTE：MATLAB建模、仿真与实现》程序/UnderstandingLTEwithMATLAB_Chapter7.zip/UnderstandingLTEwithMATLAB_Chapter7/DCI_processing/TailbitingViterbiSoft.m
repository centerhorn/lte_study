function y=TailbitingViterbiSoft(u, L)
%#codegen
trellis=poly2trellis(7, [133 171 165]);
Index=[L+1:(3*L/2) (L/2+1):L];
persistent Viterbi
if isempty(Viterbi)
    Viterbi=comm.ViterbiDecoder(...
        'TrellisStructure', trellis, 'InputFormat','Unquantized','TerminationMethod','Truncated','OutputDataType','logical');
end
uD             = fcn_RateDematcher(u, L);                % Rate de-matching
uE             = [uD;uD];                                               % Tail-biting
uF             = step(Viterbi, uE);                                  % Viterbi decoding
y               = uF(Index);