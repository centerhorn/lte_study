function [y, err] = CRCdetectorDCI(data)
%#codegen
% Transport block CRC generation
persistent hCRCDet 
if isempty(hCRCDet )
    hCRCDet = comm.CRCDetector('Polynomial',  [1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1]);
end
[y, err] = step(hCRCDet, data);