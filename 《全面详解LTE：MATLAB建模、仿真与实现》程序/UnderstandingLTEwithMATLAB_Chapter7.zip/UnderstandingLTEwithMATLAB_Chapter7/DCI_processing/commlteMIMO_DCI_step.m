function [dataIn, dataOut, modOut, rxSig]...
    = commlteMIMO_DCI_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl)
%% TX
numBitsDCI = 205;
%  Generate payload
dataIn        = genPayload(nS,  numBitsDCI);
% Transport block CRC generation
CrcOut1      = CRCgeneratorDCI(dataIn);
% Channel coding includes - tail biting convolutional coding, rate matching
data             = TailbitingConvEnc(CrcOut1,  prmLTEDLSCH.cRate);
%Scramble codeword
scramOut     = Scramble(data, nS, 0, prmLTEPDSCH.maxG);
% Modulate
modOut       = Modulator(scramOut, prmLTEPDSCH.modType);
% Transmit divrsity encoder
PrecodeOut = TDEncode(modOut, prmLTEPDSCH.numTx);
%% Channel
% MIMO fading channel
[fadeOut, pathGain]     = MIMOFadingChan(PrecodeOut, prmLTEPDSCH, prmMdl);
nVar                      = real(var(fadeOut(:)))/(10.^(0.1*snrdB));
pathG                            = squeeze(pathGain);
% AWGN
recOut                           = AWGNChannel(fadeOut, nVar);
%% RX
% Transmit diversity combiner
rxSig =  TDCombine(recOut, pathG,  prmLTEPDSCH.numTx,  prmLTEPDSCH.numRx);  
% Demodulate
demodOut = DemodulatorSoft(rxSig, prmLTEPDSCH.modType, nVar);
% Descramble both received codewords
rxCW1 =  Descramble(demodOut, nS, 0, prmLTEPDSCH.maxG);
% Channel decoding includes - tail biting Viterbi decoding, rate dematching
L=numel(CrcOut1);
decData1=TailbitingViterbiSoft( rxCW1, L);
% Transport block CRC detection
[dataOut, ~] = CRCdetectorDCI(decData1);
end