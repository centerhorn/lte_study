% PDSCH
txMode             = 2;   % Transmisson mode one of {1, 2, 4}     
numTx              = 2;    % Number of transmit antennas
numRx              = 2;    % Number of receive antennas
chanBW            = 6;    % [1,2,3,4,5,6] maps to [1.4, 3, 5, 10, 15, 20]MHz
contReg            = 1;    % {1,2,3} for >=10MHz, {2,3,4} for <10Mhz
modType           = 1;    % [1,2,3] maps to ['QPSK','16QAM','64QAM']
% DLSCH
cRate                = 1/3; % Rate matching target coding rate 
maxIter              = 2;     % Maximum number of turbo decoding terations  
fullDecode         = 0;    % Whether "full" or "early stopping" turbo decoding is performed
% Channel 
chanMdl             =   'flat';   % Channel model
Doppler              = 70;                               % Average Doppler shift
% one of {'flat-low-mobility', 'flat-high-mobility','frequency-selective-low-mobility',
% 'frequency-selective-high-mobility', 'EPA 0Hz', 'EPA 5Hz', 'EVA 5Hz', 'EVA 70Hz'}
corrLvl                 = 'Low'; 
% Simulation parametrs
Eqmode               = 2;      % Type of equalizer used [1,2,3] for ['ZF', 'MMSE','Sphere Decoder']
chEstOn              = 0;          % use channel estimation or ideal channel
visualsOn            = 0;      % Whether to visualize channel response and constellations
numCodeWords  = 1; % Number of codewords in PDSCH
enPMIfback         = 1;     % Enable/Disable Precoder Matrix Indicator (PMI) feedback
cbIdx                   = 1;      % Initialize PMI index