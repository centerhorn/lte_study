function [ber, bits]=commlteMIMO_PDSCH(EbNo, maxNumErrs, maxNumBits)
%
clear functions
%% Set simulation parametrs & initialize parameter structures
commlteMIMO_params_DCI;
codeRate=cRate;
k=2*modType;
snrdB = EbNo + 10*log10(codeRate) + 10*log10(k);
[prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_initialize(txMode, ...
    chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, Doppler, corrLvl, ...
    chEstOn, numCodeWords, enPMIfback, cbIdx, snrdB, maxNumErrs, maxNumBits);
clear txMode chanBW contReg modType Eqmode numTx numRx cRate maxIter fullDecode chanMdl Doppler corrLvl chEstOn numCodeWords enPMIfback cbIdx 
%%
hPBer = comm.ErrorRate;
%% Simulation loop
nS = 0; % Slot number, one of [0:2:18]
Measures = zeros(3,1); %initialize BER output
while (( Measures(2)< maxNumErrs) && (Measures(3) < maxNumBits))
   [dataIn, dataOut, modOut, rxSig] = ...
       commlteMIMO_PDSCH_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
    % Calculate  bit errors
    Measures = step(hPBer, dataIn, dataOut);
    % Visualize results
    if visualsOn, zVisConstell( prmLTEPDSCH,  modOut, rxSig, nS); end;
end
ber=Measures(1);
bits=Measures(3);
reset(hPBer);