function y = CRCgeneratorDCI(data)
%#codegen
% Transport block CRC generation
persistent hCRCGen
if isempty(hCRCGen)
    hCRCGen = comm.CRCGenerator('Polynomial', [1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1]);
end
y = step(hCRCGen, data);