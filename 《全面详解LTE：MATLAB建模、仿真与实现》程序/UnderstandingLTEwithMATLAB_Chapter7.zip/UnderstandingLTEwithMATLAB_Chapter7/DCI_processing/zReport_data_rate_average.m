function t = zReport_data_rate_average(p2, p1)
persistent Rmean Rmod Rcod
if isempty(Rmean), Rmean=dsp.Mean('RunningMean', true);end
if isempty(Rmod), Rmod=dsp.Mean('RunningMean', true);end
if isempty(Rcod), Rcod=dsp.Mean('RunningMean', true);end
y=(1/10.0e-3)*(p1.TBLenVec(1)+p1.TBLenVec(2)+8*p1.TBLenVec(3));
z=y/1e6;
t=step(Rmean,z);
mm=step(Rmod,2*p2.modType);
cc=step(Rcod,p1.cRate);
Mod={'QPSK','16QAM','64QAM'};
fprintf(1,'Modulation                   = %s\n',Mod{p2.modType});
fprintf(1,'Instantanous Data rate       = %.2f Mbps\n',z);
fprintf(1,'Average Data rate            = %.2f Mbps\n',t);
fprintf(1,'Instantanous Modulation rate = %4.2f\n',2*p2.modType);
fprintf(1,'Average Modulation rate      = %4.2f\n',mm);
fprintf(1,'Instantanous Coding rate     = %.4f\n',p1.cRate);
fprintf(1,'Average Coding rate          = %.4f \n\n',cc);
end

