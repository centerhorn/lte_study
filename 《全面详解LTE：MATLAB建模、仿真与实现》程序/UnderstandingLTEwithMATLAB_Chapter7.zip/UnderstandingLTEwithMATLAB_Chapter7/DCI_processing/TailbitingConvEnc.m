function y=TailbitingConvEnc(u,  codeRate)
%#codegen
trellis=poly2trellis(7, [133 171 165]);
L=numel(u);
C=6;
persistent  ConvEncoder1 ConvEncoder2
if isempty(ConvEncoder1)
    ConvEncoder1=comm.ConvolutionalEncoder('TrellisStructure', trellis, 'FinalStateOutputPort', true, ...
        'TerminationMethod','Truncated');
    ConvEncoder2 =  comm.ConvolutionalEncoder('TerminationMethod','Truncated', 'InitialStateInputPort', true,...
        'TrellisStructure', trellis);
end
u2              = u((end-C+1):end);                            % Tail-biting covolutional coding
[~, state]   = step(ConvEncoder1, u2);
u3              = step(ConvEncoder2, u,state);
y                = fcn_RateMatcher(u3, L, codeRate);  % Rate matching