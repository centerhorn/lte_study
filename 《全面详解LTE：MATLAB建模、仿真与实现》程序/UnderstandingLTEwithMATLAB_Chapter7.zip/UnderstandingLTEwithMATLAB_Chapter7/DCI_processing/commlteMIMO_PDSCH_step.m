function [dataIn, dataOut, modOut, rxSig]...
    = commlteMIMO_PDSCH_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl)
%% TX
dataIn = genPayload(nS,  prmLTEDLSCH.TBLenVec);
% Transport block CRC generation
tbCrcOut1 =CRCgenerator(dataIn);
% Channel coding includes - CB segmentation, turbo coding, rate matching,
% bit selection, CB concatenation - per codeword
[data, Kplus1, C1] = TbChannelCoding(tbCrcOut1, nS, prmLTEDLSCH, prmLTEPDSCH);
%Scramble codeword
scramOut     = Scramble(data, nS, 0, prmLTEPDSCH.maxG);
% Modulate
modOut       = Modulator(scramOut, prmLTEPDSCH.modType);
% Transmit divrsity encoder
PrecodeOut = TDEncode(modOut, prmLTEPDSCH.numTx);
%% Channel
% MIMO fading channel
[fadeOut, pathGain]     = MIMOFadingChan(PrecodeOut, prmLTEPDSCH, prmMdl);
nVar                      = real(var(fadeOut(:)))/(10.^(0.1*snrdB));
pathG                            = squeeze(pathGain);
% AWGN
recOut                           = AWGNChannel(fadeOut, nVar);
%% RX
% Transmit diversity combiner
rxSig =  TDCombine(recOut, pathG,  prmLTEPDSCH.numTx,  prmLTEPDSCH.numRx);  
% Demodulate
demodOut = DemodulatorSoft(rxSig, prmLTEPDSCH.modType, nVar);
% Descramble both received codewords
rxCW1 =  Descramble(demodOut, nS, 0, prmLTEPDSCH.maxG);
% Channel decoding includes - CB segmentation, turbo decoding, rate dematching
[decTbData1, ~,~] = TbChannelDecoding(nS, rxCW1, Kplus1, C1,  prmLTEDLSCH, prmLTEPDSCH);
% Transport block CRC detection
[dataOut, ~] = CRCdetector(decTbData1);
end