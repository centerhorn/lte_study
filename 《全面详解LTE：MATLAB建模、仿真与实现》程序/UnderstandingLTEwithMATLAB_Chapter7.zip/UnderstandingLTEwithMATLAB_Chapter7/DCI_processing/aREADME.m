% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter7\DCI_processing)
%
% This folder contains a series of MATLAB functions that showcase 
% the signal processing chain involved in transmission of downlink control channel information
% as presented in chapter 7 of the "Understanding LTE with MATLAB"
%
% How to run the demo:
% 1. To perform experiment, use the BERTOOL of the Communications
% System Toolbox as follows:
% type bertool at the MATLAB command prompt. 
% Go to Monte Carlo tab, 
% In the "Simulation MATLAB file ..." edit-box choose the following main function
% commlteMIMO_DCI.m
% Set a range of EbNo values, set the BER variable name to ber, and
% set typical values for parameters Number of errors & Number of bits. 
% For better results, the experiments have to be long enough, 
% which usually means parametrers Number of errors or Number of bits
% need to be larger than 1e2 and 1e7 respectively. 
% 2. Alternatively you can run the following MATLAB script 
% commlteMIMO_DCI_BERtestbench
% which performs the same list of operations listed in the first demo to obtain the BER results. 
