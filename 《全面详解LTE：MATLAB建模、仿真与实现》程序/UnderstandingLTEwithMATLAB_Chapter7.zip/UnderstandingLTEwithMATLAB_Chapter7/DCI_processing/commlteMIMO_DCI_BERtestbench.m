SnrVec=0:0.5:1.5;
maxNumErrs=1e4;
maxNumBits=1e7;
Bers=zeros(size(SnrVec));
Num=numel(SnrVec);
for n=1:Num
    snrdB=SnrVec(n);
    fprintf(1,'Iteration %2d out of %2d:  Processing %10d bits. SNR = %4.2f ;', ...
        n, numel(SnrVec), maxNumBits, snrdB);
    ber=commlteMIMO_DCI(snrdB, maxNumErrs, maxNumBits);
    Bers(n)=ber;
    fprintf(1,'BER = %g\n',ber);
end
semilogy(SnrVec, Bers)
grid;title('BER vs. EbNo - DCI processing');
xlabel('Eb/No (dB)');ylabel('BER');hold;