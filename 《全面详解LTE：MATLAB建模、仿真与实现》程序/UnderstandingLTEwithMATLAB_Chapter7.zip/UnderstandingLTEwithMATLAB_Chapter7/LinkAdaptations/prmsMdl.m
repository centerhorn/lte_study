function prmMdl = prmsMdl(~, chanSRate,  chanMdl, Doppler, numTx, numRx, ...
    corrLvl, chEstOn, enPMIfback, cbIdx, snrdB, maxNumErrs, maxNumBits)
prmMdl.chanMdl = chanMdl;
prmMdl.AntConfig=char([48+numTx,'x',48+numRx]);
prmMdl.Doppler=Doppler;
switch chanMdl
    case 'flat',
        prmMdl.PathDelays = 0*(1/chanSRate);
        prmMdl.PathGains  = 0;
        prmMdl.ChannelType =1;
    case 'frequency-selective',
        prmMdl.PathDelays = (0:1:4)*(1.0e-06);
        prmMdl.PathGains  = [0 -4 -8 -12 -16];
        prmMdl.ChannelType =1;
    case 'EPA 0Hz'
        prmMdl.PathDelays = [0 30 70 90 110 190 410]*1e-9;
        prmMdl.PathGains  = [0 -1 -2 -3 -8 -17.2 -20.8];
        prmMdl.ChannelType =1;
    otherwise
        prmMdl.PathDelays = 0*(1/chanSRate);
        prmMdl.PathGains  = 0;
        prmMdl.ChannelType =2;
end
prmMdl.corrLevel = corrLvl;
prmMdl.chEstOn = chEstOn;
prmMdl.snrdB=snrdB;
prmMdl.maxNumBits=maxNumBits;
prmMdl.maxNumErrs=maxNumErrs;
prmMdl.enPMIfback = enPMIfback;
prmMdl.cbIdx = cbIdx;