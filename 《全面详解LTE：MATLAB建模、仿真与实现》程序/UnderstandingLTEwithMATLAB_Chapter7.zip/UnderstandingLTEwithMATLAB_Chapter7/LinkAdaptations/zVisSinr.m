function vec=zVisSinr(sinr)
persistent Plot Buffer
if isempty(Plot)
Plot = dsp.ArrayPlot( 'Title', 'SINR','YLimits', [0 30],'Position',figposition([20 65 20 25]));
Buffer=dsp.Buffer('Length',25,'OverlapLength',24);
end
vec=step(Buffer,sinr);
step(Plot,vec);
