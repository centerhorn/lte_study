function sinr=CQIselection(bits, equalized,  nS, prmLTEDLSCH, prmLTEPDSCH)
%#codegen
tbCrcOut1 =CRCgenerator(bits);
% Channel coding includes - CB segmentation, turbo coding, rate matching,
% bit selection, CB concatenation - per codeword
data = lteTbChannelCoding(tbCrcOut1, nS, prmLTEDLSCH, prmLTEPDSCH);
%Scramble codeword
scramOut = Scramble(data, nS, 0, prmLTEPDSCH.maxG);
% Modulate
modOut = Modulator(scramOut, prmLTEPDSCH.modType);
% Map modulated symbols  to layers
LayerMapOut = LayerMapper(modOut, [], prmLTEPDSCH);
% Compute post-detection error
error=LayerMapOut-equalized;
sinr=10*log10(var(modOut(:))./var(error(:)));
