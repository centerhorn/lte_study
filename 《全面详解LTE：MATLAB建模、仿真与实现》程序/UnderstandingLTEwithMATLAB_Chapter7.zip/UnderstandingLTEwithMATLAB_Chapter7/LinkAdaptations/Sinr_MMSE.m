function Gamma = Sinr_MMSE(chEst, nVar, Wn)
%#codegen
% SINR computation:
%   Based on received channel estimates
% Per layer noise variance 
% Precoder matrix 
% Uses the MMSE detector.
% Get params
persistent Gmean
if isempty(Gmean), Gmean=dsp.Mean('RunningMean', true);end
noisFac = diag(nVar);
numData = size(chEst, 1);
numLayers = size(Wn,1);
F = inv(Wn);
%% MMSE receiver
for n = 1:numData
    h = chEst(n, :, :);                         % numTx x numRx
    h = reshape(h(:), numLayers, numLayers).';  % numRx x numTx
    Ht= inv((F'*(h'*h)*F) + noisFac);
    % Post-detection SINR
    g=real((1./(diag(Ht).*(nVar.')))-1);
    Gamma=step(Gmean,g);
end
reset(Gmean);