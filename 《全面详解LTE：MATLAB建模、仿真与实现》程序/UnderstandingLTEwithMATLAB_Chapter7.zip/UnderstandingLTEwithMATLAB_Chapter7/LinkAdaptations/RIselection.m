function y=RIselection(Ri, threshold)
% RI estimation
if Ri > threshold
    y = 4;
else
    y=2;
end