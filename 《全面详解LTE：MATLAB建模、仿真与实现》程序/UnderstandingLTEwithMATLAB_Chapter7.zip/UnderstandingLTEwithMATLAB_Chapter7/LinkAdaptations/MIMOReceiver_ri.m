function [y, ri] = MIMOReceiver_ri(in, chEst, prmLTE, nVar, Wn)
%#codegen
switch prmLTE.Eqmode
    case 1 % ZF receiver
        [y, ri] = MIMOReceiver_ZF_ri(in, chEst, Wn);
    case 2 % MMSE receiver
       [y, ri] = MIMOReceiver_MMSE_ri(in, chEst, nVar, Wn);
    case 3 % Sphere Decoder
        [y, ri] = MIMOReceiver_SphereDecoder_ri(in, chEst, prmLTE, nVar, Wn);
    otherwise
        error('Function MIMOReceiver: ZF, MMSE, Sphere decoder are only supported MIMO detectors');
end
