function vec=zVisRi(sinr)
persistent Plot Buffer
if isempty(Plot)
Plot = dsp.ArrayPlot('YLimits', [0 5],'Position',figposition([20 65 20 25]));
Buffer=dsp.Buffer('Length',25,'OverlapLength',24);
end
vec=step(Buffer,sinr);
step(Plot,vec);
