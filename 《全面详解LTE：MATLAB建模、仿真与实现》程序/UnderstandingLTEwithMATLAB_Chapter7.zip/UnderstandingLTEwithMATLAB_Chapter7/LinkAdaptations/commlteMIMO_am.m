% Script for MIMO LTE (mode 4)
%
% Single codeword transmission
%
clear functions
%% Set simulation parametrs & initialize parameter structures
commlteMIMO_params_amc;
[prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_initialize(txMode, ...
    chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, Doppler, corrLvl, ...
    chEstOn, numCodeWords, enPMIfback, cbIdx, snrdB, maxNumErrs, maxNumBits);
clear txMode chanBW contReg modType Eqmode numTx numRx cRate maxIter fullDecode chanMdl Doppler corrLvl chEstOn numCodeWords enPMIfback cbIdx snrdB maxNumErrs maxNumBits
%%
disp('Simulating LTE with CQI-based adaptation of modulation and coding rate');
disp('Mode 4 Closed loop Spatial Multiplexing');
hPBer = comm.ErrorRate;
snrdB=prmMdl.snrdB;
maxNumErrs=prmMdl.maxNumErrs;
maxNumBits=prmMdl.maxNumBits;
%% Simulation loop
tic;
Frame=0;
nS = 0; % Slot number, one of [0:2:18]
Measures = zeros(3,1); %initialize BER output
while (Measures(3) < maxNumBits)
    %% One subframe step
    [dataIn, dataOut, txSig, rxSig, dataRx, yRec, csr] = ...
        commlteMIMO_SM_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
    %% Report average data rates
    fprintf(1,'\n---\nSubframe                     = %d\n',Frame);
    ADR_a=zReport_data_rate_average(prmLTEPDSCH, prmLTEDLSCH);
    %% CQI feedback
    sinr=CQIselection(dataOut, yRec,  nS, prmLTEDLSCH, prmLTEPDSCH);
    indexMCS=CQI2indexMCS(sinr);
    %% Calculate  bit errors
    Measures = step(hPBer, dataIn, dataOut);
    %% Visualize results
    if (visualsOn && prmLTEPDSCH.Eqmode~=3)
        zVisualize( prmLTEPDSCH, txSig, rxSig, yRec, dataRx, csr, nS);
        zVisSinr(sinr);
    end;
    fprintf(1,'Bits processed               = %d\n', Measures(3));
    fprintf(1,'BER                          = %g\n', Measures(1));
    % Update subframe number
    nS = nS + 2; if nS > 19, nS = mod(nS, 20); end;
    % Adaptive change of modulation
    Frame=Frame+1;
    modType=indexMCS;
    [prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_update( prmLTEPDSCH, prmLTEDLSCH, prmMdl, modType);
end
toc;