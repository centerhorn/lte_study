function [p1, p2, p3] = commlteMIMO_update(p1,p2, p3, varargin)
switch nargin
    case 4, modType=varargin{1}; cRate=p2.cRate; cbIdx=p3.cbIdx; txMode=p1.txMode;
    case 5, modType=varargin{1}; cRate=varargin{2}; cbIdx=p3.cbIdx; txMode=p1.txMode; 
    case 6, modType=varargin{1}; cRate=varargin{2}; cbIdx=varargin{3}; txMode=p1.txMode;  
    case 7, modType=varargin{1}; cRate=varargin{2}; cbIdx=varargin{3}; txMode=varargin{4};
    otherwise
        error('commlteMIMO_update has 1 to 4 arguments!');
end
%PDSCH parameters
tmp = prmsPDSCH(txMode, p1.chanBW, p1.contReg, modType,p1.numTx, p1.numRx, ...
    p1.numCodeWords,p1.Eqmode);
p1=tmp;
[SymbolMap, Constellation]=ModulatorDetail(p1.modType);
p1.SymbolMap=SymbolMap;
p1.Constellation=Constellation;
% DLSCH parameters
p2 = prmsDLSCH(cRate, p2.maxIter, p2.fullDecode, p1);
% Channel model
tmp = prmsMdl(txMode, p1.chanSRate,  p3.chanMdl, p3.Doppler, p1.numTx, p1.numRx, ...
    p3.corrLevel, p3.chEstOn, p3.enPMIfback, cbIdx, p3.snrdB, p3.maxNumErrs, p3.maxNumBits);
p3=tmp;