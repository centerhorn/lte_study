% zREADME.m 
% Instructions regarding how to run MATLAB experiments in this directory
% (UnderstandingLTEwithMATLAB_Chapter7\LinkAdaptations)
%
% This folder contains multiple MATLAB scripts (testbenches) that showcase how
% to execute the link adaptation experiments as presented in chapter 7 of
% the book "Understanding LTE with MATLAB"
% 
% There are all together 8 experiments that cover the link adaptation
% results presented in chapter 7. All these experiments apply to LTE Mode 4. 
% We have divided them in two categories:
% A) Adaptive modulation and coding experiments together with associated no-adaptation baselines
% B) Adaptive precoding and adaptive MIMO experiments together with associated
% no-adaptation baselines
%
% Category A
% 1. commlteMIMO.m                      = Baseline (no adaptation)
% 2. commlteMIMO_am.m               = Adaptive modulation based on CQI feedback
% 3. commlteMIMO_amRand.m       = Randomized selection of modulation mode           
% 4. commlteMIMO_amc.m              = Adaptive modulation and coding rate based on CQI feedback
% 5. commlteMIMO_amcRand.m      = Randomized selection of modulation mode and coding rate          
% Category B
% 6. commlteMIMO_d.m                  = Baseline (no adaptation)                     
% 7. commlteMIMO_d_PMI.m          = Adaptive precoder index based on PMI feedback        
% 8. commlteMIMO_d_PMI_RI.m     = Adaptive precoder based on PMI feedback
%                                                           and adaptive MIMO (switch between SM and TD Tx modes) based on RI feedback        
% How to run demos:
% type each <experiment name>  such as commlteMIMO_amc at the MATLAB command prompt
% 
% You will see that the scripts first set relevant experiment parameters found in MATLAB script
% commlteMIMO_params_amc.m for category A experiments 
% and commlteMIMO_params_PMI.m for category B experiments
% Then they initializes three LTE transceiver parameter structures 
% by calling the function commlteMIMO_initialize.m. Then they set up while loop to call 
% the main transceiver functions:
% commlteMIMO_SM_step.m for all Category A and only the baseline of category B experiments
% commlteMIMO_SM_PMI_step.m for adaptive precoding experiment
% commlteMIMO_SM_PMI_RI_step.m for adaptive precoding and adaptive MIMO experiment
% Each iteration of the while loop processes one subframe of data.
% At each subframe, information regarding current modulation scheme
% (modType parameter), current coding rate (cRate parameter) and their
% averages are printed in the MATLAB workspace.
% In category B expderiments in addition to these information the precoder
% matrix index (cbIdx parameter) and current transmission mode (txMode
% parameter) are also printed to the workspace.
% You will see that after processing each subframe, the script calls the visualization functions 
% (zVisualize.m, zVisSinr.m and zVisRi.m) to 
% examine the magnitude spectra of the tranmitted and received signals (before and after equalization)
% as well as the modulation constellation of the transmitted and the received signals
% and a history of SINR and Rank estrimation measurements in succesive subframes.
% Exploration:
% By changing parameters such as modfulation scheme (modType parameter) and coding rate (cRate parameter)  
% in file commlteMIMO_params_amc.m you can experiment with various test conditions and initalize modulation and coding rates.
% As always by chaging parameters such as maxNumErrs and maxNumBits,  
% you get longer or shorter experiment time. By changing the link SNR, the parameter snrdB, you can see the efect of AWGN noise
% on the overall performance. Keep the parameter txMode always initialized
% as 4 (Closed loop spatial multiplexing). You can also explorwe a 2x2 or a
% 4x4 antenna configuration by chaning the numTx and numRx parameters
% respectively.
% 