function cbIdx = PMICbSelect(h, enPMIfback, numTx, numLayers, nVar)
%#codegen
% Codebook selection using minimum MSE criterion
if (enPMIfback)
    if (numTx == 2)
        cbLen = 2; % Only indices 1 and 2 are used for 2-layer closed-loop Spatial MUX
        MSEcb = zeros(cbLen, 1);
        for cbIdx = 1:cbLen
            Wn = PrecoderMatrix(cbIdx, numTx, numLayers);
            MSEcb(cbIdx) = Sinr_MMSE(h, nVar, Wn);
        end
        [~, cbIdx] = max(MSEcb); % 0-based, note 0 and 3 are not used
    else % for numTx=4
        cbLen = 2^numLayers;
        MSEcb = zeros(cbLen, 1);
        for cbIdx = 1:cbLen
            Wn = PrecoderMatrix(cbIdx-1, numTx, numLayers);
            MSEcb(cbIdx) = Sinr_MMSE(h, nVar, Wn);
        end
        [~, cbIdx] = max(MSEcb);   % 1-based
        cbIdx = cbIdx-1;        % 0-based
    end
else
    cbIdx = 1;
end
end
% Helper function
function out = Sinr_MMSE(chEst, nVar, Wn)
%#codegen
% post-detection SNR computation
% Based on received channel estimates
% Per layer noise variance
% Precoder matrix
% Uses the MMSE detector.
% Get params
persistent Gmean
if isempty(Gmean), Gmean=dsp.Mean('RunningMean', true);end
noisFac = diag(nVar);
numData = size(chEst, 1);
numLayers = size(Wn,1);
F = inv(Wn);
%% MMSE receiver
for n = 1:numData
    h = chEst(n, :, :);                         % numTx x numRx
    h = reshape(h(:), numLayers, numLayers).';  % numRx x numTx
    Ht= inv((F'*(h'*h)*F) + noisFac);
    % Post-detection SINR
    g=real((1./(diag(Ht).*(nVar.')))-1);
    Gamma=step(Gmean,g);
end
out=mean(Gamma);
reset(Gmean);
end