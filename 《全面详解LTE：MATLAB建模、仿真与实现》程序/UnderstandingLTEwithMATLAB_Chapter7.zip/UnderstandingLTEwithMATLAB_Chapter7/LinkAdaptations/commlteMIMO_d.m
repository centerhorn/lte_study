% Script for MIMO LTE (mode 4)
%
% Single codeword transmission
%
clear functions
%% Set simulation parametrs & initialize parameter structures
commlteMIMO_params_PMI;
[prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_initialize(txMode, ...
    chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, Doppler, corrLvl, ...
    chEstOn, numCodeWords, enPMIfback, cbIdx, snrdB, maxNumErrs, maxNumBits);
clear txMode chanBW contReg modType Eqmode numTx numRx cRate maxIter fullDecode chanMdl Doppler corrLvl chEstOn numCodeWords enPMIfback cbIdx snrdB maxNumErrs maxNumBits
%%
disp('Simulating LTE without link adaptations;    Mode 4 Closed loop Spatial Multiplexing');
hPBer = comm.ErrorRate;
snrdB=prmMdl.snrdB;
maxNumErrs=prmMdl.maxNumErrs;
maxNumBits=prmMdl.maxNumBits;
%% Simulation loop
tic;
Frame=0;
nS = 0; % Slot number, one of [0:2:18]
Measures = zeros(3,1); %initialize BER output
while (Measures(3) < maxNumBits)
    %% One subframe step processing
    [dataIn, dataOut, txSig, rxSig, dataRx, yRec, csr] = ...
        commlteMIMO_SM_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
     %% Report average data rates
    fprintf(1,'\n---\nSubframe                     = %d\n',Frame);
    ADR=zReport_data_rate_average(prmLTEPDSCH, prmLTEDLSCH);
    %% Calculate  bit errors
    Measures = step(hPBer, dataIn, dataOut);
    %% Visualize results
    if (visualsOn && prmLTEPDSCH.Eqmode~=3)
        zVisualize( prmLTEPDSCH, txSig, rxSig, yRec, dataRx, csr, nS);
    end;
    fprintf(1,'Bits processed               = %d\n', Measures(3));
    fprintf(1,'BER                          = %g\n', Measures(1));
    %% Update subframe number
    nS = nS + 2; if nS > 19, nS = mod(nS, 20); end;    
    Frame=Frame+1;
    %% No adaptations here
end
toc;