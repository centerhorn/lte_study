function MCSindex=map2MCSindex(TBSindex, modType)
%#codegen
% Assume 1-based indexing
if ((TBSindex < 1) ||  (TBSindex >27)), error('map2MCSindex function: Wrong TBSindex.');end
switch TBSindex
    case 10
        switch modType
            case 1
                MCSindex=10;
            case 2
                MCSindex=11;
            otherwise
                error('Wrong combination of TBSindex and modulation type');
        end
    case 16
        switch modType
            case 2
                MCSindex=17;
            case 3
                MCSindex=18;
            otherwise
                error('Wrong combination of TBSindex and modulation type');
        end
    otherwise
        if TBSindex <10
            MCSindex=TBSindex;
        elseif ((TBSindex >10) &&  (TBSindex <16))
            MCSindex=TBSindex+1;
        else
            MCSindex=TBSindex+2;
        end
end