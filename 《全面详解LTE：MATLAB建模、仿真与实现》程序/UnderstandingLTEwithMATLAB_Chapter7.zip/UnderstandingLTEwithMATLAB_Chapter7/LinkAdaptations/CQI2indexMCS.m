function [Ms, Cr]=CQI2indexMCS(sinr)
%#codegen
% Table of SINR threshold values, 15 boundary points for an unbounded quantizer
thresh=[-6.7,-4.7,-2.3,0.2,2.4,4.3,5.9,8.1,10.3,11.7,14.1,16.3,18.7,21,22.7];
% Table of coding rate (16 value)
Map2CodingRate=[0.076, 0.076, 0.117, 0.188, 0.301, 0.438, 0.588, 0.369, 0.479,...
0.602, 0.455, 0.554, 0.650, 0.754, 0.853, 0.926];
% Table of modulation type (1=QPSK, 2=QAM16, 3=QAM64)
Map2Modulator=[1*ones(7,1);2*ones(3,1);3*ones(6,1)];
persistent hQ
if isempty(hQ)
    hQ=dsp.ScalarQuantizerEncoder(...
        'Partitioning', 'Unbounded',...
        'BoundaryPoints',  thresh,...
        'OutputIndexDataType','uint8');
end;
indexCQI=step(hQ, sinr);
index1=indexCQI+1;                   % 1-based indexing
% Map CQI index to modulation type
Ms = Map2Modulator (index1);
% Map CQI index to coding rate
Cr = Map2CodingRate (index1);
if Cr < 1/3, Cr=1/3;end;