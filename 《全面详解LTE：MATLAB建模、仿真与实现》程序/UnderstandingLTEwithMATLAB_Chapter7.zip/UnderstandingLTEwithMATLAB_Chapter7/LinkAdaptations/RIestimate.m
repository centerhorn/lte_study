function y = RIestimate(Q)
%#codegen
y=cond(Q);
% x=abs(eig(Q));
% y=max(x)/min(x);