% Script for MIMO LTE
%
% Single codeword transmission
%
clear functions
%% Set simulation parametrs & initialize parameter structures
commlteMIMO_params_PMI;
[prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_initialize(txMode, ...
    chanBW, contReg, modType, Eqmode,numTx, numRx,cRate,maxIter, fullDecode, chanMdl, Doppler, corrLvl, ...
    chEstOn, numCodeWords, enPMIfback, cbIdx, snrdB, maxNumErrs, maxNumBits);
clear txMode chanBW contReg modType Eqmode numTx numRx cRate maxIter fullDecode chanMdl Doppler corrLvl chEstOn numCodeWords enPMIfback cbIdx snrdB maxNumErrs maxNumBits
%%
disp('Simulating LTE link adaptations;    Adaptive MIMO (rank adaptation)');
disp('Full-rank -> Spatial Multiplexing');
disp('Less than full-rank -> Transmit Diversity');
hPBer = comm.ErrorRate;
snrdB=prmMdl.snrdB;
maxNumErrs=prmMdl.maxNumErrs;
maxNumBits=prmMdl.maxNumBits;
threshold = 5;
%% Simulation loop
tic;
Frame=0;
nS = 0; % Slot number, one of [0:2:18]
Measures = zeros(3,1); %initialize BER output
while (Measures(3) < maxNumBits)
    %% One subframe step
    [dataIn, dataOut, txSig, rxSig, dataRx, yRec, csr, cbIdx, ri] ...
        =  commlteMIMO_SM_PMI_RI_step(nS, snrdB, prmLTEDLSCH, prmLTEPDSCH, prmMdl);
    
    sinr=CQIselection(dataOut, yRec,  nS, prmLTEDLSCH, prmLTEPDSCH);
    Ri=RIselection(sinr, threshold);
    fprintf(1,'\n---\nSubframe                     = %d\n',Frame);
    ADR_a=zReport_data_rate_average(prmLTEPDSCH, prmLTEDLSCH);
    fprintf(1,'PMI codebook index           = %2d\n', cbIdx);
    fprintf(1,'Current transmission mode    = %2d\n', Ri);
    
    %% Calculate  bit errors
    Measures = step(hPBer, dataIn, dataOut);
    %% Visualize results
    if (visualsOn && prmLTEPDSCH.Eqmode~=3)
        zVisualize( prmLTEPDSCH, txSig, rxSig, yRec, dataRx, csr, nS);
        zVisSinr(sinr);
        zVisRi(Ri);
    end;
    fprintf(1,'Bits processed               = %d\n', Measures(3));
    fprintf(1,'BER                          = %g\n', Measures(1));
    % Update subframe number
    nS = nS + 2; if nS > 19, nS = mod(nS, 20); end;
    Frame=Frame+1;
    % Adaptive change of modulation
    modType=prmLTEPDSCH.modType;
    cRate=prmLTEDLSCH.cRate;
    cbIdx=prmMdl.cbIdx;
    [prmLTEPDSCH, prmLTEDLSCH, prmMdl] = commlteMIMO_update(...
        prmLTEPDSCH, prmLTEDLSCH, prmMdl, modType, cRate,  cbIdx, Ri);
end
toc;